// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.





#include "icl_parser.hh"


// Unqualified %code blocks.
#line 74 "src/icl_parser.yy"

// Declared by the generated scanner (see icl_lexer.l). It must be visible at
// the parser's call site; this block lands after the parser class definition,
// so |IclParser::symbol_type| is a complete type here.
namespace icl {
IclParser::symbol_type yylex(IclDriver& driver);
}  // namespace icl
#line 83 "src/icl_parser.yy"

#include "icl_driver.h"

namespace icl {

// Reports the (first) syntax error. The driver owns the diagnostic state (it
// used to be a file-scope global); it keeps only the earliest error because
// later ones are cascades of it.
void IclParser::error(const location& loc, const std::string& message) {
  driver.SetParseDiagnostic(loc.begin.line, message);
}

}  // namespace icl

#line 69 "build/gen/icl_parser.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif


// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yy_stack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YY_USE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 42 "src/icl_parser.yy"
namespace icl {
#line 162 "build/gen/icl_parser.cc"

  /// Build a parser object.
  IclParser::IclParser (icl::IclDriver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      yy_lac_established_ (false),
      driver (driver_yyarg)
  {}

  IclParser::~IclParser ()
  {}

  IclParser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------.
  | symbol.  |
  `---------*/



  // by_state.
  IclParser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  IclParser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  IclParser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  IclParser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  IclParser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  IclParser::symbol_kind_type
  IclParser::by_state::kind () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return symbol_kind::S_YYEMPTY;
    else
      return YY_CAST (symbol_kind_type, yystos_[+state]);
  }

  IclParser::stack_symbol_type::stack_symbol_type ()
  {}

  IclParser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.YY_MOVE_OR_COPY< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.YY_MOVE_OR_COPY< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.YY_MOVE_OR_COPY< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  IclParser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.move< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.kind_ = symbol_kind::S_YYEMPTY;
  }

#if YY_CPLUSPLUS < 201103L
  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.copy< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.copy< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.copy< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.copy< std::vector<AstNode*> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.move< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  IclParser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  IclParser::yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YY_USE (yyoutput);
    if (yysym.empty ())
      yyo << "empty symbol";
    else
      {
        symbol_kind_type yykind = yysym.kind ();
        yyo << (yykind < YYNTOKENS ? "token" : "nterm")
            << ' ' << yysym.name () << " ("
            << yysym.location << ": ";
        switch (yykind)
    {
      case symbol_kind::S_IDENT: // "identifier"
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 442 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_NUMBER: // "number"
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 448 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_STRING: // "string"
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 454 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_COMMENT: // "comment"
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 460 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_port_keyword: // port_keyword
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 466 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_opt_range: // opt_range
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 472 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_ident_list: // ident_list
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 478 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_name: // attr_name
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 484 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_conn_expr: // conn_expr
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 490 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value: // value
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 496 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_postfix: // postfix
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 502 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_primary: // primary
#line 179 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 508 "build/gen/icl_parser.cc"
        break;

      default:
        break;
    }
        yyo << ')';
      }
  }
#endif

  void
  IclParser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  IclParser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  IclParser::yypop_ (int n) YY_NOEXCEPT
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  IclParser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  IclParser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  IclParser::debug_level_type
  IclParser::debug_level () const
  {
    return yydebug_;
  }

  void
  IclParser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  IclParser::state_type
  IclParser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - YYNTOKENS] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - YYNTOKENS];
  }

  bool
  IclParser::yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  IclParser::yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yytable_ninf_;
  }

  int
  IclParser::operator() ()
  {
    return parse ();
  }

  int
  IclParser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

    // Discard the LAC context in case there still is one left from a
    // previous invocation.
    yy_lac_discard_ ("init");

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';
    YY_STACK_PRINT ();

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token\n";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    if (yyla.kind () == symbol_kind::S_YYerror)
    {
      // The scanner already issued an error message, process directly
      // to error recovery.  But do not keep the error token as
      // lookahead, it is too special and may lead us to an endless
      // loop in error recovery. */
      yyla.kind_ = symbol_kind::S_YYUNDEF;
      goto yyerrlab1;
    }

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.kind ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.kind ())
      {
        if (!yy_lac_establish_ (yyla.kind ()))
          goto yyerrlab;
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        if (!yy_lac_establish_ (yyla.kind ()))
          goto yyerrlab;

        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    yy_lac_discard_ ("shift");
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case symbol_kind::S_module_def: // module_def
        yylhs.value.emplace< AstBlock* > ();
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        yylhs.value.emplace< AstNode* > ();
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        yylhs.value.emplace< std::string > ();
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        yylhs.value.emplace< std::vector<AstNode*> > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 3: // file: file module_def
#line 190 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(yystack_[0].value.as < AstBlock* > ()); }
#line 803 "build/gen/icl_parser.cc"
    break;

  case 4: // file: file "comment"
#line 192 "src/icl_parser.yy"
      {
        // Unlike the nested bodies below, the top-level rule has no vector to
        // append to, so the comment must be pushed onto the unit explicitly.
        driver.unit().top_level().push_back(
            driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)));
      }
#line 814 "build/gen/icl_parser.cc"
    break;

  case 5: // module_def: "Module" "identifier" "{" module_item_list "}"
#line 202 "src/icl_parser.yy"
      {
        yylhs.value.as < AstBlock* > () = driver.MakeBlock("Module " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 822 "build/gen/icl_parser.cc"
    break;

  case 6: // module_item_list: %empty
#line 209 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 828 "build/gen/icl_parser.cc"
    break;

  case 7: // module_item_list: module_item_list module_item
#line 211 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 834 "build/gen/icl_parser.cc"
    break;

  case 8: // module_item: "comment"
#line 215 "src/icl_parser.yy"
            { yylhs.value.as < AstNode* > () = driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)); }
#line 840 "build/gen/icl_parser.cc"
    break;

  case 9: // module_item: "Parameter" "identifier" "=" value ";"
#line 217 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Parameter " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 847 "build/gen/icl_parser.cc"
    break;

  case 10: // module_item: "Attribute" "identifier" "=" value ";"
#line 220 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Attribute " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 854 "build/gen/icl_parser.cc"
    break;

  case 11: // module_item: "Alias" "identifier" "=" value ";"
#line 223 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Alias " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 861 "build/gen/icl_parser.cc"
    break;

  case 12: // module_item: "Alias" "identifier" "=" value "{" attr_body "}"
#line 226 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Alias " + yystack_[5].value.as < std::string > () + " = " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 869 "build/gen/icl_parser.cc"
    break;

  case 13: // module_item: "Enum" "identifier" "{" attr_body "}"
#line 230 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Enum " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 877 "build/gen/icl_parser.cc"
    break;

  case 14: // module_item: port_decl
#line 233 "src/icl_parser.yy"
              { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 883 "build/gen/icl_parser.cc"
    break;

  case 15: // module_item: "ScanInterface" "identifier" "{" attr_body "}"
#line 235 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("ScanInterface " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 891 "build/gen/icl_parser.cc"
    break;

  case 16: // module_item: "OneHotScanInterface" "identifier" "{" attr_body "}"
#line 239 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("OneHotScanInterface " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 899 "build/gen/icl_parser.cc"
    break;

  case 17: // module_item: "ScanRegister" "identifier" opt_range "{" attr_body "}"
#line 243 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("ScanRegister " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 907 "build/gen/icl_parser.cc"
    break;

  case 18: // module_item: "ScanRegister" "identifier" opt_range ";"
#line 247 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("ScanRegister " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 914 "build/gen/icl_parser.cc"
    break;

  case 19: // module_item: "Reg" "identifier" opt_range "{" attr_body "}"
#line 250 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Reg " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 922 "build/gen/icl_parser.cc"
    break;

  case 20: // module_item: "Reg" "identifier" opt_range ";"
#line 254 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement( "Reg " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 929 "build/gen/icl_parser.cc"
    break;

  case 21: // module_item: "Field" "identifier" opt_range "Of" "identifier" "{" attr_body "}"
#line 257 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Field " + yystack_[6].value.as < std::string > () + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[7].location.begin.line, yystack_[0].location.end.line));
      }
#line 937 "build/gen/icl_parser.cc"
    break;

  case 22: // module_item: "Field" "identifier" opt_range "Of" "identifier" ";"
#line 261 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement( "Field " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > () + " Of " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line)); }
#line 944 "build/gen/icl_parser.cc"
    break;

  case 23: // module_item: "Instance" "identifier" "Of" "identifier" "{" attr_body "}"
#line 264 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Instance " + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 952 "build/gen/icl_parser.cc"
    break;

  case 24: // module_item: "Instance" "identifier" "Of" "identifier" ";"
#line 268 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Instance " + yystack_[3].value.as < std::string > () + " Of " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 959 "build/gen/icl_parser.cc"
    break;

  case 25: // module_item: "ScanMux" "identifier" "SelectedBy" value "{" mux_body "}"
#line 271 "src/icl_parser.yy"
      {
        // `SelectedBy` is part of the standard (IEEE 1687.1-2014); the
        // selector may be a hierarchical name such as `MyTap.M3_sel`, hence
        // |value| rather than a bare IDENT.
        yylhs.value.as < AstNode* > () = driver.MakeBlock("ScanMux " + yystack_[5].value.as < std::string > () + " SelectedBy " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 970 "build/gen/icl_parser.cc"
    break;

  case 26: // module_item: "LogicSignal" "identifier" "{" attr_body "}"
#line 278 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("LogicSignal " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 978 "build/gen/icl_parser.cc"
    break;

  case 27: // module_item: "Connection" "{" conn_body "}"
#line 282 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Connection", std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
      }
#line 986 "build/gen/icl_parser.cc"
    break;

  case 28: // module_item: "PortGroup" "identifier" "{" ident_list "}"
#line 286 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("PortGroup " + yystack_[3].value.as < std::string > () + " {" + yystack_[1].value.as < std::string > () + "}",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 993 "build/gen/icl_parser.cc"
    break;

  case 29: // module_item: "AccessLink" "identifier" "Of" "identifier" "{" attr_body "}"
#line 289 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("AccessLink " + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 1001 "build/gen/icl_parser.cc"
    break;

  case 30: // port_keyword: "ScanInPort"
#line 297 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanInPort"; }
#line 1007 "build/gen/icl_parser.cc"
    break;

  case 31: // port_keyword: "ScanOutPort"
#line 298 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanOutPort"; }
#line 1013 "build/gen/icl_parser.cc"
    break;

  case 32: // port_keyword: "ShiftEnPort"
#line 299 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ShiftEnPort"; }
#line 1019 "build/gen/icl_parser.cc"
    break;

  case 33: // port_keyword: "CaptureEnPort"
#line 300 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "CaptureEnPort"; }
#line 1025 "build/gen/icl_parser.cc"
    break;

  case 34: // port_keyword: "UpdateEnPort"
#line 301 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "UpdateEnPort"; }
#line 1031 "build/gen/icl_parser.cc"
    break;

  case 35: // port_keyword: "SelectPort"
#line 302 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "SelectPort"; }
#line 1037 "build/gen/icl_parser.cc"
    break;

  case 36: // port_keyword: "ResetPort"
#line 303 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ResetPort"; }
#line 1043 "build/gen/icl_parser.cc"
    break;

  case 37: // port_keyword: "TCKPort"
#line 304 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TCKPort"; }
#line 1049 "build/gen/icl_parser.cc"
    break;

  case 38: // port_keyword: "TMSPort"
#line 305 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TMSPort"; }
#line 1055 "build/gen/icl_parser.cc"
    break;

  case 39: // port_keyword: "TRSTPort"
#line 306 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TRSTPort"; }
#line 1061 "build/gen/icl_parser.cc"
    break;

  case 40: // port_keyword: "ToTCKPort"
#line 307 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTCKPort"; }
#line 1067 "build/gen/icl_parser.cc"
    break;

  case 41: // port_keyword: "ToTMSPort"
#line 308 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTMSPort"; }
#line 1073 "build/gen/icl_parser.cc"
    break;

  case 42: // port_keyword: "ToTRSTPort"
#line 309 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTRSTPort"; }
#line 1079 "build/gen/icl_parser.cc"
    break;

  case 43: // port_keyword: "ToShiftEnPort"
#line 310 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToShiftEnPort"; }
#line 1085 "build/gen/icl_parser.cc"
    break;

  case 44: // port_keyword: "ToCaptureEnPort"
#line 311 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToCaptureEnPort"; }
#line 1091 "build/gen/icl_parser.cc"
    break;

  case 45: // port_keyword: "ToUpdateEnPort"
#line 312 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToUpdateEnPort"; }
#line 1097 "build/gen/icl_parser.cc"
    break;

  case 46: // port_keyword: "ToResetPort"
#line 313 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToResetPort"; }
#line 1103 "build/gen/icl_parser.cc"
    break;

  case 47: // port_keyword: "ToDoPort"
#line 314 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToDoPort"; }
#line 1109 "build/gen/icl_parser.cc"
    break;

  case 48: // port_keyword: "ToSelectPort"
#line 315 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToSelectPort"; }
#line 1115 "build/gen/icl_parser.cc"
    break;

  case 49: // port_keyword: "DataInPort"
#line 316 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataInPort"; }
#line 1121 "build/gen/icl_parser.cc"
    break;

  case 50: // port_keyword: "DataOutPort"
#line 317 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataOutPort"; }
#line 1127 "build/gen/icl_parser.cc"
    break;

  case 51: // opt_range: %empty
#line 321 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = std::string(); }
#line 1133 "build/gen/icl_parser.cc"
    break;

  case 52: // opt_range: "[" "number" "]"
#line 322 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1139 "build/gen/icl_parser.cc"
    break;

  case 53: // opt_range: "[" "number" ":" "number" "]"
#line 323 "src/icl_parser.yy"
                                          { yylhs.value.as < std::string > () = "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1145 "build/gen/icl_parser.cc"
    break;

  case 54: // port_decl: port_keyword "identifier" opt_range ";"
#line 328 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
      }
#line 1154 "build/gen/icl_parser.cc"
    break;

  case 55: // port_decl: port_keyword "identifier" opt_range "{" attr_body "}"
#line 333 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 1162 "build/gen/icl_parser.cc"
    break;

  case 56: // attr_item: attr_name ";"
#line 345 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1169 "build/gen/icl_parser.cc"
    break;

  case 57: // attr_item: attr_name value ";"
#line 348 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1176 "build/gen/icl_parser.cc"
    break;

  case 58: // attr_item: attr_name "=" value ";"
#line 351 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 1183 "build/gen/icl_parser.cc"
    break;

  case 59: // attr_item: attr_name "identifier" "=" value ";"
#line 354 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1190 "build/gen/icl_parser.cc"
    break;

  case 60: // mux_body: %empty
#line 362 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1196 "build/gen/icl_parser.cc"
    break;

  case 61: // mux_body: mux_body "comment"
#line 364 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1202 "build/gen/icl_parser.cc"
    break;

  case 62: // mux_body: mux_body value ":" value ";"
#line 366 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[3].value.as < std::string > () + " : " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1210 "build/gen/icl_parser.cc"
    break;

  case 63: // conn_body: %empty
#line 373 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1216 "build/gen/icl_parser.cc"
    break;

  case 64: // conn_body: conn_body "comment"
#line 375 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1222 "build/gen/icl_parser.cc"
    break;

  case 65: // conn_body: conn_body conn_expr ";"
#line 377 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement( yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1230 "build/gen/icl_parser.cc"
    break;

  case 66: // attr_body: %empty
#line 389 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1236 "build/gen/icl_parser.cc"
    break;

  case 67: // attr_body: attr_body "comment"
#line 391 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (),
                                       SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1244 "build/gen/icl_parser.cc"
    break;

  case 68: // attr_body: attr_body attr_item
#line 395 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 1250 "build/gen/icl_parser.cc"
    break;

  case 69: // attr_body: attr_body attr_name "{" attr_body "}"
#line 397 "src/icl_parser.yy"
      {
        AstBlock* nested = driver.MakeBlock(yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                                           SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
        yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(nested);
      }
#line 1261 "build/gen/icl_parser.cc"
    break;

  case 70: // ident_list: "identifier"
#line 408 "src/icl_parser.yy"
                           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1267 "build/gen/icl_parser.cc"
    break;

  case 71: // ident_list: ident_list "," "identifier"
#line 409 "src/icl_parser.yy"
                           { yylhs.value.as < std::string > () = std::move(yystack_[2].value.as < std::string > ()) + ", " + yystack_[0].value.as < std::string > (); }
#line 1273 "build/gen/icl_parser.cc"
    break;

  case 72: // attr_name: "identifier"
#line 421 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1279 "build/gen/icl_parser.cc"
    break;

  case 73: // attr_name: "Module"
#line 422 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Module"; }
#line 1285 "build/gen/icl_parser.cc"
    break;

  case 74: // attr_name: "Parameter"
#line 423 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Parameter"; }
#line 1291 "build/gen/icl_parser.cc"
    break;

  case 75: // attr_name: "Attribute"
#line 424 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Attribute"; }
#line 1297 "build/gen/icl_parser.cc"
    break;

  case 76: // attr_name: "Alias"
#line 425 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Alias"; }
#line 1303 "build/gen/icl_parser.cc"
    break;

  case 77: // attr_name: "Enum"
#line 426 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Enum"; }
#line 1309 "build/gen/icl_parser.cc"
    break;

  case 78: // attr_name: "ScanInPort"
#line 427 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanInPort"; }
#line 1315 "build/gen/icl_parser.cc"
    break;

  case 79: // attr_name: "ScanOutPort"
#line 428 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanOutPort"; }
#line 1321 "build/gen/icl_parser.cc"
    break;

  case 80: // attr_name: "ShiftEnPort"
#line 429 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ShiftEnPort"; }
#line 1327 "build/gen/icl_parser.cc"
    break;

  case 81: // attr_name: "CaptureEnPort"
#line 430 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "CaptureEnPort"; }
#line 1333 "build/gen/icl_parser.cc"
    break;

  case 82: // attr_name: "UpdateEnPort"
#line 431 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "UpdateEnPort"; }
#line 1339 "build/gen/icl_parser.cc"
    break;

  case 83: // attr_name: "SelectPort"
#line 432 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "SelectPort"; }
#line 1345 "build/gen/icl_parser.cc"
    break;

  case 84: // attr_name: "ResetPort"
#line 433 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ResetPort"; }
#line 1351 "build/gen/icl_parser.cc"
    break;

  case 85: // attr_name: "TCKPort"
#line 434 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "TCKPort"; }
#line 1357 "build/gen/icl_parser.cc"
    break;

  case 86: // attr_name: "TMSPort"
#line 435 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "TMSPort"; }
#line 1363 "build/gen/icl_parser.cc"
    break;

  case 87: // attr_name: "TRSTPort"
#line 436 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "TRSTPort"; }
#line 1369 "build/gen/icl_parser.cc"
    break;

  case 88: // attr_name: "ToTCKPort"
#line 437 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToTCKPort"; }
#line 1375 "build/gen/icl_parser.cc"
    break;

  case 89: // attr_name: "ToTMSPort"
#line 438 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToTMSPort"; }
#line 1381 "build/gen/icl_parser.cc"
    break;

  case 90: // attr_name: "ToTRSTPort"
#line 439 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToTRSTPort"; }
#line 1387 "build/gen/icl_parser.cc"
    break;

  case 91: // attr_name: "ToShiftEnPort"
#line 440 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToShiftEnPort"; }
#line 1393 "build/gen/icl_parser.cc"
    break;

  case 92: // attr_name: "ToCaptureEnPort"
#line 441 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToCaptureEnPort"; }
#line 1399 "build/gen/icl_parser.cc"
    break;

  case 93: // attr_name: "ToUpdateEnPort"
#line 442 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToUpdateEnPort"; }
#line 1405 "build/gen/icl_parser.cc"
    break;

  case 94: // attr_name: "ToResetPort"
#line 443 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToResetPort"; }
#line 1411 "build/gen/icl_parser.cc"
    break;

  case 95: // attr_name: "ToDoPort"
#line 444 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToDoPort"; }
#line 1417 "build/gen/icl_parser.cc"
    break;

  case 96: // attr_name: "ToSelectPort"
#line 445 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToSelectPort"; }
#line 1423 "build/gen/icl_parser.cc"
    break;

  case 97: // attr_name: "DataInPort"
#line 446 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "DataInPort"; }
#line 1429 "build/gen/icl_parser.cc"
    break;

  case 98: // attr_name: "DataOutPort"
#line 447 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "DataOutPort"; }
#line 1435 "build/gen/icl_parser.cc"
    break;

  case 99: // attr_name: "ScanInterface"
#line 448 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanInterface"; }
#line 1441 "build/gen/icl_parser.cc"
    break;

  case 100: // attr_name: "OneHotScanInterface"
#line 449 "src/icl_parser.yy"
                        { yylhs.value.as < std::string > () = "OneHotScanInterface"; }
#line 1447 "build/gen/icl_parser.cc"
    break;

  case 101: // attr_name: "ScanRegister"
#line 450 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanRegister"; }
#line 1453 "build/gen/icl_parser.cc"
    break;

  case 102: // attr_name: "Reg"
#line 451 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Reg"; }
#line 1459 "build/gen/icl_parser.cc"
    break;

  case 103: // attr_name: "Field"
#line 452 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Field"; }
#line 1465 "build/gen/icl_parser.cc"
    break;

  case 104: // attr_name: "Instance"
#line 453 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Instance"; }
#line 1471 "build/gen/icl_parser.cc"
    break;

  case 105: // attr_name: "ScanMux"
#line 454 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanMux"; }
#line 1477 "build/gen/icl_parser.cc"
    break;

  case 106: // attr_name: "SelectedBy"
#line 455 "src/icl_parser.yy"
                  { yylhs.value.as < std::string > () = "SelectedBy"; }
#line 1483 "build/gen/icl_parser.cc"
    break;

  case 107: // attr_name: "LogicSignal"
#line 456 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "LogicSignal"; }
#line 1489 "build/gen/icl_parser.cc"
    break;

  case 108: // attr_name: "Connection"
#line 457 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Connection"; }
#line 1495 "build/gen/icl_parser.cc"
    break;

  case 109: // attr_name: "PortGroup"
#line 458 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "PortGroup"; }
#line 1501 "build/gen/icl_parser.cc"
    break;

  case 110: // attr_name: "AccessLink"
#line 459 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "AccessLink"; }
#line 1507 "build/gen/icl_parser.cc"
    break;

  case 111: // attr_name: "iProcsForModule"
#line 460 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "iProcsForModule"; }
#line 1513 "build/gen/icl_parser.cc"
    break;

  case 112: // attr_name: "Of"
#line 461 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Of"; }
#line 1519 "build/gen/icl_parser.cc"
    break;

  case 113: // conn_expr: postfix
#line 467 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1525 "build/gen/icl_parser.cc"
    break;

  case 114: // conn_expr: postfix "->" postfix
#line 468 "src/icl_parser.yy"
                          { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + " -> " + yystack_[0].value.as < std::string > (); }
#line 1531 "build/gen/icl_parser.cc"
    break;

  case 115: // value: postfix
#line 472 "src/icl_parser.yy"
            { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1537 "build/gen/icl_parser.cc"
    break;

  case 116: // postfix: primary
#line 476 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1543 "build/gen/icl_parser.cc"
    break;

  case 117: // postfix: postfix "." "identifier"
#line 477 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 1549 "build/gen/icl_parser.cc"
    break;

  case 118: // postfix: postfix "." "number"
#line 478 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 1555 "build/gen/icl_parser.cc"
    break;

  case 119: // postfix: postfix "[" "number" "]"
#line 479 "src/icl_parser.yy"
                                                { yylhs.value.as < std::string > () = yystack_[3].value.as < std::string > () + "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1561 "build/gen/icl_parser.cc"
    break;

  case 120: // postfix: postfix "[" "number" ":" "number" "]"
#line 480 "src/icl_parser.yy"
                                                  { yylhs.value.as < std::string > () = yystack_[5].value.as < std::string > () + "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1567 "build/gen/icl_parser.cc"
    break;

  case 121: // primary: "identifier"
#line 484 "src/icl_parser.yy"
           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1573 "build/gen/icl_parser.cc"
    break;

  case 122: // primary: "number"
#line 485 "src/icl_parser.yy"
           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1579 "build/gen/icl_parser.cc"
    break;

  case 123: // primary: "string"
#line 486 "src/icl_parser.yy"
           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1585 "build/gen/icl_parser.cc"
    break;


#line 1589 "build/gen/icl_parser.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        context yyctx (*this, yyla);
        std::string msg = yysyntax_error_ (yyctx);
        error (yyla.location, YY_MOVE (msg));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.kind () == symbol_kind::S_YYEOF)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    // Pop stack until we find a state that shifts the error token.
    for (;;)
      {
        yyn = yypact_[+yystack_[0].state];
        if (!yy_pact_value_is_default_ (yyn))
          {
            yyn += symbol_kind::S_YYerror;
            if (0 <= yyn && yyn <= yylast_
                && yycheck_[yyn] == symbol_kind::S_YYerror)
              {
                yyn = yytable_[yyn];
                if (0 < yyn)
                  break;
              }
          }

        // Pop the current state because it cannot handle the error token.
        if (yystack_.size () == 1)
          YYABORT;

        yyerror_range[1].location = yystack_[0].location;
        yy_destroy_ ("Error: popping", yystack_[0]);
        yypop_ ();
        YY_STACK_PRINT ();
      }
    {
      stack_symbol_type error_token;

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      yy_lac_discard_ ("error recovery");
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    YY_STACK_PRINT ();
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  IclParser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  const char *
  IclParser::symbol_name (symbol_kind_type yysymbol)
  {
    static const char *const yy_sname[] =
    {
    "end of file", "error", "invalid token", "identifier", "number",
  "string", "comment", "->", "Module", "Parameter", "Attribute", "Alias",
  "Enum", "ScanInPort", "ScanOutPort", "ShiftEnPort", "CaptureEnPort",
  "UpdateEnPort", "SelectPort", "ResetPort", "TCKPort", "TMSPort",
  "TRSTPort", "ToTCKPort", "ToTMSPort", "ToTRSTPort", "ToShiftEnPort",
  "ToCaptureEnPort", "ToUpdateEnPort", "ToResetPort", "ToDoPort",
  "ToSelectPort", "DataInPort", "DataOutPort", "ScanInterface",
  "OneHotScanInterface", "ScanRegister", "Reg", "Field", "Instance",
  "ScanMux", "SelectedBy", "LogicSignal", "Connection", "PortGroup",
  "AccessLink", "iProcsForModule", "Of", "{", "}", "[", "]", ";", ":", ",",
  ".", "=", "$accept", "file", "module_def", "module_item_list",
  "module_item", "port_keyword", "opt_range", "port_decl", "attr_item",
  "mux_body", "conn_body", "attr_body", "ident_list", "attr_name",
  "conn_expr", "value", "postfix", "primary", YY_NULLPTR
    };
    return yy_sname[yysymbol];
  }



  // IclParser::context.
  IclParser::context::context (const IclParser& yyparser, const symbol_type& yyla)
    : yyparser_ (yyparser)
    , yyla_ (yyla)
  {}

  int
  IclParser::context::expected_tokens (symbol_kind_type yyarg[], int yyargn) const
  {
    // Actual number of expected tokens
    int yycount = 0;

#if YYDEBUG
    // Execute LAC once. We don't care if it is successful, we
    // only do it for the sake of debugging output.
    if (!yyparser_.yy_lac_established_)
      yyparser_.yy_lac_check_ (yyla_.kind ());
#endif

    for (int yyx = 0; yyx < YYNTOKENS; ++yyx)
      {
        symbol_kind_type yysym = YY_CAST (symbol_kind_type, yyx);
        if (yysym != symbol_kind::S_YYerror
            && yysym != symbol_kind::S_YYUNDEF
            && yyparser_.yy_lac_check_ (yysym))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = yysym;
          }
      }
    if (yyarg && yycount == 0 && 0 < yyargn)
      yyarg[0] = symbol_kind::S_YYEMPTY;
    return yycount;
  }




  bool
  IclParser::yy_lac_check_ (symbol_kind_type yytoken) const
  {
    // Logically, the yylac_stack's lifetime is confined to this function.
    // Clear it, to get rid of potential left-overs from previous call.
    yylac_stack_.clear ();
    // Reduce until we encounter a shift and thereby accept the token.
#if YYDEBUG
    YYCDEBUG << "LAC: checking lookahead " << symbol_name (yytoken) << ':';
#endif
    std::ptrdiff_t lac_top = 0;
    while (true)
      {
        state_type top_state = (yylac_stack_.empty ()
                                ? yystack_[lac_top].state
                                : yylac_stack_.back ());
        int yyrule = yypact_[+top_state];
        if (yy_pact_value_is_default_ (yyrule)
            || (yyrule += yytoken) < 0 || yylast_ < yyrule
            || yycheck_[yyrule] != yytoken)
          {
            // Use the default action.
            yyrule = yydefact_[+top_state];
            if (yyrule == 0)
              {
                YYCDEBUG << " Err\n";
                return false;
              }
          }
        else
          {
            // Use the action from yytable.
            yyrule = yytable_[yyrule];
            if (yy_table_value_is_error_ (yyrule))
              {
                YYCDEBUG << " Err\n";
                return false;
              }
            if (0 < yyrule)
              {
                YYCDEBUG << " S" << yyrule << '\n';
                return true;
              }
            yyrule = -yyrule;
          }
        // By now we know we have to simulate a reduce.
        YYCDEBUG << " R" << yyrule - 1;
        // Pop the corresponding number of values from the stack.
        {
          std::ptrdiff_t yylen = yyr2_[yyrule];
          // First pop from the LAC stack as many tokens as possible.
          std::ptrdiff_t lac_size = std::ptrdiff_t (yylac_stack_.size ());
          if (yylen < lac_size)
            {
              yylac_stack_.resize (std::size_t (lac_size - yylen));
              yylen = 0;
            }
          else if (lac_size)
            {
              yylac_stack_.clear ();
              yylen -= lac_size;
            }
          // Only afterwards look at the main stack.
          // We simulate popping elements by incrementing lac_top.
          lac_top += yylen;
        }
        // Keep top_state in sync with the updated stack.
        top_state = (yylac_stack_.empty ()
                     ? yystack_[lac_top].state
                     : yylac_stack_.back ());
        // Push the resulting state of the reduction.
        state_type state = yy_lr_goto_state_ (top_state, yyr1_[yyrule]);
        YYCDEBUG << " G" << int (state);
        yylac_stack_.push_back (state);
      }
  }

  // Establish the initial context if no initial context currently exists.
  bool
  IclParser::yy_lac_establish_ (symbol_kind_type yytoken)
  {
    /* Establish the initial context for the current lookahead if no initial
       context is currently established.

       We define a context as a snapshot of the parser stacks.  We define
       the initial context for a lookahead as the context in which the
       parser initially examines that lookahead in order to select a
       syntactic action.  Thus, if the lookahead eventually proves
       syntactically unacceptable (possibly in a later context reached via a
       series of reductions), the initial context can be used to determine
       the exact set of tokens that would be syntactically acceptable in the
       lookahead's place.  Moreover, it is the context after which any
       further semantic actions would be erroneous because they would be
       determined by a syntactically unacceptable token.

       yy_lac_establish_ should be invoked when a reduction is about to be
       performed in an inconsistent state (which, for the purposes of LAC,
       includes consistent states that don't know they're consistent because
       their default reductions have been disabled).

       For parse.lac=full, the implementation of yy_lac_establish_ is as
       follows.  If no initial context is currently established for the
       current lookahead, then check if that lookahead can eventually be
       shifted if syntactic actions continue from the current context.  */
    if (yy_lac_established_)
      return true;
    else
      {
#if YYDEBUG
        YYCDEBUG << "LAC: initial context established for "
                 << symbol_name (yytoken) << '\n';
#endif
        yy_lac_established_ = true;
        return yy_lac_check_ (yytoken);
      }
  }

  // Discard any previous initial lookahead context.
  void
  IclParser::yy_lac_discard_ (const char* event)
  {
   /* Discard any previous initial lookahead context because of Event,
      which may be a lookahead change or an invalidation of the currently
      established initial context for the current lookahead.

      The most common example of a lookahead change is a shift.  An example
      of both cases is syntax error recovery.  That is, a syntax error
      occurs when the lookahead is syntactically erroneous for the
      currently established initial context, so error recovery manipulates
      the parser stacks to try to find a new initial context in which the
      current lookahead is syntactically acceptable.  If it fails to find
      such a context, it discards the lookahead.  */
    if (yy_lac_established_)
      {
        YYCDEBUG << "LAC: initial context discarded due to "
                 << event << '\n';
        yy_lac_established_ = false;
      }
  }


  int
  IclParser::yy_syntax_error_arguments_ (const context& yyctx,
                                                 symbol_kind_type yyarg[], int yyargn) const
  {
    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
         In the first two cases, it might appear that the current syntax
         error should have been detected in the previous state when
         yy_lac_check was invoked.  However, at that time, there might
         have been a different syntax error that discarded a different
         initial context during error recovery, leaving behind the
         current lookahead.
    */

    if (!yyctx.lookahead ().empty ())
      {
        if (yyarg)
          yyarg[0] = yyctx.token ();
        int yyn = yyctx.expected_tokens (yyarg ? yyarg + 1 : yyarg, yyargn - 1);
        return yyn + 1;
      }
    return 0;
  }

  // Generate an error message.
  std::string
  IclParser::yysyntax_error_ (const context& yyctx) const
  {
    // Its maximum.
    enum { YYARGS_MAX = 5 };
    // Arguments of yyformat.
    symbol_kind_type yyarg[YYARGS_MAX];
    int yycount = yy_syntax_error_arguments_ (yyctx, yyarg, YYARGS_MAX);

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += symbol_name (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const signed char IclParser::yypact_ninf_ = -78;

  const signed char IclParser::yytable_ninf_ = -1;

  const short
  IclParser::yypact_[] =
  {
     -78,    22,   -78,   -78,     0,   -78,   -22,   -78,   682,   -78,
      32,    45,    62,    63,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,    64,    65,    66,    67,    68,
      69,    70,    71,    27,    73,    74,   -78,   -78,    75,   -78,
      23,    24,    25,    34,    35,    36,    37,    37,    37,    38,
      47,    41,   -78,    42,    39,    37,    58,    58,    58,   -78,
     -78,   -78,    87,   -25,   -12,    46,    89,    58,   -78,    11,
      91,    93,   -11,   -78,   -78,   -78,    48,   -17,   -78,    49,
      -6,   145,   190,   235,   -40,   -78,   -78,   -78,   -78,    94,
      -5,    51,   280,   -78,   -78,    53,     2,   -78,   -15,    54,
     -78,   -78,   -78,    99,    50,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,     3,   -78,   -78,   -78,   102,   325,   370,    -3,
     -78,   -78,   -78,   -78,   -78,    58,   -78,   104,   -78,   415,
       5,   -78,   -78,   460,    52,   -78,   -78,    58,    57,    59,
     -78,   -78,   -78,   -78,   505,    15,   -17,   -78,   550,   -78,
     -78,   107,   -78,    58,   595,    61,   -78,   -78,   640,   -78,
     -78,   -78,    72,   -78,    76,    77,   -78,   -78,   -78,    58,
     -78,   -78,    78,   -78
  };

  const signed char
  IclParser::yydefact_[] =
  {
       2,     0,     1,     4,     0,     3,     0,     6,     0,     8,
       0,     0,     0,     0,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     5,     7,     0,    14,
       0,     0,     0,     0,     0,     0,    51,    51,    51,     0,
       0,     0,    63,     0,     0,    51,     0,     0,     0,    66,
      66,    66,     0,     0,     0,     0,     0,     0,    66,     0,
       0,     0,     0,   121,   122,   123,     0,   115,   116,     0,
       0,     0,     0,     0,     0,    66,    18,    66,    20,     0,
       0,     0,     0,    64,    27,     0,   113,    70,     0,     0,
      66,    54,     9,     0,     0,    10,    66,    11,    72,    67,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    89,    90,    91,    92,
      93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
      13,    68,     0,    15,    16,    52,     0,     0,     0,     0,
      66,    24,    60,    26,    65,     0,    28,     0,    66,     0,
       0,   117,   118,     0,   121,    66,    56,     0,     0,     0,
      17,    19,    66,    22,     0,     0,   114,    71,     0,    55,
     119,     0,    12,     0,     0,     0,    57,    53,     0,    23,
      61,    25,     0,    29,     0,     0,    69,    58,    21,     0,
     120,    59,     0,    62
  };

  const signed char
  IclParser::yypgoto_[] =
  {
     -78,   -78,   -78,   -78,   -78,   -78,   -33,   -78,   -78,   -78,
     -78,   -66,   -78,   -78,   -78,   -67,   -77,   -78
  };

  const unsigned char
  IclParser::yydefgoto_[] =
  {
       0,     1,     5,     8,    47,    48,    73,    49,   161,   195,
      79,    91,   108,   162,   105,    86,    87,    88
  };

  const unsigned char
  IclParser::yytable_[] =
  {
      89,    90,   106,     6,    92,    93,   184,    84,    85,   175,
     101,   165,   102,   166,    83,    84,    85,   103,    83,    84,
      85,   210,     2,    95,    74,    75,     7,    96,     3,   167,
       4,   168,    82,   113,   176,    50,    97,   110,   114,   177,
      98,   111,   116,   170,   179,   192,   117,   171,    51,   193,
     183,   185,   113,   181,   182,   186,   200,   114,   201,   187,
     104,    83,    84,    85,   211,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    76,    81,    72,    77,    78,
      80,    94,   100,    99,   107,   188,   109,   169,   196,   172,
     112,   115,   178,   180,   194,   174,   189,   197,   203,   206,
     207,   214,   198,   217,     0,     0,     0,     0,     0,   204,
     205,     0,     0,     0,     0,   219,   208,   220,   212,   221,
     223,     0,     0,     0,     0,     0,   215,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   118,     0,
       0,   119,   222,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
     157,   158,   159,   118,   160,     0,   119,     0,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   118,   163,
       0,   119,     0,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
     157,   158,   159,   118,   164,     0,   119,     0,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   118,   173,
       0,   119,     0,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
     157,   158,   159,   118,   190,     0,   119,     0,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   118,   191,
       0,   119,     0,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
     157,   158,   159,   118,   199,     0,   119,     0,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   118,   202,
       0,   119,     0,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
     157,   158,   159,   118,   209,     0,   119,     0,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   118,   213,
       0,   119,     0,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
     157,   158,   159,   118,   216,     0,   119,     0,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,     9,   218,
       0,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,     0,    42,    43,    44,    45,     0,     0,
       0,    46
  };

  const short
  IclParser::yycheck_[] =
  {
      67,    68,    79,     3,    70,    71,     3,     4,     5,     7,
      77,    51,    78,    53,     3,     4,     5,     6,     3,     4,
       5,     6,     0,    48,    57,    58,    48,    52,     6,    95,
       8,    97,    65,    50,    49,     3,    48,    48,    55,    54,
      52,    52,    48,    48,   110,    48,    52,    52,     3,    52,
     116,    48,    50,     3,     4,    52,    51,    55,    53,    56,
      49,     3,     4,     5,    49,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,    48,     3,     3,     3,    56,
      56,    56,    48,    48,    48,    47,    47,    50,    41,    48,
      48,     4,     3,    47,     3,   162,     3,     3,   175,    48,
      52,    52,    48,     4,   170,    52,     4,     3,    56,    52,
      51,     4,   178,    52,    -1,    -1,    -1,    -1,    -1,   185,
     187,    -1,    -1,    -1,    -1,    53,   192,    51,   195,    52,
      52,    -1,    -1,    -1,    -1,    -1,   203,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,    -1,
      -1,     6,   219,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,     3,    49,    -1,     6,    -1,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,     3,    49,
      -1,     6,    -1,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,     3,    49,    -1,     6,    -1,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,     3,    49,
      -1,     6,    -1,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,     3,    49,    -1,     6,    -1,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,     3,    49,
      -1,     6,    -1,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,     3,    49,    -1,     6,    -1,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,     3,    49,
      -1,     6,    -1,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,     3,    49,    -1,     6,    -1,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,     3,    49,
      -1,     6,    -1,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,     3,    49,    -1,     6,    -1,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,     6,    49,
      -1,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    -1,    42,    43,    44,    45,    -1,    -1,
      -1,    49
  };

  const signed char
  IclParser::yystos_[] =
  {
       0,    58,     0,     6,     8,    59,     3,    48,    60,     6,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    42,    43,    44,    45,    49,    61,    62,    64,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,    48,     3,     3,     3,    56,    56,    56,    48,
      48,    48,    50,    63,    63,    63,    47,    41,    48,    67,
      48,    47,    63,     3,     4,     5,    72,    73,    74,    72,
      72,    68,    68,    68,     4,    48,    52,    48,    52,    47,
       3,    72,    68,     6,    49,    71,    73,     3,    69,     3,
      48,    52,    52,    50,    55,    52,    48,    52,     3,     6,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      49,    65,    70,    49,    49,    51,    53,    68,    68,     3,
      48,    52,    48,    49,    52,     7,    49,    54,    48,    68,
       4,     3,     4,    68,     3,    48,    52,    56,    72,     4,
      49,    49,    48,    52,    68,    66,    73,     3,    68,    49,
      51,    53,    49,    56,    68,    72,    52,    51,    68,    49,
       6,    49,    72,    49,     4,    72,    49,    52,    49,    53,
      51,    52,    72,    52
  };

  const signed char
  IclParser::yyr1_[] =
  {
       0,    57,    58,    58,    58,    59,    60,    60,    61,    61,
      61,    61,    61,    61,    61,    61,    61,    61,    61,    61,
      61,    61,    61,    61,    61,    61,    61,    61,    61,    61,
      62,    62,    62,    62,    62,    62,    62,    62,    62,    62,
      62,    62,    62,    62,    62,    62,    62,    62,    62,    62,
      62,    63,    63,    63,    64,    64,    65,    65,    65,    65,
      66,    66,    66,    67,    67,    67,    68,    68,    68,    68,
      69,    69,    70,    70,    70,    70,    70,    70,    70,    70,
      70,    70,    70,    70,    70,    70,    70,    70,    70,    70,
      70,    70,    70,    70,    70,    70,    70,    70,    70,    70,
      70,    70,    70,    70,    70,    70,    70,    70,    70,    70,
      70,    70,    70,    71,    71,    72,    73,    73,    73,    73,
      73,    74,    74,    74
  };

  const signed char
  IclParser::yyr2_[] =
  {
       0,     2,     0,     2,     2,     5,     0,     2,     1,     5,
       5,     5,     7,     5,     1,     5,     5,     6,     4,     6,
       4,     8,     6,     7,     5,     7,     5,     4,     5,     7,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     0,     3,     5,     4,     6,     2,     3,     4,     5,
       0,     2,     5,     0,     2,     3,     0,     2,     2,     5,
       1,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     3,     1,     1,     3,     3,     4,
       6,     1,     1,     1
  };




#if YYDEBUG
  const short
  IclParser::yyrline_[] =
  {
       0,   188,   188,   189,   191,   201,   208,   210,   215,   216,
     219,   222,   225,   229,   233,   234,   238,   242,   246,   249,
     253,   256,   260,   263,   267,   270,   277,   281,   285,   288,
     297,   298,   299,   300,   301,   302,   303,   304,   305,   306,
     307,   308,   309,   310,   311,   312,   313,   314,   315,   316,
     317,   321,   322,   323,   327,   332,   344,   347,   350,   353,
     361,   363,   365,   372,   374,   376,   388,   390,   394,   396,
     408,   409,   421,   422,   423,   424,   425,   426,   427,   428,
     429,   430,   431,   432,   433,   434,   435,   436,   437,   438,
     439,   440,   441,   442,   443,   444,   445,   446,   447,   448,
     449,   450,   451,   452,   453,   454,   455,   456,   457,   458,
     459,   460,   461,   467,   468,   472,   476,   477,   478,   479,
     480,   484,   485,   486
  };

  void
  IclParser::yy_stack_print_ () const
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  void
  IclParser::yy_reduce_print_ (int yyrule) const
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 42 "src/icl_parser.yy"
} // icl
#line 2403 "build/gen/icl_parser.cc"

#line 489 "src/icl_parser.yy"

