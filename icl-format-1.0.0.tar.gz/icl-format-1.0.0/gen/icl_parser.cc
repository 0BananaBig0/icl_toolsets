// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.





#include "icl_parser.hh"


// Unqualified %code blocks.
#line 80 "src/icl_parser.yy"

// Declared by the generated scanner (see icl_lexer.l). It must be visible at
// the parser's call site; this block lands after the parser class definition,
// so |IclParser::symbol_type| is a complete type here.
namespace icl {
IclParser::symbol_type yylex(IclDriver& driver);
}  // namespace icl
#line 89 "src/icl_parser.yy"

#include "icl_driver.h"

namespace icl {

// Reports the (first) syntax error. The driver owns the diagnostic state (it
// used to be a file-scope global); it keeps only the earliest error because
// later ones are cascades of it.
void IclParser::error(const location& loc, const std::string& message) {
  driver.SetParseDiagnostic(loc.begin.line, message);
}

}  // namespace icl

#line 69 "build/gen/icl_parser.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif


// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yy_stack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YY_USE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 48 "src/icl_parser.yy"
namespace icl {
#line 162 "build/gen/icl_parser.cc"

  /// Build a parser object.
  IclParser::IclParser (icl::IclDriver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      yy_lac_established_ (false),
      driver (driver_yyarg)
  {}

  IclParser::~IclParser ()
  {}

  IclParser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------.
  | symbol.  |
  `---------*/



  // by_state.
  IclParser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  IclParser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  IclParser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  IclParser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  IclParser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  IclParser::symbol_kind_type
  IclParser::by_state::kind () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return symbol_kind::S_YYEMPTY;
    else
      return YY_CAST (symbol_kind_type, yystos_[+state]);
  }

  IclParser::stack_symbol_type::stack_symbol_type ()
  {}

  IclParser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.YY_MOVE_OR_COPY< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_instance_block: // instance_block
      case symbol_kind::S_instance_item: // instance_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        value.YY_MOVE_OR_COPY< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_port_group_item: // port_group_item
        value.YY_MOVE_OR_COPY< icl::PortGroupItem > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_decl_name: // decl_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_onehot_block_kw: // onehot_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_std_tap_kw: // std_tap_kw
      case symbol_kind::S_of_kw: // of_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.YY_MOVE_OR_COPY< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_port_group_items: // port_group_items
        value.YY_MOVE_OR_COPY< std::vector<icl::PortGroupItem> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  IclParser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_instance_block: // instance_block
      case symbol_kind::S_instance_item: // instance_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        value.move< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_port_group_item: // port_group_item
        value.move< icl::PortGroupItem > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_decl_name: // decl_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_onehot_block_kw: // onehot_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_std_tap_kw: // std_tap_kw
      case symbol_kind::S_of_kw: // of_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_port_group_items: // port_group_items
        value.move< std::vector<icl::PortGroupItem> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.kind_ = symbol_kind::S_YYEMPTY;
  }

#if YY_CPLUSPLUS < 201103L
  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.copy< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_instance_block: // instance_block
      case symbol_kind::S_instance_item: // instance_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        value.copy< AstNode* > (that.value);
        break;

      case symbol_kind::S_port_group_item: // port_group_item
        value.copy< icl::PortGroupItem > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_decl_name: // decl_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_onehot_block_kw: // onehot_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_std_tap_kw: // std_tap_kw
      case symbol_kind::S_of_kw: // of_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.copy< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.copy< std::vector<AstNode*> > (that.value);
        break;

      case symbol_kind::S_port_group_items: // port_group_items
        value.copy< std::vector<icl::PortGroupItem> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_instance_block: // instance_block
      case symbol_kind::S_instance_item: // instance_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        value.move< AstNode* > (that.value);
        break;

      case symbol_kind::S_port_group_item: // port_group_item
        value.move< icl::PortGroupItem > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_decl_name: // decl_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_onehot_block_kw: // onehot_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_std_tap_kw: // std_tap_kw
      case symbol_kind::S_of_kw: // of_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (that.value);
        break;

      case symbol_kind::S_port_group_items: // port_group_items
        value.move< std::vector<icl::PortGroupItem> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  IclParser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  IclParser::yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YY_USE (yyoutput);
    if (yysym.empty ())
      yyo << "empty symbol";
    else
      {
        symbol_kind_type yykind = yysym.kind ();
        yyo << (yykind < YYNTOKENS ? "token" : "nterm")
            << ' ' << yysym.name () << " ("
            << yysym.location << ": ";
        switch (yykind)
    {
      case symbol_kind::S_IDENT: // "identifier"
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 550 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_NUMBER: // "number"
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 556 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_STRING: // "string"
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 562 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_COMMENT: // "comment"
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 568 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_PARAMREF: // "parameter reference"
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 574 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_IPROCARG: // "<D>/<R>"
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 580 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_OPERATOR: // "operator"
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 586 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_port_keyword: // port_keyword
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 592 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_value: // attr_value
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 598 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 604 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value_list: // value_list
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 610 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_opt_range: // opt_range
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 616 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 622 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_decl_name: // decl_name
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 628 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_name: // attr_name
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 634 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_name_block_kw: // name_block_kw
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 640 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_onehot_block_kw: // onehot_block_kw
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 646 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_range_block_kw: // range_block_kw
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 652 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_std_tap_kw: // std_tap_kw
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 658 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_of_kw: // of_kw
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 664 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_module_ref: // module_ref
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 670 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_sel_block_kw: // sel_block_kw
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 676 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_of_block_kw: // of_block_kw
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 682 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_any_keyword: // any_keyword
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 688 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value: // value
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 694 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_postfix: // postfix
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 700 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_primary: // primary
#line 249 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 706 "build/gen/icl_parser.cc"
        break;

      default:
        break;
    }
        yyo << ')';
      }
  }
#endif

  void
  IclParser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  IclParser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  IclParser::yypop_ (int n) YY_NOEXCEPT
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  IclParser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  IclParser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  IclParser::debug_level_type
  IclParser::debug_level () const
  {
    return yydebug_;
  }

  void
  IclParser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  IclParser::state_type
  IclParser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - YYNTOKENS] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - YYNTOKENS];
  }

  bool
  IclParser::yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  IclParser::yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yytable_ninf_;
  }

  int
  IclParser::operator() ()
  {
    return parse ();
  }

  int
  IclParser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

    // Discard the LAC context in case there still is one left from a
    // previous invocation.
    yy_lac_discard_ ("init");

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';
    YY_STACK_PRINT ();

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token\n";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    if (yyla.kind () == symbol_kind::S_YYerror)
    {
      // The scanner already issued an error message, process directly
      // to error recovery.  But do not keep the error token as
      // lookahead, it is too special and may lead us to an endless
      // loop in error recovery. */
      yyla.kind_ = symbol_kind::S_YYUNDEF;
      goto yyerrlab1;
    }

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.kind ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.kind ())
      {
        if (!yy_lac_establish_ (yyla.kind ()))
          goto yyerrlab;
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        if (!yy_lac_establish_ (yyla.kind ()))
          goto yyerrlab;

        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    yy_lac_discard_ ("shift");
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case symbol_kind::S_module_def: // module_def
        yylhs.value.emplace< AstBlock* > ();
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_instance_block: // instance_block
      case symbol_kind::S_instance_item: // instance_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        yylhs.value.emplace< AstNode* > ();
        break;

      case symbol_kind::S_port_group_item: // port_group_item
        yylhs.value.emplace< icl::PortGroupItem > ();
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_decl_name: // decl_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_onehot_block_kw: // onehot_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_std_tap_kw: // std_tap_kw
      case symbol_kind::S_of_kw: // of_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        yylhs.value.emplace< std::string > ();
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        yylhs.value.emplace< std::vector<AstNode*> > ();
        break;

      case symbol_kind::S_port_group_items: // port_group_items
        yylhs.value.emplace< std::vector<icl::PortGroupItem> > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 3: // file: file module_def
#line 260 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(yystack_[0].value.as < AstBlock* > ()); }
#line 1028 "build/gen/icl_parser.cc"
    break;

  case 4: // file: file ns_stmt
#line 262 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 1034 "build/gen/icl_parser.cc"
    break;

  case 5: // file: file "comment"
#line 264 "src/icl_parser.yy"
      {
        // Unlike the nested bodies below, the top-level rule has no vector to
        // append to, so the comment must be pushed onto the unit explicitly.
        driver.unit().top_level().push_back(
            driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)));
      }
#line 1045 "build/gen/icl_parser.cc"
    break;

  case 6: // file: file "#include" "string"
#line 281 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(
            driver.MakeStatement("#include " + yystack_[0].value.as < std::string > (),
                                 SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1053 "build/gen/icl_parser.cc"
    break;

  case 7: // file: file "#include" "string" ";"
#line 285 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(
            driver.MakeStatement("#include " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line))); }
#line 1061 "build/gen/icl_parser.cc"
    break;

  case 8: // module_def: "Module" decl_name "{" module_item_list "}"
#line 292 "src/icl_parser.yy"
      {
        yylhs.value.as < AstBlock* > () = driver.MakeBlock("Module " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 1069 "build/gen/icl_parser.cc"
    break;

  case 9: // module_item_list: %empty
#line 299 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1075 "build/gen/icl_parser.cc"
    break;

  case 10: // module_item_list: module_item_list module_item
#line 301 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 1081 "build/gen/icl_parser.cc"
    break;

  case 11: // module_item: "comment"
#line 305 "src/icl_parser.yy"
            { yylhs.value.as < AstNode* > () = driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)); }
#line 1087 "build/gen/icl_parser.cc"
    break;

  case 12: // module_item: "Parameter" decl_name "=" value_list ";"
#line 307 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Parameter " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1094 "build/gen/icl_parser.cc"
    break;

  case 13: // module_item: "LocalParameter" decl_name "=" value_list ";"
#line 310 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("LocalParameter " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1101 "build/gen/icl_parser.cc"
    break;

  case 14: // module_item: ns_stmt
#line 312 "src/icl_parser.yy"
            { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 1107 "build/gen/icl_parser.cc"
    break;

  case 15: // module_item: "Attribute" decl_name "=" value_list ";"
#line 314 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Attribute " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1114 "build/gen/icl_parser.cc"
    break;

  case 16: // module_item: "Attribute" decl_name ";"
#line 320 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Attribute " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1121 "build/gen/icl_parser.cc"
    break;

  case 17: // module_item: "AllowBroadcastOnScanInterface" decl_name ";"
#line 327 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("AllowBroadcastOnScanInterface " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1128 "build/gen/icl_parser.cc"
    break;

  case 18: // module_item: "Alias" decl_name opt_range "=" value_list ";"
#line 337 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Alias " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line)); }
#line 1135 "build/gen/icl_parser.cc"
    break;

  case 19: // module_item: "Alias" decl_name opt_range "=" value_list "{" attr_body "}"
#line 340 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Alias " + yystack_[6].value.as < std::string > () + yystack_[5].value.as < std::string > () + " = " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[7].location.begin.line, yystack_[0].location.end.line));
      }
#line 1144 "build/gen/icl_parser.cc"
    break;

  case 20: // module_item: name_block_kw decl_name "{" attr_body "}"
#line 349 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 1153 "build/gen/icl_parser.cc"
    break;

  case 21: // module_item: onehot_block_kw decl_name opt_range "{" attr_body "}"
#line 358 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 1162 "build/gen/icl_parser.cc"
    break;

  case 22: // module_item: range_block_kw decl_name opt_range "{" attr_body "}"
#line 363 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 1171 "build/gen/icl_parser.cc"
    break;

  case 23: // module_item: range_block_kw decl_name opt_range ";"
#line 368 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 1178 "build/gen/icl_parser.cc"
    break;

  case 24: // module_item: port_decl
#line 370 "src/icl_parser.yy"
              { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 1184 "build/gen/icl_parser.cc"
    break;

  case 25: // module_item: sel_block_kw decl_name opt_range "SelectedBy" value_list "{" mux_body "}"
#line 372 "src/icl_parser.yy"
      {
        // `SelectedBy` is part of the standard; the selector may be a
        // hierarchical name such as `MyTap.M3_sel`, hence |value_list| rather
        // than a bare IDENT — and a *list*, because Tessent writes
        // `SelectedBy config_sib_shift_reg, enable_shift_reg` when a mux is
        // selected by more than one signal.
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[7].value.as < std::string > () + " " + yystack_[6].value.as < std::string > () + yystack_[5].value.as < std::string > () + " SelectedBy " + yystack_[3].value.as < std::string > (),
                              std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[7].location.begin.line, yystack_[0].location.end.line));
      }
#line 1199 "build/gen/icl_parser.cc"
    break;

  case 26: // module_item: sel_block_kw decl_name opt_range value "{" mux_body "}"
#line 390 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[6].value.as < std::string > () + " " + yystack_[5].value.as < std::string > () + yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (),
                              std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 1209 "build/gen/icl_parser.cc"
    break;

  case 27: // module_item: instance_item
#line 396 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 1215 "build/gen/icl_parser.cc"
    break;

  case 28: // module_item: "LogicSignal" decl_name opt_range "{" logic_body "}"
#line 404 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("LogicSignal " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 1224 "build/gen/icl_parser.cc"
    break;

  case 29: // module_item: "Connection" "{" conn_body "}"
#line 409 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Connection", std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
      }
#line 1233 "build/gen/icl_parser.cc"
    break;

  case 30: // module_item: "PortGroup" decl_name "{" port_group_items "}"
#line 414 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakePortGroup(yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<icl::PortGroupItem> > ()),
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1240 "build/gen/icl_parser.cc"
    break;

  case 31: // port_keyword: "ScanInPort"
#line 421 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanInPort"; }
#line 1246 "build/gen/icl_parser.cc"
    break;

  case 32: // port_keyword: "ToIRSelectPort"
#line 427 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToIRSelectPort"; }
#line 1252 "build/gen/icl_parser.cc"
    break;

  case 33: // port_keyword: "AddressPort"
#line 428 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "AddressPort"; }
#line 1258 "build/gen/icl_parser.cc"
    break;

  case 34: // port_keyword: "WriteEnPort"
#line 429 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "WriteEnPort"; }
#line 1264 "build/gen/icl_parser.cc"
    break;

  case 35: // port_keyword: "ReadEnPort"
#line 430 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ReadEnPort"; }
#line 1270 "build/gen/icl_parser.cc"
    break;

  case 36: // port_keyword: "ScanOutPort"
#line 431 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanOutPort"; }
#line 1276 "build/gen/icl_parser.cc"
    break;

  case 37: // port_keyword: "ShiftEnPort"
#line 432 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ShiftEnPort"; }
#line 1282 "build/gen/icl_parser.cc"
    break;

  case 38: // port_keyword: "CaptureEnPort"
#line 433 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "CaptureEnPort"; }
#line 1288 "build/gen/icl_parser.cc"
    break;

  case 39: // port_keyword: "UpdateEnPort"
#line 434 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "UpdateEnPort"; }
#line 1294 "build/gen/icl_parser.cc"
    break;

  case 40: // port_keyword: "SelectPort"
#line 435 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "SelectPort"; }
#line 1300 "build/gen/icl_parser.cc"
    break;

  case 41: // port_keyword: "ResetPort"
#line 436 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ResetPort"; }
#line 1306 "build/gen/icl_parser.cc"
    break;

  case 42: // port_keyword: "TCKPort"
#line 437 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TCKPort"; }
#line 1312 "build/gen/icl_parser.cc"
    break;

  case 43: // port_keyword: "ClockPort"
#line 438 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ClockPort"; }
#line 1318 "build/gen/icl_parser.cc"
    break;

  case 44: // port_keyword: "ToClockPort"
#line 439 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToClockPort"; }
#line 1324 "build/gen/icl_parser.cc"
    break;

  case 45: // port_keyword: "TMSPort"
#line 440 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TMSPort"; }
#line 1330 "build/gen/icl_parser.cc"
    break;

  case 46: // port_keyword: "TRSTPort"
#line 441 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TRSTPort"; }
#line 1336 "build/gen/icl_parser.cc"
    break;

  case 47: // port_keyword: "ToTCKPort"
#line 442 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTCKPort"; }
#line 1342 "build/gen/icl_parser.cc"
    break;

  case 48: // port_keyword: "ToTMSPort"
#line 443 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTMSPort"; }
#line 1348 "build/gen/icl_parser.cc"
    break;

  case 49: // port_keyword: "ToTRSTPort"
#line 444 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTRSTPort"; }
#line 1354 "build/gen/icl_parser.cc"
    break;

  case 50: // port_keyword: "ToShiftEnPort"
#line 445 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToShiftEnPort"; }
#line 1360 "build/gen/icl_parser.cc"
    break;

  case 51: // port_keyword: "ToCaptureEnPort"
#line 446 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToCaptureEnPort"; }
#line 1366 "build/gen/icl_parser.cc"
    break;

  case 52: // port_keyword: "ToUpdateEnPort"
#line 447 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToUpdateEnPort"; }
#line 1372 "build/gen/icl_parser.cc"
    break;

  case 53: // port_keyword: "ToResetPort"
#line 448 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToResetPort"; }
#line 1378 "build/gen/icl_parser.cc"
    break;

  case 54: // port_keyword: "ToDoPort"
#line 449 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToDoPort"; }
#line 1384 "build/gen/icl_parser.cc"
    break;

  case 55: // port_keyword: "ToSelectPort"
#line 450 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToSelectPort"; }
#line 1390 "build/gen/icl_parser.cc"
    break;

  case 56: // port_keyword: "DataInPort"
#line 451 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataInPort"; }
#line 1396 "build/gen/icl_parser.cc"
    break;

  case 57: // port_keyword: "DataOutPort"
#line 452 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataOutPort"; }
#line 1402 "build/gen/icl_parser.cc"
    break;

  case 58: // attr_value: value_no_lead_op
#line 460 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1408 "build/gen/icl_parser.cc"
    break;

  case 59: // attr_value: "::" value_no_lead_op
#line 470 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = "::" + yystack_[0].value.as < std::string > (); }
#line 1414 "build/gen/icl_parser.cc"
    break;

  case 60: // attr_value: attr_value "," value_no_lead_op
#line 471 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = std::move(yystack_[2].value.as < std::string > ()) + ", " + yystack_[0].value.as < std::string > (); }
#line 1420 "build/gen/icl_parser.cc"
    break;

  case 61: // attr_value: attr_value "," "operator" value_no_lead_op
#line 478 "src/icl_parser.yy"
      { yylhs.value.as < std::string > () = std::move(yystack_[3].value.as < std::string > ()) + ", " + yystack_[1].value.as < std::string > () + yystack_[0].value.as < std::string > (); }
#line 1426 "build/gen/icl_parser.cc"
    break;

  case 62: // attr_value: attr_value value_no_lead_op
#line 482 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = std::move(yystack_[1].value.as < std::string > ()) + " " + yystack_[0].value.as < std::string > (); }
#line 1432 "build/gen/icl_parser.cc"
    break;

  case 63: // attr_value: attr_value "operator" value_no_lead_op
#line 489 "src/icl_parser.yy"
      { yylhs.value.as < std::string > () = std::move(yystack_[2].value.as < std::string > ()) + " " + yystack_[1].value.as < std::string > () + " " + yystack_[0].value.as < std::string > (); }
#line 1438 "build/gen/icl_parser.cc"
    break;

  case 64: // value_no_lead_op: postfix
#line 493 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1444 "build/gen/icl_parser.cc"
    break;

  case 65: // value_no_lead_op: value_no_lead_op "::" postfix
#line 497 "src/icl_parser.yy"
                                    { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "::" + yystack_[0].value.as < std::string > (); }
#line 1450 "build/gen/icl_parser.cc"
    break;

  case 66: // logic_body: %empty
#line 505 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1456 "build/gen/icl_parser.cc"
    break;

  case 67: // logic_body: logic_body "comment"
#line 507 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (),
                                       SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1464 "build/gen/icl_parser.cc"
    break;

  case 68: // logic_body: logic_body value_list ";"
#line 511 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1472 "build/gen/icl_parser.cc"
    break;

  case 69: // logic_body: logic_body attr_name "=" value_list ";"
#line 515 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1480 "build/gen/icl_parser.cc"
    break;

  case 70: // logic_body: logic_body attr_name value_no_lead_op ";"
#line 523 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[3].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line))); }
#line 1488 "build/gen/icl_parser.cc"
    break;

  case 71: // logic_body: logic_body attr_name "{" attr_body "}"
#line 527 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeBlock(yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                                      SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1496 "build/gen/icl_parser.cc"
    break;

  case 72: // value_list: value
#line 540 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1502 "build/gen/icl_parser.cc"
    break;

  case 73: // value_list: value_list "," value
#line 541 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = std::move(yystack_[2].value.as < std::string > ()) + ", " + yystack_[0].value.as < std::string > (); }
#line 1508 "build/gen/icl_parser.cc"
    break;

  case 74: // opt_range: %empty
#line 549 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = std::string(); }
#line 1514 "build/gen/icl_parser.cc"
    break;

  case 75: // opt_range: "[" value "]"
#line 550 "src/icl_parser.yy"
                                       { yylhs.value.as < std::string > () = "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1520 "build/gen/icl_parser.cc"
    break;

  case 76: // opt_range: "[" value ":" value "]"
#line 551 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1526 "build/gen/icl_parser.cc"
    break;

  case 77: // port_decl: port_keyword decl_name opt_range ";"
#line 556 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
      }
#line 1535 "build/gen/icl_parser.cc"
    break;

  case 78: // port_decl: port_keyword decl_name opt_range "{" attr_body "}"
#line 561 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 1543 "build/gen/icl_parser.cc"
    break;

  case 79: // attr_item: attr_stmt_name ";"
#line 573 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1550 "build/gen/icl_parser.cc"
    break;

  case 80: // attr_item: attr_name attr_value ";"
#line 584 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1557 "build/gen/icl_parser.cc"
    break;

  case 81: // attr_item: attr_name "operator" value_list ";"
#line 590 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 1564 "build/gen/icl_parser.cc"
    break;

  case 82: // attr_item: attr_name "=" value_list ";"
#line 595 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 1571 "build/gen/icl_parser.cc"
    break;

  case 83: // attr_item: attr_name postfix "=" value_list ";"
#line 613 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1578 "build/gen/icl_parser.cc"
    break;

  case 84: // attr_item: instance_item
#line 629 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 1584 "build/gen/icl_parser.cc"
    break;

  case 85: // attr_item: attr_name postfix "{" attr_body "}"
#line 638 "src/icl_parser.yy"
      {
        // `postfix`, not `IDENT opt_range`: the name may be indexed
        // (`Field f[3:0] { ... }`), and using the same nonterminal as an
        // expression means the parser decides between "block" and
        // "statement" at `{` versus `;` — one token. Spelling it
        // `IDENT opt_range` instead makes it decide at `[`, which is one
        // token too early, and that is a real shift/reduce conflict: both
        // `Source a[3:0];` and `Field f[3:0] { }` start the same way.
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 1600 "build/gen/icl_parser.cc"
    break;

  case 86: // mux_body: %empty
#line 655 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1606 "build/gen/icl_parser.cc"
    break;

  case 87: // mux_body: mux_body "comment"
#line 657 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1612 "build/gen/icl_parser.cc"
    break;

  case 88: // mux_body: mux_body value_list ":" value_list ";"
#line 662 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[3].value.as < std::string > () + " : " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1620 "build/gen/icl_parser.cc"
    break;

  case 89: // mux_body: mux_body value ";"
#line 668 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1628 "build/gen/icl_parser.cc"
    break;

  case 90: // mux_body: mux_body attr_name "=" value_list ";"
#line 679 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1636 "build/gen/icl_parser.cc"
    break;

  case 91: // mux_body: mux_body attr_name "identifier" "=" value_list ";"
#line 685 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[5].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line))); }
#line 1644 "build/gen/icl_parser.cc"
    break;

  case 92: // conn_body: %empty
#line 692 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1650 "build/gen/icl_parser.cc"
    break;

  case 93: // conn_body: conn_body "comment"
#line 694 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1656 "build/gen/icl_parser.cc"
    break;

  case 94: // conn_body: conn_body value_list ";"
#line 696 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1664 "build/gen/icl_parser.cc"
    break;

  case 95: // attr_body: %empty
#line 708 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1670 "build/gen/icl_parser.cc"
    break;

  case 96: // attr_body: attr_body "comment"
#line 710 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (),
                                       SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1678 "build/gen/icl_parser.cc"
    break;

  case 97: // attr_body: attr_body attr_item
#line 714 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 1684 "build/gen/icl_parser.cc"
    break;

  case 98: // attr_body: attr_body attr_name "{" attr_body "}"
#line 716 "src/icl_parser.yy"
      {
        AstBlock* nested = driver.MakeBlock(yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                                           SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
        yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(nested);
      }
#line 1695 "build/gen/icl_parser.cc"
    break;

  case 99: // port_group_items: port_group_item
#line 746 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<icl::PortGroupItem> > () = std::vector<icl::PortGroupItem>(); yylhs.value.as < std::vector<icl::PortGroupItem> > ().push_back(std::move(yystack_[0].value.as < icl::PortGroupItem > ())); }
#line 1701 "build/gen/icl_parser.cc"
    break;

  case 100: // port_group_items: port_group_items port_group_item
#line 748 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<icl::PortGroupItem> > () = std::move(yystack_[1].value.as < std::vector<icl::PortGroupItem> > ()); yylhs.value.as < std::vector<icl::PortGroupItem> > ().push_back(std::move(yystack_[0].value.as < icl::PortGroupItem > ())); }
#line 1707 "build/gen/icl_parser.cc"
    break;

  case 101: // port_group_item: decl_name opt_range
#line 753 "src/icl_parser.yy"
      { yylhs.value.as < icl::PortGroupItem > () = icl::PortGroupItem::Name(yystack_[1].value.as < std::string > () + yystack_[0].value.as < std::string > (),
                                      SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1714 "build/gen/icl_parser.cc"
    break;

  case 102: // port_group_item: "comment"
#line 756 "src/icl_parser.yy"
      { yylhs.value.as < icl::PortGroupItem > () = icl::PortGroupItem::Comment(
            driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)),
            SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)); }
#line 1722 "build/gen/icl_parser.cc"
    break;

  case 103: // port_group_item: ","
#line 760 "src/icl_parser.yy"
      { yylhs.value.as < icl::PortGroupItem > () = icl::PortGroupItem::Comma(); }
#line 1728 "build/gen/icl_parser.cc"
    break;

  case 104: // attr_stmt_name: any_keyword
#line 782 "src/icl_parser.yy"
                { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1734 "build/gen/icl_parser.cc"
    break;

  case 105: // attr_stmt_name: postfix
#line 783 "src/icl_parser.yy"
                { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1740 "build/gen/icl_parser.cc"
    break;

  case 106: // decl_name: "identifier"
#line 805 "src/icl_parser.yy"
                 { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1746 "build/gen/icl_parser.cc"
    break;

  case 107: // decl_name: any_keyword
#line 806 "src/icl_parser.yy"
                 { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1752 "build/gen/icl_parser.cc"
    break;

  case 108: // attr_name: "identifier"
#line 810 "src/icl_parser.yy"
                 { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1758 "build/gen/icl_parser.cc"
    break;

  case 109: // attr_name: any_keyword
#line 811 "src/icl_parser.yy"
                 { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1764 "build/gen/icl_parser.cc"
    break;

  case 110: // instance_block: of_block_kw "identifier" of_kw module_ref "{" attr_body "}"
#line 823 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[6].value.as < std::string > () + " " + yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 1773 "build/gen/icl_parser.cc"
    break;

  case 111: // instance_item: instance_block
#line 831 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 1779 "build/gen/icl_parser.cc"
    break;

  case 112: // instance_item: of_block_kw "identifier" of_kw module_ref ";"
#line 833 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1786 "build/gen/icl_parser.cc"
    break;

  case 113: // name_block_kw: "Enum"
#line 842 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Enum"; }
#line 1792 "build/gen/icl_parser.cc"
    break;

  case 114: // name_block_kw: "ScanInterface"
#line 843 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ScanInterface"; }
#line 1798 "build/gen/icl_parser.cc"
    break;

  case 115: // onehot_block_kw: "OneHotScanInterface"
#line 847 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "OneHotScanInterface"; }
#line 1804 "build/gen/icl_parser.cc"
    break;

  case 116: // onehot_block_kw: "OneHotScanGroup"
#line 848 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "OneHotScanGroup"; }
#line 1810 "build/gen/icl_parser.cc"
    break;

  case 117: // onehot_block_kw: "OneHotDataGroup"
#line 849 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "OneHotDataGroup"; }
#line 1816 "build/gen/icl_parser.cc"
    break;

  case 118: // range_block_kw: "ScanRegister"
#line 853 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ScanRegister"; }
#line 1822 "build/gen/icl_parser.cc"
    break;

  case 119: // range_block_kw: "DataRegister"
#line 854 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "DataRegister"; }
#line 1828 "build/gen/icl_parser.cc"
    break;

  case 120: // range_block_kw: "Reg"
#line 855 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Reg"; }
#line 1834 "build/gen/icl_parser.cc"
    break;

  case 121: // range_block_kw: "Field"
#line 856 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Field"; }
#line 1840 "build/gen/icl_parser.cc"
    break;

  case 122: // ns_stmt: "NameSpace" ";"
#line 863 "src/icl_parser.yy"
                                 { yylhs.value.as < AstNode* > () = driver.MakeStatement("NameSpace;",
                                     SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1847 "build/gen/icl_parser.cc"
    break;

  case 123: // ns_stmt: "NameSpace" "identifier" ";"
#line 865 "src/icl_parser.yy"
                                 { yylhs.value.as < AstNode* > () = driver.MakeStatement("NameSpace " + yystack_[1].value.as < std::string > () + ";",
                                     SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1854 "build/gen/icl_parser.cc"
    break;

  case 124: // ns_stmt: "UseNameSpace" ";"
#line 867 "src/icl_parser.yy"
                                 { yylhs.value.as < AstNode* > () = driver.MakeStatement("UseNameSpace;",
                                     SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1861 "build/gen/icl_parser.cc"
    break;

  case 125: // ns_stmt: "UseNameSpace" "identifier" ";"
#line 869 "src/icl_parser.yy"
                                 { yylhs.value.as < AstNode* > () = driver.MakeStatement("UseNameSpace " + yystack_[1].value.as < std::string > () + ";",
                                     SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1868 "build/gen/icl_parser.cc"
    break;

  case 126: // std_tap_kw: "STD_1149_1_2001"
#line 888 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "STD_1149_1_2001"; }
#line 1874 "build/gen/icl_parser.cc"
    break;

  case 127: // std_tap_kw: "STD_1149_1_2013"
#line 889 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "STD_1149_1_2013"; }
#line 1880 "build/gen/icl_parser.cc"
    break;

  case 128: // of_kw: "Of"
#line 908 "src/icl_parser.yy"
            { yylhs.value.as < std::string > () = "Of"; }
#line 1886 "build/gen/icl_parser.cc"
    break;

  case 129: // of_kw: "of"
#line 909 "src/icl_parser.yy"
            { yylhs.value.as < std::string > () = "of"; }
#line 1892 "build/gen/icl_parser.cc"
    break;

  case 130: // module_ref: "identifier"
#line 913 "src/icl_parser.yy"
                             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1898 "build/gen/icl_parser.cc"
    break;

  case 131: // module_ref: std_tap_kw
#line 914 "src/icl_parser.yy"
                             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1904 "build/gen/icl_parser.cc"
    break;

  case 132: // module_ref: module_ref "::" "identifier"
#line 915 "src/icl_parser.yy"
                             { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "::" + yystack_[0].value.as < std::string > (); }
#line 1910 "build/gen/icl_parser.cc"
    break;

  case 133: // module_ref: "::" "identifier"
#line 926 "src/icl_parser.yy"
                             { yylhs.value.as < std::string > () = "::" + yystack_[0].value.as < std::string > (); }
#line 1916 "build/gen/icl_parser.cc"
    break;

  case 134: // sel_block_kw: "ScanMux"
#line 931 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ScanMux"; }
#line 1922 "build/gen/icl_parser.cc"
    break;

  case 135: // sel_block_kw: "DataMux"
#line 932 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "DataMux"; }
#line 1928 "build/gen/icl_parser.cc"
    break;

  case 136: // sel_block_kw: "ClockMux"
#line 933 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ClockMux"; }
#line 1934 "build/gen/icl_parser.cc"
    break;

  case 137: // of_block_kw: "Instance"
#line 937 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Instance"; }
#line 1940 "build/gen/icl_parser.cc"
    break;

  case 138: // of_block_kw: "AccessLink"
#line 938 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "AccessLink"; }
#line 1946 "build/gen/icl_parser.cc"
    break;

  case 139: // any_keyword: name_block_kw
#line 944 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1952 "build/gen/icl_parser.cc"
    break;

  case 140: // any_keyword: onehot_block_kw
#line 945 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1958 "build/gen/icl_parser.cc"
    break;

  case 141: // any_keyword: range_block_kw
#line 946 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1964 "build/gen/icl_parser.cc"
    break;

  case 142: // any_keyword: sel_block_kw
#line 947 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1970 "build/gen/icl_parser.cc"
    break;

  case 143: // any_keyword: port_keyword
#line 953 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1976 "build/gen/icl_parser.cc"
    break;

  case 144: // any_keyword: "Module"
#line 954 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Module"; }
#line 1982 "build/gen/icl_parser.cc"
    break;

  case 145: // any_keyword: "Parameter"
#line 955 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Parameter"; }
#line 1988 "build/gen/icl_parser.cc"
    break;

  case 146: // any_keyword: "Attribute"
#line 956 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Attribute"; }
#line 1994 "build/gen/icl_parser.cc"
    break;

  case 147: // any_keyword: "AllowBroadcastOnScanInterface"
#line 957 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "AllowBroadcastOnScanInterface"; }
#line 2000 "build/gen/icl_parser.cc"
    break;

  case 148: // any_keyword: "AccessTogether"
#line 958 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "AccessTogether"; }
#line 2006 "build/gen/icl_parser.cc"
    break;

  case 149: // any_keyword: "ActivePolarity"
#line 959 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "ActivePolarity"; }
#line 2012 "build/gen/icl_parser.cc"
    break;

  case 150: // any_keyword: "ActiveSignals"
#line 960 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "ActiveSignals"; }
#line 2018 "build/gen/icl_parser.cc"
    break;

  case 151: // any_keyword: "AddressValue"
#line 961 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "AddressValue"; }
#line 2024 "build/gen/icl_parser.cc"
    break;

  case 152: // any_keyword: "BSDLEntity"
#line 962 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "BSDLEntity"; }
#line 2030 "build/gen/icl_parser.cc"
    break;

  case 153: // any_keyword: "CaptureSource"
#line 963 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "CaptureSource"; }
#line 2036 "build/gen/icl_parser.cc"
    break;

  case 154: // any_keyword: "Chain"
#line 964 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Chain"; }
#line 2042 "build/gen/icl_parser.cc"
    break;

  case 155: // any_keyword: "DefaultLoadValue"
#line 965 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DefaultLoadValue"; }
#line 2048 "build/gen/icl_parser.cc"
    break;

  case 156: // any_keyword: "DifferentialInvOf"
#line 966 "src/icl_parser.yy"
                      { yylhs.value.as < std::string > () = "DifferentialInvOf"; }
#line 2054 "build/gen/icl_parser.cc"
    break;

  case 157: // any_keyword: "Enable"
#line 967 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Enable"; }
#line 2060 "build/gen/icl_parser.cc"
    break;

  case 158: // any_keyword: "FreqDivider"
#line 968 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "FreqDivider"; }
#line 2066 "build/gen/icl_parser.cc"
    break;

  case 159: // any_keyword: "FreqMultiplier"
#line 969 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "FreqMultiplier"; }
#line 2072 "build/gen/icl_parser.cc"
    break;

  case 160: // any_keyword: "Period"
#line 970 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Period"; }
#line 2078 "build/gen/icl_parser.cc"
    break;

  case 161: // any_keyword: "InputPort"
#line 971 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "InputPort"; }
#line 2084 "build/gen/icl_parser.cc"
    break;

  case 162: // any_keyword: "Port"
#line 972 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Port"; }
#line 2090 "build/gen/icl_parser.cc"
    break;

  case 163: // any_keyword: "ReadCallBack"
#line 973 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "ReadCallBack"; }
#line 2096 "build/gen/icl_parser.cc"
    break;

  case 164: // any_keyword: "ReadDataSource"
#line 974 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "ReadDataSource"; }
#line 2102 "build/gen/icl_parser.cc"
    break;

  case 165: // any_keyword: "RefEnum"
#line 975 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "RefEnum"; }
#line 2108 "build/gen/icl_parser.cc"
    break;

  case 166: // any_keyword: "ResetValue"
#line 976 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "ResetValue"; }
#line 2114 "build/gen/icl_parser.cc"
    break;

  case 167: // any_keyword: "STD_1149_1_2001"
#line 977 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "STD_1149_1_2001"; }
#line 2120 "build/gen/icl_parser.cc"
    break;

  case 168: // any_keyword: "STD_1149_1_2013"
#line 978 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "STD_1149_1_2013"; }
#line 2126 "build/gen/icl_parser.cc"
    break;

  case 169: // any_keyword: "ScanInSource"
#line 979 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "ScanInSource"; }
#line 2132 "build/gen/icl_parser.cc"
    break;

  case 170: // any_keyword: "Source"
#line 980 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Source"; }
#line 2138 "build/gen/icl_parser.cc"
    break;

  case 171: // any_keyword: "WriteCallBack"
#line 981 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "WriteCallBack"; }
#line 2144 "build/gen/icl_parser.cc"
    break;

  case 172: // any_keyword: "WriteDataSource"
#line 982 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "WriteDataSource"; }
#line 2150 "build/gen/icl_parser.cc"
    break;

  case 173: // any_keyword: "WriteEnSource"
#line 983 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "WriteEnSource"; }
#line 2156 "build/gen/icl_parser.cc"
    break;

  case 174: // any_keyword: "iApplyEndState"
#line 984 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "iApplyEndState"; }
#line 2162 "build/gen/icl_parser.cc"
    break;

  case 175: // any_keyword: "Alias"
#line 985 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Alias"; }
#line 2168 "build/gen/icl_parser.cc"
    break;

  case 176: // any_keyword: "SelectedBy"
#line 986 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "SelectedBy"; }
#line 2174 "build/gen/icl_parser.cc"
    break;

  case 177: // any_keyword: "LogicSignal"
#line 987 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "LogicSignal"; }
#line 2180 "build/gen/icl_parser.cc"
    break;

  case 178: // any_keyword: "Connection"
#line 988 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Connection"; }
#line 2186 "build/gen/icl_parser.cc"
    break;

  case 179: // any_keyword: "PortGroup"
#line 989 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "PortGroup"; }
#line 2192 "build/gen/icl_parser.cc"
    break;

  case 180: // any_keyword: "Of"
#line 990 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Of"; }
#line 2198 "build/gen/icl_parser.cc"
    break;

  case 181: // any_keyword: "of"
#line 991 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "of"; }
#line 2204 "build/gen/icl_parser.cc"
    break;

  case 182: // any_keyword: "LocalParameter"
#line 992 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "LocalParameter"; }
#line 2210 "build/gen/icl_parser.cc"
    break;

  case 183: // any_keyword: "NameSpace"
#line 993 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "NameSpace"; }
#line 2216 "build/gen/icl_parser.cc"
    break;

  case 184: // any_keyword: "UseNameSpace"
#line 994 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "UseNameSpace"; }
#line 2222 "build/gen/icl_parser.cc"
    break;

  case 185: // value: postfix
#line 1000 "src/icl_parser.yy"
            { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 2228 "build/gen/icl_parser.cc"
    break;

  case 186: // value: postfix "->" postfix
#line 1004 "src/icl_parser.yy"
                          { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + " -> " + yystack_[0].value.as < std::string > (); }
#line 2234 "build/gen/icl_parser.cc"
    break;

  case 187: // value: "operator" value
#line 1006 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = yystack_[1].value.as < std::string > () + yystack_[0].value.as < std::string > (); }
#line 2240 "build/gen/icl_parser.cc"
    break;

  case 188: // value: value "operator" value
#line 1009 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + " " + yystack_[0].value.as < std::string > (); }
#line 2246 "build/gen/icl_parser.cc"
    break;

  case 189: // value: "(" value_list ")"
#line 1010 "src/icl_parser.yy"
                             { yylhs.value.as < std::string > () = "(" + yystack_[1].value.as < std::string > () + ")"; }
#line 2252 "build/gen/icl_parser.cc"
    break;

  case 190: // postfix: primary
#line 1014 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 2258 "build/gen/icl_parser.cc"
    break;

  case 191: // postfix: postfix "." "identifier"
#line 1015 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 2264 "build/gen/icl_parser.cc"
    break;

  case 192: // postfix: postfix "[" value "]"
#line 1018 "src/icl_parser.yy"
      { yylhs.value.as < std::string > () = yystack_[3].value.as < std::string > () + "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 2270 "build/gen/icl_parser.cc"
    break;

  case 193: // postfix: postfix "[" value ":" value "]"
#line 1020 "src/icl_parser.yy"
      { yylhs.value.as < std::string > () = yystack_[5].value.as < std::string > () + "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 2276 "build/gen/icl_parser.cc"
    break;

  case 194: // primary: "identifier"
#line 1024 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 2282 "build/gen/icl_parser.cc"
    break;

  case 195: // primary: "number"
#line 1025 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 2288 "build/gen/icl_parser.cc"
    break;

  case 196: // primary: "string"
#line 1026 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 2294 "build/gen/icl_parser.cc"
    break;

  case 197: // primary: "parameter reference"
#line 1027 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 2300 "build/gen/icl_parser.cc"
    break;

  case 198: // primary: "<D>/<R>"
#line 1029 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 2306 "build/gen/icl_parser.cc"
    break;


#line 2310 "build/gen/icl_parser.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        context yyctx (*this, yyla);
        std::string msg = yysyntax_error_ (yyctx);
        error (yyla.location, YY_MOVE (msg));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.kind () == symbol_kind::S_YYEOF)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    // Pop stack until we find a state that shifts the error token.
    for (;;)
      {
        yyn = yypact_[+yystack_[0].state];
        if (!yy_pact_value_is_default_ (yyn))
          {
            yyn += symbol_kind::S_YYerror;
            if (0 <= yyn && yyn <= yylast_
                && yycheck_[yyn] == symbol_kind::S_YYerror)
              {
                yyn = yytable_[yyn];
                if (0 < yyn)
                  break;
              }
          }

        // Pop the current state because it cannot handle the error token.
        if (yystack_.size () == 1)
          YYABORT;

        yyerror_range[1].location = yystack_[0].location;
        yy_destroy_ ("Error: popping", yystack_[0]);
        yypop_ ();
        YY_STACK_PRINT ();
      }
    {
      stack_symbol_type error_token;

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      yy_lac_discard_ ("error recovery");
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    YY_STACK_PRINT ();
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  IclParser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  const char *
  IclParser::symbol_name (symbol_kind_type yysymbol)
  {
    static const char *const yy_sname[] =
    {
    "end of file", "error", "invalid token", "identifier", "number",
  "string", "comment", "parameter reference", "<D>/<R>", "::",
  "ToIRSelectPort", "AddressPort", "WriteEnPort", "ReadEnPort",
  "NameSpace", "UseNameSpace", "LocalParameter", "->", "operator", "(",
  ")", "Module", "Parameter", "Attribute", "AllowBroadcastOnScanInterface",
  "AccessTogether", "ActivePolarity", "ActiveSignals", "AddressValue",
  "BSDLEntity", "CaptureSource", "Chain", "DefaultLoadValue",
  "DifferentialInvOf", "Enable", "FreqDivider", "FreqMultiplier", "Period",
  "InputPort", "Port", "ReadCallBack", "ReadDataSource", "RefEnum",
  "ResetValue", "STD_1149_1_2001", "STD_1149_1_2013", "ScanInSource",
  "Source", "WriteCallBack", "WriteDataSource", "WriteEnSource",
  "iApplyEndState", "Alias", "Enum", "ScanInPort", "ScanOutPort",
  "ShiftEnPort", "CaptureEnPort", "UpdateEnPort", "SelectPort",
  "ResetPort", "ClockPort", "ToClockPort", "TCKPort", "TMSPort",
  "TRSTPort", "ToTCKPort", "ToTMSPort", "ToTRSTPort", "ToShiftEnPort",
  "ToCaptureEnPort", "ToUpdateEnPort", "ToResetPort", "ToDoPort",
  "ToSelectPort", "DataInPort", "DataOutPort", "ScanInterface",
  "OneHotScanInterface", "ScanRegister", "DataRegister", "Reg", "Field",
  "Instance", "ScanMux", "DataMux", "ClockMux", "OneHotScanGroup",
  "OneHotDataGroup", "SelectedBy", "LogicSignal", "Connection",
  "PortGroup", "AccessLink", "Of", "of", "#include", "{", "}", "[", "]",
  ";", ":", ",", ".", "=", "$accept", "file", "module_def",
  "module_item_list", "module_item", "port_keyword", "attr_value",
  "value_no_lead_op", "logic_body", "value_list", "opt_range", "port_decl",
  "attr_item", "mux_body", "conn_body", "attr_body", "port_group_items",
  "port_group_item", "attr_stmt_name", "decl_name", "attr_name",
  "instance_block", "instance_item", "name_block_kw", "onehot_block_kw",
  "range_block_kw", "ns_stmt", "std_tap_kw", "of_kw", "module_ref",
  "sel_block_kw", "of_block_kw", "any_keyword", "value", "postfix",
  "primary", YY_NULLPTR
    };
    return yy_sname[yysymbol];
  }



  // IclParser::context.
  IclParser::context::context (const IclParser& yyparser, const symbol_type& yyla)
    : yyparser_ (yyparser)
    , yyla_ (yyla)
  {}

  int
  IclParser::context::expected_tokens (symbol_kind_type yyarg[], int yyargn) const
  {
    // Actual number of expected tokens
    int yycount = 0;

#if YYDEBUG
    // Execute LAC once. We don't care if it is successful, we
    // only do it for the sake of debugging output.
    if (!yyparser_.yy_lac_established_)
      yyparser_.yy_lac_check_ (yyla_.kind ());
#endif

    for (int yyx = 0; yyx < YYNTOKENS; ++yyx)
      {
        symbol_kind_type yysym = YY_CAST (symbol_kind_type, yyx);
        if (yysym != symbol_kind::S_YYerror
            && yysym != symbol_kind::S_YYUNDEF
            && yyparser_.yy_lac_check_ (yysym))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = yysym;
          }
      }
    if (yyarg && yycount == 0 && 0 < yyargn)
      yyarg[0] = symbol_kind::S_YYEMPTY;
    return yycount;
  }




  bool
  IclParser::yy_lac_check_ (symbol_kind_type yytoken) const
  {
    // Logically, the yylac_stack's lifetime is confined to this function.
    // Clear it, to get rid of potential left-overs from previous call.
    yylac_stack_.clear ();
    // Reduce until we encounter a shift and thereby accept the token.
#if YYDEBUG
    YYCDEBUG << "LAC: checking lookahead " << symbol_name (yytoken) << ':';
#endif
    std::ptrdiff_t lac_top = 0;
    while (true)
      {
        state_type top_state = (yylac_stack_.empty ()
                                ? yystack_[lac_top].state
                                : yylac_stack_.back ());
        int yyrule = yypact_[+top_state];
        if (yy_pact_value_is_default_ (yyrule)
            || (yyrule += yytoken) < 0 || yylast_ < yyrule
            || yycheck_[yyrule] != yytoken)
          {
            // Use the default action.
            yyrule = yydefact_[+top_state];
            if (yyrule == 0)
              {
                YYCDEBUG << " Err\n";
                return false;
              }
          }
        else
          {
            // Use the action from yytable.
            yyrule = yytable_[yyrule];
            if (yy_table_value_is_error_ (yyrule))
              {
                YYCDEBUG << " Err\n";
                return false;
              }
            if (0 < yyrule)
              {
                YYCDEBUG << " S" << yyrule << '\n';
                return true;
              }
            yyrule = -yyrule;
          }
        // By now we know we have to simulate a reduce.
        YYCDEBUG << " R" << yyrule - 1;
        // Pop the corresponding number of values from the stack.
        {
          std::ptrdiff_t yylen = yyr2_[yyrule];
          // First pop from the LAC stack as many tokens as possible.
          std::ptrdiff_t lac_size = std::ptrdiff_t (yylac_stack_.size ());
          if (yylen < lac_size)
            {
              yylac_stack_.resize (std::size_t (lac_size - yylen));
              yylen = 0;
            }
          else if (lac_size)
            {
              yylac_stack_.clear ();
              yylen -= lac_size;
            }
          // Only afterwards look at the main stack.
          // We simulate popping elements by incrementing lac_top.
          lac_top += yylen;
        }
        // Keep top_state in sync with the updated stack.
        top_state = (yylac_stack_.empty ()
                     ? yystack_[lac_top].state
                     : yylac_stack_.back ());
        // Push the resulting state of the reduction.
        state_type state = yy_lr_goto_state_ (top_state, yyr1_[yyrule]);
        YYCDEBUG << " G" << int (state);
        yylac_stack_.push_back (state);
      }
  }

  // Establish the initial context if no initial context currently exists.
  bool
  IclParser::yy_lac_establish_ (symbol_kind_type yytoken)
  {
    /* Establish the initial context for the current lookahead if no initial
       context is currently established.

       We define a context as a snapshot of the parser stacks.  We define
       the initial context for a lookahead as the context in which the
       parser initially examines that lookahead in order to select a
       syntactic action.  Thus, if the lookahead eventually proves
       syntactically unacceptable (possibly in a later context reached via a
       series of reductions), the initial context can be used to determine
       the exact set of tokens that would be syntactically acceptable in the
       lookahead's place.  Moreover, it is the context after which any
       further semantic actions would be erroneous because they would be
       determined by a syntactically unacceptable token.

       yy_lac_establish_ should be invoked when a reduction is about to be
       performed in an inconsistent state (which, for the purposes of LAC,
       includes consistent states that don't know they're consistent because
       their default reductions have been disabled).

       For parse.lac=full, the implementation of yy_lac_establish_ is as
       follows.  If no initial context is currently established for the
       current lookahead, then check if that lookahead can eventually be
       shifted if syntactic actions continue from the current context.  */
    if (yy_lac_established_)
      return true;
    else
      {
#if YYDEBUG
        YYCDEBUG << "LAC: initial context established for "
                 << symbol_name (yytoken) << '\n';
#endif
        yy_lac_established_ = true;
        return yy_lac_check_ (yytoken);
      }
  }

  // Discard any previous initial lookahead context.
  void
  IclParser::yy_lac_discard_ (const char* event)
  {
   /* Discard any previous initial lookahead context because of Event,
      which may be a lookahead change or an invalidation of the currently
      established initial context for the current lookahead.

      The most common example of a lookahead change is a shift.  An example
      of both cases is syntax error recovery.  That is, a syntax error
      occurs when the lookahead is syntactically erroneous for the
      currently established initial context, so error recovery manipulates
      the parser stacks to try to find a new initial context in which the
      current lookahead is syntactically acceptable.  If it fails to find
      such a context, it discards the lookahead.  */
    if (yy_lac_established_)
      {
        YYCDEBUG << "LAC: initial context discarded due to "
                 << event << '\n';
        yy_lac_established_ = false;
      }
  }


  int
  IclParser::yy_syntax_error_arguments_ (const context& yyctx,
                                                 symbol_kind_type yyarg[], int yyargn) const
  {
    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
         In the first two cases, it might appear that the current syntax
         error should have been detected in the previous state when
         yy_lac_check was invoked.  However, at that time, there might
         have been a different syntax error that discarded a different
         initial context during error recovery, leaving behind the
         current lookahead.
    */

    if (!yyctx.lookahead ().empty ())
      {
        if (yyarg)
          yyarg[0] = yyctx.token ();
        int yyn = yyctx.expected_tokens (yyarg ? yyarg + 1 : yyarg, yyargn - 1);
        return yyn + 1;
      }
    return 0;
  }

  // Generate an error message.
  std::string
  IclParser::yysyntax_error_ (const context& yyctx) const
  {
    // Its maximum.
    enum { YYARGS_MAX = 5 };
    // Arguments of yyformat.
    symbol_kind_type yyarg[YYARGS_MAX];
    int yycount = yy_syntax_error_arguments_ (yyctx, yyarg, YYARGS_MAX);

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += symbol_name (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short IclParser::yypact_ninf_ = -180;

  const short IclParser::yytable_ninf_ = -195;

  const short
  IclParser::yypact_[] =
  {
    -180,     7,  -180,  -180,    38,    41,  1615,    44,  -180,  -180,
     -29,  -180,   -19,  -180,  -180,  -180,  -180,  -180,  -180,  -180,
    -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,
    -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,
    -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,
    -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,
    -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,
    -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,
    -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,  -180,
    -180,  -180,  -180,  -180,  -180,  -180,    46,  -180,  -180,  -180,
    -180,  -180,    21,  -180,  -180,  -180,  -180,  1702,  -180,  1615,
    1615,  1615,  1615,  1615,  -180,  1615,    47,  1615,  -180,  -180,
    -180,  1615,  -180,  -180,  -180,  1615,  1615,  1615,  -180,  1615,
      82,     3,    53,   -68,    61,    67,    67,  -180,    72,    67,
      91,    67,    67,    67,   -64,   405,   405,  -180,   405,  -180,
     405,    87,   110,   385,   282,   -22,  -180,   111,   -13,  1724,
    -180,  -180,   161,  -180,  -180,  -180,  -180,  -180,   405,   405,
     -20,   165,    -5,  -180,    77,    78,    55,   405,  -180,  -180,
    -180,    81,  -180,  -180,   188,  -180,    67,  -180,  -180,   466,
    -180,  -180,  -180,   405,    37,  -180,   268,  -180,  -180,  -180,
      16,  -180,   -16,  -180,   405,   405,   168,   405,   278,  -180,
    -180,  -180,   405,   -43,   562,  -180,  -180,  -180,  -180,   658,
     -36,  -180,  -180,  -180,   183,    88,  -180,   189,   -28,   754,
     850,   -80,  -180,  -180,   362,  -180,  -180,  -180,   165,  -180,
     -28,    59,  -180,    24,  -180,  -180,  -180,  -180,    86,    31,
    -180,  -180,  -180,   168,   405,  -180,   405,    11,   371,   -52,
    -180,  -180,  -180,   946,  -180,  1042,  -180,   405,  -180,  1138,
    -180,  -180,   405,     0,   -28,   371,    94,  1234,   186,   168,
    -180,   411,   371,   168,  -180,   405,  1330,  -180,  -180,   -41,
       2,   -12,  -180,    25,  -180,  1426,   198,  -180,  -180,  -180,
    -180,   371,   168,   371,   -28,  1522,   199,  -180,   405,   290,
     405,  -180,  -180,  -180,  -180,   371,  -180,  -180,   283,   405,
     295,  -180,   319,  -180,  -180,    49
  };

  const unsigned char
  IclParser::yydefact_[] =
  {
       2,     0,     1,     5,     0,     0,     0,     0,     3,     4,
       0,   122,     0,   124,   106,    32,    33,    34,    35,   183,
     184,   182,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,   166,   167,   168,   169,   170,   171,
     172,   173,   174,   175,   113,    31,    36,    37,    38,    39,
      40,    41,    43,    44,    42,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   114,   115,
     118,   119,   120,   121,   134,   135,   136,   116,   117,   176,
     177,   178,   179,   180,   181,   143,     0,   139,   140,   141,
     142,   107,     6,   123,   125,     9,     7,     0,    11,     0,
       0,     0,     0,     0,   137,     0,     0,     0,   138,     8,
      10,     0,    24,   111,    27,     0,     0,     0,    14,     0,
       0,     0,     0,     0,     0,    74,    74,    92,     0,    74,
       0,    74,    74,    74,     0,     0,     0,    16,     0,    17,
       0,     0,     0,     0,     0,     0,    95,     0,     0,     0,
     128,   129,     0,   194,   195,   196,   197,   198,     0,     0,
       0,    72,   185,   190,     0,     0,     0,     0,    66,    93,
      29,     0,   102,   103,     0,    99,    74,    95,    77,     0,
      95,    95,    23,     0,     0,   130,     0,   126,   127,   131,
       0,   187,     0,    13,     0,     0,     0,     0,     0,    12,
      15,    75,     0,     0,     0,    94,    30,   100,   101,     0,
     108,    96,    20,    97,     0,     0,    84,   109,   105,     0,
       0,     0,    86,   133,     0,    95,   112,   189,    73,   188,
     186,     0,   191,     0,    95,    18,    67,    28,     0,     0,
     109,    78,    79,     0,     0,    95,     0,     0,    58,    64,
      21,    22,    86,     0,   132,     0,   192,     0,    76,     0,
      68,    95,     0,     0,    64,    59,     0,     0,     0,     0,
      80,     0,    62,     0,    95,     0,     0,    87,    26,     0,
       0,    72,   110,     0,    19,     0,     0,    70,    81,    98,
      82,    63,     0,    60,    65,     0,     0,    25,     0,     0,
       0,    89,   193,    71,    69,    61,    85,    83,     0,     0,
       0,    88,     0,    90,    91,   108
  };

  const short
  IclParser::yypgoto_[] =
  {
    -180,  -180,  -180,  -180,  -180,   280,  -180,   126,  -180,  -145,
     258,  -180,  -180,   140,  -180,   191,  -180,   222,  -180,    20,
     -96,  -180,   304,   310,   314,   318,   320,  -180,  -180,  -180,
     323,  -180,  -109,  -148,  -179,  -180
  };

  const short
  IclParser::yydefgoto_[] =
  {
       0,     1,     8,   107,   120,    95,   257,   258,   214,   289,
     151,   122,   223,   263,   153,   189,   184,   185,   224,   186,
     225,   123,   226,    97,    98,    99,     9,   199,   162,   200,
     100,   130,   101,   171,   172,   173
  };

  const short
  IclParser::yytable_[] =
  {
     170,   174,   176,   175,   237,   309,   205,     2,   181,   283,
     228,   194,   206,     3,   163,   164,   165,   262,   166,   167,
     201,     4,     5,   204,   202,   234,    96,   240,     6,   279,
     160,   161,   213,   147,   163,   164,   165,   148,   166,   167,
     228,    10,   205,   205,    12,   284,   259,   207,   231,   102,
     228,   228,   208,   285,   244,   205,   238,   239,   245,   241,
     204,   308,   204,  -194,   243,  -194,  -194,  -194,  -194,   248,
     274,   207,   103,   205,   274,   187,   208,   205,   274,   188,
     227,   203,   104,   204,   191,   144,   228,   204,   192,   311,
     228,   163,   164,   165,   207,   166,   167,   253,   228,   208,
     274,   297,   274,     7,   304,   250,   254,   310,   145,   276,
     227,   278,   280,   235,   281,   291,   228,   236,   249,   293,
     227,   227,   106,   274,   268,   312,   228,   296,   271,   131,
     132,   133,   134,   135,   232,   136,   272,   138,   291,    11,
     306,   139,    13,   105,   137,   140,   141,   142,  -194,   143,
    -194,  -194,  -194,  -194,   250,   211,   227,   212,   146,   266,
     227,   267,   149,   318,   195,   320,   150,   290,   227,   154,
     196,   163,   164,   165,   322,   166,   167,   250,   209,   210,
     204,   204,   215,   205,   204,   255,   227,   270,   156,   204,
     290,    14,   177,   256,   182,   298,   227,   204,    15,    16,
      17,    18,    19,    20,    21,   197,   198,   178,   190,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,   233,    84,    85,    86,    87,    88,    89,    90,    91,
      92,   242,    93,    94,   252,    14,   216,   300,   182,   204,
    -104,   183,    15,    16,    17,    18,    19,    20,    21,   314,
     317,   204,   204,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,   264,    84,    85,    86,    87,
      88,    89,    90,    91,    92,   273,    93,    94,   219,   275,
     283,   229,   230,   282,   321,   183,   204,   121,   163,   164,
     165,   179,   166,   167,   152,   319,   323,   155,   204,   157,
     158,   159,   286,   168,   169,   301,   217,   303,   163,   164,
     165,   124,   166,   167,   163,   164,   165,   125,   166,   167,
     324,   126,   204,   168,   169,   127,   265,   128,   315,   302,
     129,     0,     0,     0,     0,   269,     0,     0,     0,     0,
       0,     0,     0,     0,   218,     0,   277,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   295,     0,     0,     0,     0,     0,     0,   220,
     164,   165,   221,   166,   167,   305,    15,    16,    17,    18,
      19,    20,    21,   180,     0,     0,     0,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,   114,
      84,    85,    86,    87,    88,    89,    90,    91,    92,   118,
      93,    94,     0,     0,   222,   325,   164,   165,   246,   166,
     167,     0,    15,    16,    17,    18,    19,    20,    21,     0,
     168,   169,     0,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,     0,    84,    85,    86,    87,
      88,    89,    90,    91,    92,     0,    93,    94,     0,     0,
     247,   220,   164,   165,   221,   166,   167,     0,    15,    16,
      17,    18,    19,    20,    21,     0,     0,     0,     0,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,   114,    84,    85,    86,    87,    88,    89,    90,    91,
      92,   118,    93,    94,     0,     0,   251,   220,   164,   165,
     221,   166,   167,     0,    15,    16,    17,    18,    19,    20,
      21,     0,     0,     0,     0,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,   114,    84,    85,
      86,    87,    88,    89,    90,    91,    92,   118,    93,    94,
       0,     0,   260,   220,   164,   165,   221,   166,   167,     0,
      15,    16,    17,    18,    19,    20,    21,     0,     0,     0,
       0,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,   114,    84,    85,    86,    87,    88,    89,
      90,    91,    92,   118,    93,    94,     0,     0,   261,   325,
     164,   165,   287,   166,   167,     0,    15,    16,    17,    18,
      19,    20,    21,     0,   168,   169,     0,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,     0,
      84,    85,    86,    87,    88,    89,    90,    91,    92,     0,
      93,    94,     0,     0,   288,   220,   164,   165,   221,   166,
     167,     0,    15,    16,    17,    18,    19,    20,    21,     0,
       0,     0,     0,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,   114,    84,    85,    86,    87,
      88,    89,    90,    91,    92,   118,    93,    94,     0,     0,
     292,   220,   164,   165,   221,   166,   167,     0,    15,    16,
      17,    18,    19,    20,    21,     0,     0,     0,     0,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,   114,    84,    85,    86,    87,    88,    89,    90,    91,
      92,   118,    93,    94,     0,     0,   294,   220,   164,   165,
     221,   166,   167,     0,    15,    16,    17,    18,    19,    20,
      21,     0,     0,     0,     0,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,   114,    84,    85,
      86,    87,    88,    89,    90,    91,    92,   118,    93,    94,
       0,     0,   299,   325,   164,   165,   287,   166,   167,     0,
      15,    16,    17,    18,    19,    20,    21,     0,   168,   169,
       0,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,     0,    84,    85,    86,    87,    88,    89,
      90,    91,    92,     0,    93,    94,     0,     0,   307,   220,
     164,   165,   221,   166,   167,     0,    15,    16,    17,    18,
      19,    20,    21,     0,     0,     0,     0,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,   114,
      84,    85,    86,    87,    88,    89,    90,    91,    92,   118,
      93,    94,     0,     0,   313,   220,   164,   165,   221,   166,
     167,     0,    15,    16,    17,    18,    19,    20,    21,     0,
       0,     0,     0,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,   114,    84,    85,    86,    87,
      88,    89,    90,    91,    92,   118,    93,    94,    14,     0,
     316,     0,     0,     0,     0,    15,    16,    17,    18,    19,
      20,    21,     0,     0,     0,     0,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,     0,    84,
      85,    86,    87,    88,    89,    90,    91,    92,   108,    93,
      94,     0,    15,    16,    17,    18,     4,     5,   109,     0,
       0,     0,     0,     0,   110,   111,   112,   163,   164,   165,
       0,   166,   167,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   168,   169,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   113,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,   114,    84,    85,    86,    87,
      88,     0,   115,   116,   117,   118,     0,     0,     0,     0,
     119,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   193
  };

  const short
  IclParser::yycheck_[] =
  {
     145,   146,   150,   148,    20,     3,    18,     0,   153,     9,
     189,   159,    17,     6,     3,     4,     5,    97,     7,     8,
     168,    14,    15,   103,   169,     9,     6,   206,    21,    18,
      94,    95,   177,   101,     3,     4,     5,   105,     7,     8,
     219,     3,    18,    18,     3,    97,   225,    99,   193,     5,
     229,   230,   104,   105,    97,    18,   204,   205,   101,   207,
     103,   102,   103,    99,   212,   101,    17,    18,   104,   214,
     249,    99,   101,    18,   253,    97,   104,    18,   257,   101,
     189,   101,   101,   103,    97,     3,   265,   103,   101,   101,
     269,     3,     4,     5,    99,     7,     8,     9,   277,   104,
     279,   101,   281,    96,   283,   214,    18,   105,   105,   254,
     219,   256,   101,    97,   103,   263,   295,   101,   214,   267,
     229,   230,   101,   302,   100,   100,   305,   272,    97,   109,
     110,   111,   112,   113,    97,   115,   105,   117,   286,   101,
     285,   121,   101,    97,    97,   125,   126,   127,    99,   129,
     101,   102,   103,   104,   263,   100,   265,   102,   105,   100,
     269,   102,   101,   308,     3,   310,    99,   263,   277,    97,
       9,     3,     4,     5,   319,     7,     8,   286,   101,   101,
     103,   103,   101,    18,   103,    97,   295,   101,    97,   103,
     286,     3,   105,   105,     6,   101,   305,   103,    10,    11,
      12,    13,    14,    15,    16,    44,    45,    97,    97,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,     3,    84,    85,    86,    87,    88,    89,    90,    91,
      92,     3,    94,    95,   101,     3,    98,   101,     6,   103,
     101,   103,    10,    11,    12,    13,    14,    15,    16,   101,
     101,   103,   103,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,     3,    84,    85,    86,    87,
      88,    89,    90,    91,    92,   249,    94,    95,   187,   253,
       9,   190,   191,   257,   101,   103,   103,   107,     3,     4,
       5,     6,     7,     8,   136,   105,   101,   139,   103,   141,
     142,   143,   262,    18,    19,   279,   184,   281,     3,     4,
       5,   107,     7,     8,     3,     4,     5,   107,     7,     8,
     101,   107,   103,    18,    19,   107,   235,   107,   302,    18,
     107,    -1,    -1,    -1,    -1,   244,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   186,    -1,   255,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   271,    -1,    -1,    -1,    -1,    -1,    -1,     3,
       4,     5,     6,     7,     8,   284,    10,    11,    12,    13,
      14,    15,    16,    98,    -1,    -1,    -1,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    95,    -1,    -1,    98,     3,     4,     5,     6,     7,
       8,    -1,    10,    11,    12,    13,    14,    15,    16,    -1,
      18,    19,    -1,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    -1,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    -1,    94,    95,    -1,    -1,
      98,     3,     4,     5,     6,     7,     8,    -1,    10,    11,
      12,    13,    14,    15,    16,    -1,    -1,    -1,    -1,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
      92,    93,    94,    95,    -1,    -1,    98,     3,     4,     5,
       6,     7,     8,    -1,    10,    11,    12,    13,    14,    15,
      16,    -1,    -1,    -1,    -1,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
      -1,    -1,    98,     3,     4,     5,     6,     7,     8,    -1,
      10,    11,    12,    13,    14,    15,    16,    -1,    -1,    -1,
      -1,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    93,    94,    95,    -1,    -1,    98,     3,
       4,     5,     6,     7,     8,    -1,    10,    11,    12,    13,
      14,    15,    16,    -1,    18,    19,    -1,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    -1,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    -1,
      94,    95,    -1,    -1,    98,     3,     4,     5,     6,     7,
       8,    -1,    10,    11,    12,    13,    14,    15,    16,    -1,
      -1,    -1,    -1,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,    -1,    -1,
      98,     3,     4,     5,     6,     7,     8,    -1,    10,    11,
      12,    13,    14,    15,    16,    -1,    -1,    -1,    -1,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
      92,    93,    94,    95,    -1,    -1,    98,     3,     4,     5,
       6,     7,     8,    -1,    10,    11,    12,    13,    14,    15,
      16,    -1,    -1,    -1,    -1,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
      -1,    -1,    98,     3,     4,     5,     6,     7,     8,    -1,
      10,    11,    12,    13,    14,    15,    16,    -1,    18,    19,
      -1,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    -1,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    -1,    94,    95,    -1,    -1,    98,     3,
       4,     5,     6,     7,     8,    -1,    10,    11,    12,    13,
      14,    15,    16,    -1,    -1,    -1,    -1,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    95,    -1,    -1,    98,     3,     4,     5,     6,     7,
       8,    -1,    10,    11,    12,    13,    14,    15,    16,    -1,
      -1,    -1,    -1,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,     3,    -1,
      98,    -1,    -1,    -1,    -1,    10,    11,    12,    13,    14,
      15,    16,    -1,    -1,    -1,    -1,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    -1,    84,
      85,    86,    87,    88,    89,    90,    91,    92,     6,    94,
      95,    -1,    10,    11,    12,    13,    14,    15,    16,    -1,
      -1,    -1,    -1,    -1,    22,    23,    24,     3,     4,     5,
      -1,     7,     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      88,    -1,    90,    91,    92,    93,    -1,    -1,    -1,    -1,
      98,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    89
  };

  const unsigned char
  IclParser::yystos_[] =
  {
       0,   107,     0,     6,    14,    15,    21,    96,   108,   132,
       3,   101,     3,   101,     3,    10,    11,    12,    13,    14,
      15,    16,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    94,    95,   111,   125,   129,   130,   131,
     136,   138,     5,   101,   101,    97,   101,   109,     6,    16,
      22,    23,    24,    52,    83,    90,    91,    92,    93,    98,
     110,   111,   117,   127,   128,   129,   130,   131,   132,   136,
     137,   125,   125,   125,   125,   125,   125,    97,   125,   125,
     125,   125,   125,   125,     3,   105,   105,   101,   105,   101,
      99,   116,   116,   120,    97,   116,    97,   116,   116,   116,
      94,    95,   134,     3,     4,     5,     7,     8,    18,    19,
     115,   139,   140,   141,   115,   115,   139,   105,    97,     6,
      98,   115,     6,   103,   122,   123,   125,    97,   101,   121,
      97,    97,   101,    89,   139,     3,     9,    44,    45,   133,
     135,   139,   115,   101,   103,    18,    17,    99,   104,   101,
     101,   100,   102,   115,   114,   101,    98,   123,   116,   121,
       3,     6,    98,   118,   124,   126,   128,   138,   140,   121,
     121,   115,    97,     3,     9,    97,   101,    20,   139,   139,
     140,   139,     3,   139,    97,   101,     6,    98,   115,   126,
     138,    98,   101,     9,    18,    97,   105,   112,   113,   140,
      98,    98,    97,   119,     3,   121,   100,   102,   100,   121,
     101,    97,   105,   113,   140,   113,   115,   121,   115,    18,
     101,   103,   113,     9,    97,   105,   119,     6,    98,   115,
     126,   139,    98,   139,    98,   121,   115,   101,   101,    98,
     101,   113,    18,   113,   140,   121,   115,    98,   102,     3,
     105,   101,   100,    98,   101,   113,    98,   101,   115,   105,
     115,   101,   115,   101,   101,     3
  };

  const unsigned char
  IclParser::yyr1_[] =
  {
       0,   106,   107,   107,   107,   107,   107,   107,   108,   109,
     109,   110,   110,   110,   110,   110,   110,   110,   110,   110,
     110,   110,   110,   110,   110,   110,   110,   110,   110,   110,
     110,   111,   111,   111,   111,   111,   111,   111,   111,   111,
     111,   111,   111,   111,   111,   111,   111,   111,   111,   111,
     111,   111,   111,   111,   111,   111,   111,   111,   112,   112,
     112,   112,   112,   112,   113,   113,   114,   114,   114,   114,
     114,   114,   115,   115,   116,   116,   116,   117,   117,   118,
     118,   118,   118,   118,   118,   118,   119,   119,   119,   119,
     119,   119,   120,   120,   120,   121,   121,   121,   121,   122,
     122,   123,   123,   123,   124,   124,   125,   125,   126,   126,
     127,   128,   128,   129,   129,   130,   130,   130,   131,   131,
     131,   131,   132,   132,   132,   132,   133,   133,   134,   134,
     135,   135,   135,   135,   136,   136,   136,   137,   137,   138,
     138,   138,   138,   138,   138,   138,   138,   138,   138,   138,
     138,   138,   138,   138,   138,   138,   138,   138,   138,   138,
     138,   138,   138,   138,   138,   138,   138,   138,   138,   138,
     138,   138,   138,   138,   138,   138,   138,   138,   138,   138,
     138,   138,   138,   138,   138,   139,   139,   139,   139,   139,
     140,   140,   140,   140,   141,   141,   141,   141,   141
  };

  const signed char
  IclParser::yyr2_[] =
  {
       0,     2,     0,     2,     2,     2,     3,     4,     5,     0,
       2,     1,     5,     5,     1,     5,     3,     3,     6,     8,
       5,     6,     6,     4,     1,     8,     7,     1,     6,     4,
       5,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       3,     4,     2,     3,     1,     3,     0,     2,     3,     5,
       4,     5,     1,     3,     0,     3,     5,     4,     6,     2,
       3,     4,     4,     5,     1,     5,     0,     2,     5,     3,
       5,     6,     0,     2,     3,     0,     2,     2,     5,     1,
       2,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       7,     1,     5,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     3,     2,     3,     1,     1,     1,     1,
       1,     1,     3,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     2,     3,     3,
       1,     3,     4,     6,     1,     1,     1,     1,     1
  };




#if YYDEBUG
  const short
  IclParser::yyrline_[] =
  {
       0,   258,   258,   259,   261,   263,   280,   284,   291,   298,
     300,   305,   306,   309,   312,   313,   319,   326,   336,   339,
     348,   357,   362,   367,   370,   371,   389,   395,   403,   408,
     413,   421,   427,   428,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,   439,   440,   441,   442,   443,   444,
     445,   446,   447,   448,   449,   450,   451,   452,   460,   470,
     471,   477,   482,   488,   493,   497,   504,   506,   510,   514,
     522,   526,   540,   541,   549,   550,   551,   555,   560,   572,
     583,   589,   594,   612,   628,   637,   654,   656,   661,   667,
     678,   684,   691,   693,   695,   707,   709,   713,   715,   745,
     747,   752,   755,   759,   782,   783,   805,   806,   810,   811,
     822,   830,   832,   842,   843,   847,   848,   849,   853,   854,
     855,   856,   863,   865,   867,   869,   888,   889,   908,   909,
     913,   914,   915,   926,   931,   932,   933,   937,   938,   944,
     945,   946,   947,   953,   954,   955,   956,   957,   958,   959,
     960,   961,   962,   963,   964,   965,   966,   967,   968,   969,
     970,   971,   972,   973,   974,   975,   976,   977,   978,   979,
     980,   981,   982,   983,   984,   985,   986,   987,   988,   989,
     990,   991,   992,   993,   994,  1000,  1004,  1006,  1009,  1010,
    1014,  1015,  1017,  1019,  1024,  1025,  1026,  1027,  1029
  };

  void
  IclParser::yy_stack_print_ () const
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  void
  IclParser::yy_reduce_print_ (int yyrule) const
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 48 "src/icl_parser.yy"
} // icl
#line 3411 "build/gen/icl_parser.cc"

#line 1032 "src/icl_parser.yy"

