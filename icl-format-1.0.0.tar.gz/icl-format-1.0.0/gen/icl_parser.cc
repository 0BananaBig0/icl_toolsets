// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.





#include "icl_parser.hh"


// Unqualified %code blocks.
#line 66 "src/icl_parser.yy"

// Declared by the generated scanner (see icl_lexer.l). It must be visible at
// the parser's call site; this block lands after the parser class definition,
// so |IclParser::symbol_type| is a complete type here.
namespace icl {
IclParser::symbol_type yylex(IclDriver& driver);
}  // namespace icl
#line 75 "src/icl_parser.yy"

#include "icl_driver.h"

namespace icl {

// Reports the (first) syntax error. Later errors are cascades of the first,
// so the driver keeps only the earliest one.
void IclParser::error(const location& loc, const std::string& message) {
  SetParseDiagnostic(loc.begin.line, message);
}

}  // namespace icl

#line 68 "build/gen/icl_parser.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif


// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yy_stack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YY_USE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 42 "src/icl_parser.yy"
namespace icl {
#line 161 "build/gen/icl_parser.cc"

  /// Build a parser object.
  IclParser::IclParser (icl::IclDriver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  IclParser::~IclParser ()
  {}

  IclParser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------.
  | symbol.  |
  `---------*/



  // by_state.
  IclParser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  IclParser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  IclParser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  IclParser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  IclParser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  IclParser::symbol_kind_type
  IclParser::by_state::kind () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return symbol_kind::S_YYEMPTY;
    else
      return YY_CAST (symbol_kind_type, yystos_[+state]);
  }

  IclParser::stack_symbol_type::stack_symbol_type ()
  {}

  IclParser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.YY_MOVE_OR_COPY< AstModule* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
        value.YY_MOVE_OR_COPY< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        value.YY_MOVE_OR_COPY< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_ident_list: // ident_list
        value.YY_MOVE_OR_COPY< std::vector<std::string> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  IclParser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstModule* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
        value.move< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        value.move< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_ident_list: // ident_list
        value.move< std::vector<std::string> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.kind_ = symbol_kind::S_YYEMPTY;
  }

#if YY_CPLUSPLUS < 201103L
  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.copy< AstModule* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
        value.copy< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.copy< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        value.copy< std::vector<AstNode*> > (that.value);
        break;

      case symbol_kind::S_ident_list: // ident_list
        value.copy< std::vector<std::string> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstModule* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
        value.move< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        value.move< std::vector<AstNode*> > (that.value);
        break;

      case symbol_kind::S_ident_list: // ident_list
        value.move< std::vector<std::string> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  IclParser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  IclParser::yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YY_USE (yyoutput);
    if (yysym.empty ())
      yyo << "empty symbol";
    else
      {
        symbol_kind_type yykind = yysym.kind ();
        yyo << (yykind < YYNTOKENS ? "token" : "nterm")
            << ' ' << yysym.name () << " ("
            << yysym.location << ": ";
        switch (yykind)
    {
      case symbol_kind::S_IDENT: // "identifier"
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 452 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_NUMBER: // "number"
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 458 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_STRING: // "string"
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 464 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_COMMENT: // "comment"
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 470 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_port_keyword: // port_keyword
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 476 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_opt_range: // opt_range
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 482 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_name: // attr_name
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 488 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_conn_expr: // conn_expr
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 494 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value: // value
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 500 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_postfix: // postfix
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 506 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_primary: // primary
#line 161 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 512 "build/gen/icl_parser.cc"
        break;

      default:
        break;
    }
        yyo << ')';
      }
  }
#endif

  void
  IclParser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  IclParser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  IclParser::yypop_ (int n) YY_NOEXCEPT
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  IclParser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  IclParser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  IclParser::debug_level_type
  IclParser::debug_level () const
  {
    return yydebug_;
  }

  void
  IclParser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  IclParser::state_type
  IclParser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - YYNTOKENS] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - YYNTOKENS];
  }

  bool
  IclParser::yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  IclParser::yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yytable_ninf_;
  }

  int
  IclParser::operator() ()
  {
    return parse ();
  }

  int
  IclParser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';
    YY_STACK_PRINT ();

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token\n";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    if (yyla.kind () == symbol_kind::S_YYerror)
    {
      // The scanner already issued an error message, process directly
      // to error recovery.  But do not keep the error token as
      // lookahead, it is too special and may lead us to an endless
      // loop in error recovery. */
      yyla.kind_ = symbol_kind::S_YYUNDEF;
      goto yyerrlab1;
    }

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.kind ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.kind ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case symbol_kind::S_module_def: // module_def
        yylhs.value.emplace< AstModule* > ();
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
        yylhs.value.emplace< AstNode* > ();
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        yylhs.value.emplace< std::string > ();
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        yylhs.value.emplace< std::vector<AstNode*> > ();
        break;

      case symbol_kind::S_ident_list: // ident_list
        yylhs.value.emplace< std::vector<std::string> > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 3: // file: file module_def
#line 172 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(yystack_[0].value.as < AstModule* > ()); }
#line 800 "build/gen/icl_parser.cc"
    break;

  case 4: // file: file "comment"
#line 174 "src/icl_parser.yy"
      {
        // Unlike the nested bodies below, the top-level rule has no vector to
        // append to, so the comment must be pushed onto the unit explicitly.
        driver.unit().top_level().push_back(
            driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)));
      }
#line 811 "build/gen/icl_parser.cc"
    break;

  case 5: // module_def: "Module" "identifier" "{" module_item_list "}"
#line 184 "src/icl_parser.yy"
      {
        AstModule* module = driver.MakeAstModule(yystack_[3].value.as < std::string > (), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        module->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstModule* > () = module;
      }
#line 821 "build/gen/icl_parser.cc"
    break;

  case 6: // module_item_list: %empty
#line 193 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 827 "build/gen/icl_parser.cc"
    break;

  case 7: // module_item_list: module_item_list module_item
#line 195 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 833 "build/gen/icl_parser.cc"
    break;

  case 8: // module_item: "comment"
#line 199 "src/icl_parser.yy"
            { yylhs.value.as < AstNode* > () = driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)); }
#line 839 "build/gen/icl_parser.cc"
    break;

  case 9: // module_item: "Parameter" "identifier" "=" value ";"
#line 201 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(AstKind::kParameter,
                                  "Parameter " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 847 "build/gen/icl_parser.cc"
    break;

  case 10: // module_item: "Attribute" "identifier" "=" "string" ";"
#line 205 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(AstKind::kAttribute,
                                  "Attribute " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 855 "build/gen/icl_parser.cc"
    break;

  case 11: // module_item: "Alias" "identifier" "=" value ";"
#line 209 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(AstKind::kAlias,
                                  "Alias " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 863 "build/gen/icl_parser.cc"
    break;

  case 12: // module_item: "Alias" "identifier" "=" value "{" attr_body "}"
#line 213 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kAlias,
                                          "Alias " + yystack_[5].value.as < std::string > () + " = " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 875 "build/gen/icl_parser.cc"
    break;

  case 13: // module_item: "Enum" "identifier" "{" attr_body "}"
#line 221 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kEnum, "Enum " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 886 "build/gen/icl_parser.cc"
    break;

  case 14: // module_item: port_decl
#line 227 "src/icl_parser.yy"
              { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 892 "build/gen/icl_parser.cc"
    break;

  case 15: // module_item: "ScanInterface" "identifier" "{" attr_body "}"
#line 229 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kScanInterface,
                                          "ScanInterface " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 904 "build/gen/icl_parser.cc"
    break;

  case 16: // module_item: "OneHotScanInterface" "identifier" "{" attr_body "}"
#line 237 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kOneHotScanInterface,
                                          "OneHotScanInterface " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 916 "build/gen/icl_parser.cc"
    break;

  case 17: // module_item: "ScanRegister" "identifier" opt_range "{" attr_body "}"
#line 245 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kScanRegister,
                                          "ScanRegister " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 928 "build/gen/icl_parser.cc"
    break;

  case 18: // module_item: "ScanRegister" "identifier" opt_range ";"
#line 253 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(AstKind::kScanRegister,
                                  "ScanRegister " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 936 "build/gen/icl_parser.cc"
    break;

  case 19: // module_item: "Reg" "identifier" opt_range "{" attr_body "}"
#line 257 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kReg, "Reg " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 947 "build/gen/icl_parser.cc"
    break;

  case 20: // module_item: "Reg" "identifier" opt_range ";"
#line 264 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(AstKind::kReg, "Reg " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 954 "build/gen/icl_parser.cc"
    break;

  case 21: // module_item: "Field" "identifier" opt_range "Of" "identifier" "{" attr_body "}"
#line 267 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(
            AstKind::kField, "Field " + yystack_[6].value.as < std::string > () + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (),
            SpanOf(yystack_[7].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 966 "build/gen/icl_parser.cc"
    break;

  case 22: // module_item: "Field" "identifier" opt_range "Of" "identifier" ";"
#line 275 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(
            AstKind::kField, "Field " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > () + " Of " + yystack_[1].value.as < std::string > () + ";",
            SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line)); }
#line 974 "build/gen/icl_parser.cc"
    break;

  case 23: // module_item: "Instance" "identifier" "Of" "identifier" "{" attr_body "}"
#line 279 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(
            AstKind::kInstance, "Instance " + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (),
            SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 986 "build/gen/icl_parser.cc"
    break;

  case 24: // module_item: "Instance" "identifier" "Of" "identifier" ";"
#line 287 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(AstKind::kInstance,
                                  "Instance " + yystack_[3].value.as < std::string > () + " Of " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 994 "build/gen/icl_parser.cc"
    break;

  case 25: // module_item: "ScanMux" "identifier" "identifier" "{" mux_body "}"
#line 291 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kScanMux,
                                          "ScanMux " + yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 1006 "build/gen/icl_parser.cc"
    break;

  case 26: // module_item: "LogicSignal" "identifier" "{" attr_body "}"
#line 299 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kLogicSignal,
                                          "LogicSignal " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 1018 "build/gen/icl_parser.cc"
    break;

  case 27: // module_item: "Connection" "{" conn_body "}"
#line 307 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kConnection, "Connection",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 1029 "build/gen/icl_parser.cc"
    break;

  case 28: // module_item: "PortGroup" "identifier" "{" ident_list "}"
#line 314 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakePortGroup(yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<std::string> > ()), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1035 "build/gen/icl_parser.cc"
    break;

  case 29: // module_item: "AccessLink" "identifier" "Of" "identifier" "{" al_body "}"
#line 316 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(
            AstKind::kAccessLink, "AccessLink " + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (),
            SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 1047 "build/gen/icl_parser.cc"
    break;

  case 30: // port_keyword: "ScanInPort"
#line 328 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanInPort"; }
#line 1053 "build/gen/icl_parser.cc"
    break;

  case 31: // port_keyword: "ScanOutPort"
#line 329 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanOutPort"; }
#line 1059 "build/gen/icl_parser.cc"
    break;

  case 32: // port_keyword: "ShiftEnPort"
#line 330 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ShiftEnPort"; }
#line 1065 "build/gen/icl_parser.cc"
    break;

  case 33: // port_keyword: "CaptureEnPort"
#line 331 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "CaptureEnPort"; }
#line 1071 "build/gen/icl_parser.cc"
    break;

  case 34: // port_keyword: "UpdateEnPort"
#line 332 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "UpdateEnPort"; }
#line 1077 "build/gen/icl_parser.cc"
    break;

  case 35: // port_keyword: "SelectPort"
#line 333 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "SelectPort"; }
#line 1083 "build/gen/icl_parser.cc"
    break;

  case 36: // port_keyword: "ResetPort"
#line 334 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ResetPort"; }
#line 1089 "build/gen/icl_parser.cc"
    break;

  case 37: // port_keyword: "TCKPort"
#line 335 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TCKPort"; }
#line 1095 "build/gen/icl_parser.cc"
    break;

  case 38: // port_keyword: "TMSPort"
#line 336 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TMSPort"; }
#line 1101 "build/gen/icl_parser.cc"
    break;

  case 39: // port_keyword: "ToDoPort"
#line 337 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToDoPort"; }
#line 1107 "build/gen/icl_parser.cc"
    break;

  case 40: // port_keyword: "ToSelectPort"
#line 338 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToSelectPort"; }
#line 1113 "build/gen/icl_parser.cc"
    break;

  case 41: // port_keyword: "DataInPort"
#line 339 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataInPort"; }
#line 1119 "build/gen/icl_parser.cc"
    break;

  case 42: // port_keyword: "DataOutPort"
#line 340 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataOutPort"; }
#line 1125 "build/gen/icl_parser.cc"
    break;

  case 43: // opt_range: %empty
#line 344 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = std::string(); }
#line 1131 "build/gen/icl_parser.cc"
    break;

  case 44: // opt_range: "[" "number" "]"
#line 345 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1137 "build/gen/icl_parser.cc"
    break;

  case 45: // opt_range: "[" "number" ":" "number" "]"
#line 346 "src/icl_parser.yy"
                                          { yylhs.value.as < std::string > () = "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1143 "build/gen/icl_parser.cc"
    break;

  case 46: // port_decl: port_keyword "identifier" opt_range ";"
#line 351 "src/icl_parser.yy"
      {
        AstPort* port = driver.MakePort(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > (), SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
        yylhs.value.as < AstNode* > () = port;
      }
#line 1152 "build/gen/icl_parser.cc"
    break;

  case 47: // port_decl: port_keyword "identifier" opt_range "{" attr_body "}"
#line 356 "src/icl_parser.yy"
      {
        AstPort* port = driver.MakePort(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
        port->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = port;
      }
#line 1162 "build/gen/icl_parser.cc"
    break;

  case 48: // attr_body: %empty
#line 367 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1168 "build/gen/icl_parser.cc"
    break;

  case 49: // attr_body: attr_body "comment"
#line 369 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1174 "build/gen/icl_parser.cc"
    break;

  case 50: // attr_body: attr_body attr_name ";"
#line 371 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(AstKind::kAttributeItem,
                                          yystack_[1].value.as < std::string > () + ";", SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1182 "build/gen/icl_parser.cc"
    break;

  case 51: // attr_body: attr_body attr_name value ";"
#line 375 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[3].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(AstKind::kAttributeItem,
                                          yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line))); }
#line 1191 "build/gen/icl_parser.cc"
    break;

  case 52: // attr_body: attr_body attr_name "=" value ";"
#line 380 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(AstKind::kAttributeItem,
                                          yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1200 "build/gen/icl_parser.cc"
    break;

  case 53: // attr_body: attr_body attr_name "identifier" "=" value ";"
#line 385 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[5].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(AstKind::kAttributeItem,
                                          yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line))); }
#line 1209 "build/gen/icl_parser.cc"
    break;

  case 54: // mux_body: %empty
#line 393 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1215 "build/gen/icl_parser.cc"
    break;

  case 55: // mux_body: mux_body "comment"
#line 395 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1221 "build/gen/icl_parser.cc"
    break;

  case 56: // mux_body: mux_body value ":" value ";"
#line 397 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(AstKind::kMuxEntry,
                                          yystack_[3].value.as < std::string > () + " : " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1230 "build/gen/icl_parser.cc"
    break;

  case 57: // conn_body: %empty
#line 405 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1236 "build/gen/icl_parser.cc"
    break;

  case 58: // conn_body: conn_body "comment"
#line 407 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1242 "build/gen/icl_parser.cc"
    break;

  case 59: // conn_body: conn_body conn_expr ";"
#line 409 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(AstKind::kConnectionItem, yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1250 "build/gen/icl_parser.cc"
    break;

  case 60: // al_body: %empty
#line 417 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1256 "build/gen/icl_parser.cc"
    break;

  case 61: // al_body: al_body "comment"
#line 419 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1262 "build/gen/icl_parser.cc"
    break;

  case 62: // al_body: al_body attr_name ";"
#line 421 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(AstKind::kAttributeItem, yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1270 "build/gen/icl_parser.cc"
    break;

  case 63: // al_body: al_body attr_name value ";"
#line 425 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[3].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(AstKind::kAttributeItem,
                                          yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line))); }
#line 1279 "build/gen/icl_parser.cc"
    break;

  case 64: // al_body: al_body attr_name "identifier" "=" value ";"
#line 430 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[5].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(AstKind::kAttributeItem,
                                          yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line))); }
#line 1288 "build/gen/icl_parser.cc"
    break;

  case 65: // al_body: al_body attr_name "{" al_body "}"
#line 435 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(AstKind::kAccessLinkItem, yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(block);
      }
#line 1300 "build/gen/icl_parser.cc"
    break;

  case 66: // ident_list: "identifier"
#line 445 "src/icl_parser.yy"
                        { yylhs.value.as < std::vector<std::string> > () = std::vector<std::string>{yystack_[0].value.as < std::string > ()}; }
#line 1306 "build/gen/icl_parser.cc"
    break;

  case 67: // ident_list: ident_list "," "identifier"
#line 446 "src/icl_parser.yy"
                           { yylhs.value.as < std::vector<std::string> > () = std::move(yystack_[2].value.as < std::vector<std::string> > ()); yylhs.value.as < std::vector<std::string> > ().push_back(yystack_[0].value.as < std::string > ()); }
#line 1312 "build/gen/icl_parser.cc"
    break;

  case 68: // attr_name: "identifier"
#line 453 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1318 "build/gen/icl_parser.cc"
    break;

  case 69: // attr_name: "Module"
#line 454 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Module"; }
#line 1324 "build/gen/icl_parser.cc"
    break;

  case 70: // attr_name: "Parameter"
#line 455 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Parameter"; }
#line 1330 "build/gen/icl_parser.cc"
    break;

  case 71: // attr_name: "Attribute"
#line 456 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Attribute"; }
#line 1336 "build/gen/icl_parser.cc"
    break;

  case 72: // attr_name: "Alias"
#line 457 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Alias"; }
#line 1342 "build/gen/icl_parser.cc"
    break;

  case 73: // attr_name: "Enum"
#line 458 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Enum"; }
#line 1348 "build/gen/icl_parser.cc"
    break;

  case 74: // attr_name: "ScanInPort"
#line 459 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanInPort"; }
#line 1354 "build/gen/icl_parser.cc"
    break;

  case 75: // attr_name: "ScanOutPort"
#line 460 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanOutPort"; }
#line 1360 "build/gen/icl_parser.cc"
    break;

  case 76: // attr_name: "ShiftEnPort"
#line 461 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ShiftEnPort"; }
#line 1366 "build/gen/icl_parser.cc"
    break;

  case 77: // attr_name: "CaptureEnPort"
#line 462 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "CaptureEnPort"; }
#line 1372 "build/gen/icl_parser.cc"
    break;

  case 78: // attr_name: "UpdateEnPort"
#line 463 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "UpdateEnPort"; }
#line 1378 "build/gen/icl_parser.cc"
    break;

  case 79: // attr_name: "SelectPort"
#line 464 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "SelectPort"; }
#line 1384 "build/gen/icl_parser.cc"
    break;

  case 80: // attr_name: "ResetPort"
#line 465 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ResetPort"; }
#line 1390 "build/gen/icl_parser.cc"
    break;

  case 81: // attr_name: "TCKPort"
#line 466 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "TCKPort"; }
#line 1396 "build/gen/icl_parser.cc"
    break;

  case 82: // attr_name: "TMSPort"
#line 467 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "TMSPort"; }
#line 1402 "build/gen/icl_parser.cc"
    break;

  case 83: // attr_name: "ToDoPort"
#line 468 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToDoPort"; }
#line 1408 "build/gen/icl_parser.cc"
    break;

  case 84: // attr_name: "ToSelectPort"
#line 469 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToSelectPort"; }
#line 1414 "build/gen/icl_parser.cc"
    break;

  case 85: // attr_name: "DataInPort"
#line 470 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "DataInPort"; }
#line 1420 "build/gen/icl_parser.cc"
    break;

  case 86: // attr_name: "DataOutPort"
#line 471 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "DataOutPort"; }
#line 1426 "build/gen/icl_parser.cc"
    break;

  case 87: // attr_name: "ScanInterface"
#line 472 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanInterface"; }
#line 1432 "build/gen/icl_parser.cc"
    break;

  case 88: // attr_name: "OneHotScanInterface"
#line 473 "src/icl_parser.yy"
                        { yylhs.value.as < std::string > () = "OneHotScanInterface"; }
#line 1438 "build/gen/icl_parser.cc"
    break;

  case 89: // attr_name: "ScanRegister"
#line 474 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanRegister"; }
#line 1444 "build/gen/icl_parser.cc"
    break;

  case 90: // attr_name: "Reg"
#line 475 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Reg"; }
#line 1450 "build/gen/icl_parser.cc"
    break;

  case 91: // attr_name: "Field"
#line 476 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Field"; }
#line 1456 "build/gen/icl_parser.cc"
    break;

  case 92: // attr_name: "Instance"
#line 477 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Instance"; }
#line 1462 "build/gen/icl_parser.cc"
    break;

  case 93: // attr_name: "ScanMux"
#line 478 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanMux"; }
#line 1468 "build/gen/icl_parser.cc"
    break;

  case 94: // attr_name: "LogicSignal"
#line 479 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "LogicSignal"; }
#line 1474 "build/gen/icl_parser.cc"
    break;

  case 95: // attr_name: "Connection"
#line 480 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Connection"; }
#line 1480 "build/gen/icl_parser.cc"
    break;

  case 96: // attr_name: "PortGroup"
#line 481 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "PortGroup"; }
#line 1486 "build/gen/icl_parser.cc"
    break;

  case 97: // attr_name: "AccessLink"
#line 482 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "AccessLink"; }
#line 1492 "build/gen/icl_parser.cc"
    break;

  case 98: // attr_name: "iProcsForModule"
#line 483 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "iProcsForModule"; }
#line 1498 "build/gen/icl_parser.cc"
    break;

  case 99: // attr_name: "Of"
#line 484 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Of"; }
#line 1504 "build/gen/icl_parser.cc"
    break;

  case 100: // conn_expr: postfix
#line 490 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1510 "build/gen/icl_parser.cc"
    break;

  case 101: // conn_expr: postfix "->" postfix
#line 491 "src/icl_parser.yy"
                          { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + " -> " + yystack_[0].value.as < std::string > (); }
#line 1516 "build/gen/icl_parser.cc"
    break;

  case 102: // value: postfix
#line 495 "src/icl_parser.yy"
            { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1522 "build/gen/icl_parser.cc"
    break;

  case 103: // postfix: primary
#line 499 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1528 "build/gen/icl_parser.cc"
    break;

  case 104: // postfix: postfix "." "identifier"
#line 500 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 1534 "build/gen/icl_parser.cc"
    break;

  case 105: // postfix: postfix "." "number"
#line 501 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 1540 "build/gen/icl_parser.cc"
    break;

  case 106: // postfix: postfix "[" "number" "]"
#line 502 "src/icl_parser.yy"
                                                { yylhs.value.as < std::string > () = yystack_[3].value.as < std::string > () + "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1546 "build/gen/icl_parser.cc"
    break;

  case 107: // postfix: postfix "[" "number" ":" "number" "]"
#line 503 "src/icl_parser.yy"
                                                  { yylhs.value.as < std::string > () = yystack_[5].value.as < std::string > () + "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1552 "build/gen/icl_parser.cc"
    break;

  case 108: // primary: "identifier"
#line 507 "src/icl_parser.yy"
           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1558 "build/gen/icl_parser.cc"
    break;

  case 109: // primary: "number"
#line 508 "src/icl_parser.yy"
           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1564 "build/gen/icl_parser.cc"
    break;

  case 110: // primary: "string"
#line 509 "src/icl_parser.yy"
           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1570 "build/gen/icl_parser.cc"
    break;


#line 1574 "build/gen/icl_parser.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        std::string msg = YY_("syntax error");
        error (yyla.location, YY_MOVE (msg));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.kind () == symbol_kind::S_YYEOF)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    // Pop stack until we find a state that shifts the error token.
    for (;;)
      {
        yyn = yypact_[+yystack_[0].state];
        if (!yy_pact_value_is_default_ (yyn))
          {
            yyn += symbol_kind::S_YYerror;
            if (0 <= yyn && yyn <= yylast_
                && yycheck_[yyn] == symbol_kind::S_YYerror)
              {
                yyn = yytable_[yyn];
                if (0 < yyn)
                  break;
              }
          }

        // Pop the current state because it cannot handle the error token.
        if (yystack_.size () == 1)
          YYABORT;

        yyerror_range[1].location = yystack_[0].location;
        yy_destroy_ ("Error: popping", yystack_[0]);
        yypop_ ();
        YY_STACK_PRINT ();
      }
    {
      stack_symbol_type error_token;

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    YY_STACK_PRINT ();
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  IclParser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

#if YYDEBUG || 0
  const char *
  IclParser::symbol_name (symbol_kind_type yysymbol)
  {
    return yytname_[yysymbol];
  }
#endif // #if YYDEBUG || 0









  const short IclParser::yypact_ninf_ = -175;

  const signed char IclParser::yytable_ninf_ = -1;

  const short
  IclParser::yypact_[] =
  {
    -175,    24,  -175,  -175,    11,  -175,    -8,  -175,   570,  -175,
      30,    39,    49,    53,  -175,  -175,  -175,  -175,  -175,  -175,
    -175,  -175,  -175,  -175,  -175,  -175,  -175,    58,    66,    70,
      71,    72,    73,    74,    75,    40,    77,    78,  -175,  -175,
      79,  -175,    36,    38,    41,    47,    48,    51,    52,    52,
      52,    54,    92,    57,  -175,    59,    61,    52,    62,    95,
      62,  -175,  -175,  -175,    93,    -3,     0,    63,    99,    64,
    -175,    13,   101,   102,    12,  -175,  -175,  -175,    67,   -33,
    -175,    76,    19,   141,   177,   213,   -17,  -175,  -175,  -175,
    -175,   103,    20,  -175,   249,  -175,  -175,    80,     8,  -175,
     -11,    81,  -175,  -175,  -175,   105,    68,  -175,  -175,  -175,
    -175,  -175,  -175,  -175,  -175,  -175,  -175,  -175,  -175,  -175,
    -175,  -175,  -175,  -175,  -175,  -175,  -175,  -175,  -175,  -175,
    -175,  -175,  -175,  -175,  -175,  -175,  -175,  -175,  -175,  -175,
    -175,  -175,  -175,  -175,     1,  -175,  -175,  -175,   107,   285,
     321,    21,  -175,  -175,    17,  -175,  -175,    62,  -175,   104,
    -175,   357,    26,  -175,  -175,   393,    69,  -175,    62,    82,
      85,  -175,  -175,  -175,  -175,   429,  -175,  -175,    84,   -33,
    -175,   465,  -175,  -175,   109,  -175,    62,    86,  -175,  -175,
     501,  -175,    62,  -175,  -175,     7,    88,    90,  -175,  -175,
      91,    89,  -175,  -175,    94,  -175,  -175,  -175,    62,   537,
    -175,    96,  -175,  -175
  };

  const signed char
  IclParser::yydefact_[] =
  {
       2,     0,     1,     4,     0,     3,     0,     6,     0,     8,
       0,     0,     0,     0,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     5,     7,
       0,    14,     0,     0,     0,     0,     0,     0,    43,    43,
      43,     0,     0,     0,    57,     0,     0,    43,     0,     0,
       0,    48,    48,    48,     0,     0,     0,     0,     0,     0,
      48,     0,     0,     0,     0,   108,   109,   110,     0,   102,
     103,     0,     0,     0,     0,     0,     0,    48,    18,    48,
      20,     0,     0,    54,     0,    58,    27,     0,   100,    66,
       0,     0,    48,    46,     9,     0,     0,    10,    48,    11,
      68,    49,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
      97,    98,    99,    13,     0,    15,    16,    44,     0,     0,
       0,     0,    48,    24,     0,    26,    59,     0,    28,     0,
      60,     0,     0,   104,   105,     0,   108,    50,     0,     0,
       0,    17,    19,    48,    22,     0,    55,    25,     0,   101,
      67,     0,    47,   106,     0,    12,     0,     0,    51,    45,
       0,    23,     0,    61,    29,     0,     0,     0,    52,    21,
       0,   108,    60,    62,     0,   107,    53,    56,     0,     0,
      63,     0,    65,    64
  };

  const short
  IclParser::yypgoto_[] =
  {
    -175,  -175,  -175,  -175,  -175,  -175,   -12,  -175,   -61,  -175,
    -175,   -88,  -175,  -174,  -175,   -60,   -68,  -175
  };

  const unsigned char
  IclParser::yydefgoto_[] =
  {
       0,     1,     5,     8,    39,    40,    65,    41,    83,   154,
      71,   181,   100,   144,    97,    78,    79,    80
  };

  const unsigned char
  IclParser::yytable_[] =
  {
      82,    84,    85,    98,   166,    76,    77,   195,   105,    94,
     201,    76,    77,   106,     6,   157,    75,    76,    77,    95,
      75,    76,    77,   176,     2,   147,   149,   148,   150,   158,
       3,     7,     4,    42,   159,   195,    87,    66,    67,    89,
      88,   161,    43,    90,   167,    74,   202,   165,   168,   105,
     203,   102,    44,    96,   106,   103,    45,   177,   108,   152,
     173,    46,   109,   153,   174,    75,    76,    77,   183,    47,
     184,   163,   164,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,   169,    59,    61,    62,    60,   179,
      63,   175,    68,    64,   178,    69,    70,    86,    72,    73,
      81,    91,    92,    93,    99,   101,   151,   180,   187,   162,
     104,   170,   190,   196,   209,     0,   186,     0,     0,   107,
     160,     0,     0,   156,     0,   188,   197,   189,   192,   198,
     205,     0,   200,   206,   207,   204,   208,   210,     0,   213,
       0,     0,     0,     0,   110,     0,     0,   111,   211,   112,
     113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
     110,   143,     0,   111,     0,   112,   113,   114,   115,   116,
     117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   110,   145,     0,   111,
       0,   112,   113,   114,   115,   116,   117,   118,   119,   120,
     121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
     131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
     141,   142,   110,   146,     0,   111,     0,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   110,   155,
       0,   111,     0,   112,   113,   114,   115,   116,   117,   118,
     119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
     129,   130,   131,   132,   133,   134,   135,   136,   137,   138,
     139,   140,   141,   142,   110,   171,     0,   111,     0,   112,
     113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
     110,   172,     0,   111,     0,   112,   113,   114,   115,   116,
     117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   110,   182,     0,   111,
       0,   112,   113,   114,   115,   116,   117,   118,   119,   120,
     121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
     131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
     141,   142,   110,   185,     0,   111,     0,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   110,   191,
       0,   193,     0,   112,   113,   114,   115,   116,   117,   118,
     119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
     129,   130,   131,   132,   133,   134,   135,   136,   137,   138,
     139,   140,   141,   142,   110,   194,     0,   111,     0,   112,
     113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
     110,   199,     0,   193,     0,   112,   113,   114,   115,   116,
     117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,     9,   212,     0,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,     0,     0,     0,
      38
  };

  const short
  IclParser::yycheck_[] =
  {
      60,    62,    63,    71,     3,     4,     5,   181,    41,    70,
       3,     4,     5,    46,     3,     7,     3,     4,     5,     6,
       3,     4,     5,     6,     0,    42,    87,    44,    89,    40,
       6,    39,     8,     3,    45,   209,    39,    49,    50,    39,
      43,   102,     3,    43,    43,    57,    39,   108,    47,    41,
      43,    39,     3,    40,    46,    43,     3,    40,    39,    39,
      39,     3,    43,    43,    43,     3,     4,     5,    42,     3,
      44,     3,     4,     3,     3,     3,     3,     3,     3,    39,
       3,     3,     3,    47,   144,    47,    39,    39,    47,   157,
      39,   152,    38,    41,   154,     3,    39,     4,    39,    38,
       5,    38,     3,    39,     3,     3,     3,     3,   168,     4,
      43,     4,   173,     4,   202,    -1,    47,    -1,    -1,    43,
      39,    -1,    -1,    43,    -1,    43,   186,    42,    44,    43,
      42,    -1,   192,    43,    43,   195,    47,    43,    -1,    43,
      -1,    -1,    -1,    -1,     3,    -1,    -1,     6,   208,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
       3,    40,    -1,     6,    -1,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,     3,    40,    -1,     6,
      -1,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,     3,    40,    -1,     6,    -1,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,     3,    40,
      -1,     6,    -1,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,     3,    40,    -1,     6,    -1,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
       3,    40,    -1,     6,    -1,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,     3,    40,    -1,     6,
      -1,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,     3,    40,    -1,     6,    -1,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,     3,    40,
      -1,     6,    -1,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,     3,    40,    -1,     6,    -1,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
       3,    40,    -1,     6,    -1,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,     6,    40,    -1,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      40
  };

  const signed char
  IclParser::yystos_[] =
  {
       0,    49,     0,     6,     8,    50,     3,    39,    51,     6,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    40,    52,
      53,    55,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,    39,     3,     3,     3,    47,    47,
      47,    39,    39,    39,    41,    54,    54,    54,    38,     3,
      39,    58,    39,    38,    54,     3,     4,     5,    63,    64,
      65,     5,    63,    56,    56,    56,     4,    39,    43,    39,
      43,    38,     3,    39,    56,     6,    40,    62,    64,     3,
      60,     3,    39,    43,    43,    41,    46,    43,    39,    43,
       3,     6,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    40,    61,    40,    40,    42,    44,    56,
      56,     3,    39,    43,    57,    40,    43,     7,    40,    45,
      39,    56,     4,     3,     4,    56,     3,    43,    47,    63,
       4,    40,    40,    39,    43,    56,     6,    40,    63,    64,
       3,    59,    40,    42,    44,    40,    47,    63,    43,    42,
      56,    40,    44,     6,    40,    61,     4,    63,    43,    40,
      63,     3,    39,    43,    63,    42,    43,    43,    47,    59,
      43,    63,    40,    43
  };

  const signed char
  IclParser::yyr1_[] =
  {
       0,    48,    49,    49,    49,    50,    51,    51,    52,    52,
      52,    52,    52,    52,    52,    52,    52,    52,    52,    52,
      52,    52,    52,    52,    52,    52,    52,    52,    52,    52,
      53,    53,    53,    53,    53,    53,    53,    53,    53,    53,
      53,    53,    53,    54,    54,    54,    55,    55,    56,    56,
      56,    56,    56,    56,    57,    57,    57,    58,    58,    58,
      59,    59,    59,    59,    59,    59,    60,    60,    61,    61,
      61,    61,    61,    61,    61,    61,    61,    61,    61,    61,
      61,    61,    61,    61,    61,    61,    61,    61,    61,    61,
      61,    61,    61,    61,    61,    61,    61,    61,    61,    61,
      62,    62,    63,    64,    64,    64,    64,    64,    65,    65,
      65
  };

  const signed char
  IclParser::yyr2_[] =
  {
       0,     2,     0,     2,     2,     5,     0,     2,     1,     5,
       5,     5,     7,     5,     1,     5,     5,     6,     4,     6,
       4,     8,     6,     7,     5,     6,     5,     4,     5,     7,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     3,     5,     4,     6,     0,     2,
       3,     4,     5,     6,     0,     2,     5,     0,     2,     3,
       0,     2,     3,     4,     6,     5,     1,     3,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     3,     1,     1,     3,     3,     4,     6,     1,     1,
       1
  };


#if YYDEBUG
  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a YYNTOKENS, nonterminals.
  const char*
  const IclParser::yytname_[] =
  {
  "\"end of file\"", "error", "\"invalid token\"", "\"identifier\"",
  "\"number\"", "\"string\"", "\"comment\"", "\"->\"", "\"Module\"",
  "\"Parameter\"", "\"Attribute\"", "\"Alias\"", "\"Enum\"",
  "\"ScanInPort\"", "\"ScanOutPort\"", "\"ShiftEnPort\"",
  "\"CaptureEnPort\"", "\"UpdateEnPort\"", "\"SelectPort\"",
  "\"ResetPort\"", "\"TCKPort\"", "\"TMSPort\"", "\"ToDoPort\"",
  "\"ToSelectPort\"", "\"DataInPort\"", "\"DataOutPort\"",
  "\"ScanInterface\"", "\"OneHotScanInterface\"", "\"ScanRegister\"",
  "\"Reg\"", "\"Field\"", "\"Instance\"", "\"ScanMux\"", "\"LogicSignal\"",
  "\"Connection\"", "\"PortGroup\"", "\"AccessLink\"",
  "\"iProcsForModule\"", "\"Of\"", "\"{\"", "\"}\"", "\"[\"", "\"]\"",
  "\";\"", "\":\"", "\",\"", "\".\"", "\"=\"", "$accept", "file",
  "module_def", "module_item_list", "module_item", "port_keyword",
  "opt_range", "port_decl", "attr_body", "mux_body", "conn_body",
  "al_body", "ident_list", "attr_name", "conn_expr", "value", "postfix",
  "primary", YY_NULLPTR
  };
#endif


#if YYDEBUG
  const short
  IclParser::yyrline_[] =
  {
       0,   170,   170,   171,   173,   183,   192,   194,   199,   200,
     204,   208,   212,   220,   227,   228,   236,   244,   252,   256,
     263,   266,   274,   278,   286,   290,   298,   306,   313,   315,
     328,   329,   330,   331,   332,   333,   334,   335,   336,   337,
     338,   339,   340,   344,   345,   346,   350,   355,   366,   368,
     370,   374,   379,   384,   392,   394,   396,   404,   406,   408,
     416,   418,   420,   424,   429,   434,   445,   446,   453,   454,
     455,   456,   457,   458,   459,   460,   461,   462,   463,   464,
     465,   466,   467,   468,   469,   470,   471,   472,   473,   474,
     475,   476,   477,   478,   479,   480,   481,   482,   483,   484,
     490,   491,   495,   499,   500,   501,   502,   503,   507,   508,
     509
  };

  void
  IclParser::yy_stack_print_ () const
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  void
  IclParser::yy_reduce_print_ (int yyrule) const
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 42 "src/icl_parser.yy"
} // icl
#line 2109 "build/gen/icl_parser.cc"

#line 512 "src/icl_parser.yy"

