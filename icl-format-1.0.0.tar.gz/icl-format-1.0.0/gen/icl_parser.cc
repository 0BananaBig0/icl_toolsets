// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.





#include "icl_parser.hh"


// Unqualified %code blocks.
#line 74 "src/icl_parser.yy"

// Declared by the generated scanner (see icl_lexer.l). It must be visible at
// the parser's call site; this block lands after the parser class definition,
// so |IclParser::symbol_type| is a complete type here.
namespace icl {
IclParser::symbol_type yylex(IclDriver& driver);
}  // namespace icl
#line 83 "src/icl_parser.yy"

#include "icl_driver.h"

namespace icl {

// Reports the (first) syntax error. The driver owns the diagnostic state (it
// used to be a file-scope global); it keeps only the earliest error because
// later ones are cascades of it.
void IclParser::error(const location& loc, const std::string& message) {
  driver.SetParseDiagnostic(loc.begin.line, message);
}

}  // namespace icl

#line 69 "build/gen/icl_parser.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif


// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yy_stack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YY_USE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 42 "src/icl_parser.yy"
namespace icl {
#line 162 "build/gen/icl_parser.cc"

  /// Build a parser object.
  IclParser::IclParser (icl::IclDriver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      yy_lac_established_ (false),
      driver (driver_yyarg)
  {}

  IclParser::~IclParser ()
  {}

  IclParser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------.
  | symbol.  |
  `---------*/



  // by_state.
  IclParser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  IclParser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  IclParser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  IclParser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  IclParser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  IclParser::symbol_kind_type
  IclParser::by_state::kind () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return symbol_kind::S_YYEMPTY;
    else
      return YY_CAST (symbol_kind_type, yystos_[+state]);
  }

  IclParser::stack_symbol_type::stack_symbol_type ()
  {}

  IclParser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.YY_MOVE_OR_COPY< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.YY_MOVE_OR_COPY< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_range_bound: // range_bound
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.YY_MOVE_OR_COPY< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  IclParser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.move< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_range_bound: // range_bound
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.kind_ = symbol_kind::S_YYEMPTY;
  }

#if YY_CPLUSPLUS < 201103L
  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.copy< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.copy< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_range_bound: // range_bound
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.copy< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.copy< std::vector<AstNode*> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.move< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_range_bound: // range_bound
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  IclParser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  IclParser::yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YY_USE (yyoutput);
    if (yysym.empty ())
      yyo << "empty symbol";
    else
      {
        symbol_kind_type yykind = yysym.kind ();
        yyo << (yykind < YYNTOKENS ? "token" : "nterm")
            << ' ' << yysym.name () << " ("
            << yysym.location << ": ";
        switch (yykind)
    {
      case symbol_kind::S_IDENT: // "identifier"
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 474 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_NUMBER: // "number"
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 480 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_STRING: // "string"
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 486 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_COMMENT: // "comment"
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 492 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_PARAMREF: // "parameter reference"
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 498 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_OPERATOR: // "operator"
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 504 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_port_keyword: // port_keyword
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 510 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_range_bound: // range_bound
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 516 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_opt_range: // opt_range
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 522 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_ident_list: // ident_list
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 528 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_name: // attr_name
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 534 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_name_block_kw: // name_block_kw
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 540 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_range_block_kw: // range_block_kw
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 546 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_sel_block_kw: // sel_block_kw
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 552 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_of_block_kw: // of_block_kw
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 558 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_any_keyword: // any_keyword
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 564 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_conn_expr: // conn_expr
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 570 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value: // value
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 576 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_postfix: // postfix
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 582 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_primary: // primary
#line 202 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 588 "build/gen/icl_parser.cc"
        break;

      default:
        break;
    }
        yyo << ')';
      }
  }
#endif

  void
  IclParser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  IclParser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  IclParser::yypop_ (int n) YY_NOEXCEPT
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  IclParser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  IclParser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  IclParser::debug_level_type
  IclParser::debug_level () const
  {
    return yydebug_;
  }

  void
  IclParser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  IclParser::state_type
  IclParser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - YYNTOKENS] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - YYNTOKENS];
  }

  bool
  IclParser::yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  IclParser::yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yytable_ninf_;
  }

  int
  IclParser::operator() ()
  {
    return parse ();
  }

  int
  IclParser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

    // Discard the LAC context in case there still is one left from a
    // previous invocation.
    yy_lac_discard_ ("init");

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';
    YY_STACK_PRINT ();

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token\n";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    if (yyla.kind () == symbol_kind::S_YYerror)
    {
      // The scanner already issued an error message, process directly
      // to error recovery.  But do not keep the error token as
      // lookahead, it is too special and may lead us to an endless
      // loop in error recovery. */
      yyla.kind_ = symbol_kind::S_YYUNDEF;
      goto yyerrlab1;
    }

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.kind ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.kind ())
      {
        if (!yy_lac_establish_ (yyla.kind ()))
          goto yyerrlab;
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        if (!yy_lac_establish_ (yyla.kind ()))
          goto yyerrlab;

        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    yy_lac_discard_ ("shift");
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case symbol_kind::S_module_def: // module_def
        yylhs.value.emplace< AstBlock* > ();
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        yylhs.value.emplace< AstNode* > ();
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_range_bound: // range_bound
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        yylhs.value.emplace< std::string > ();
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        yylhs.value.emplace< std::vector<AstNode*> > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 3: // file: file module_def
#line 213 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(yystack_[0].value.as < AstBlock* > ()); }
#line 891 "build/gen/icl_parser.cc"
    break;

  case 4: // file: file "comment"
#line 215 "src/icl_parser.yy"
      {
        // Unlike the nested bodies below, the top-level rule has no vector to
        // append to, so the comment must be pushed onto the unit explicitly.
        driver.unit().top_level().push_back(
            driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)));
      }
#line 902 "build/gen/icl_parser.cc"
    break;

  case 5: // module_def: "Module" "identifier" "{" module_item_list "}"
#line 225 "src/icl_parser.yy"
      {
        yylhs.value.as < AstBlock* > () = driver.MakeBlock("Module " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 910 "build/gen/icl_parser.cc"
    break;

  case 6: // module_item_list: %empty
#line 232 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 916 "build/gen/icl_parser.cc"
    break;

  case 7: // module_item_list: module_item_list module_item
#line 234 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 922 "build/gen/icl_parser.cc"
    break;

  case 8: // module_item: "comment"
#line 238 "src/icl_parser.yy"
            { yylhs.value.as < AstNode* > () = driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)); }
#line 928 "build/gen/icl_parser.cc"
    break;

  case 9: // module_item: "Parameter" "identifier" "=" value ";"
#line 240 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Parameter " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 935 "build/gen/icl_parser.cc"
    break;

  case 10: // module_item: "Attribute" "identifier" "=" value ";"
#line 243 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Attribute " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 942 "build/gen/icl_parser.cc"
    break;

  case 11: // module_item: "Alias" "identifier" "=" value ";"
#line 246 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Alias " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 949 "build/gen/icl_parser.cc"
    break;

  case 12: // module_item: "Alias" "identifier" "=" value "{" attr_body "}"
#line 249 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Alias " + yystack_[5].value.as < std::string > () + " = " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 957 "build/gen/icl_parser.cc"
    break;

  case 13: // module_item: name_block_kw "identifier" "{" attr_body "}"
#line 257 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 966 "build/gen/icl_parser.cc"
    break;

  case 14: // module_item: range_block_kw "identifier" opt_range "{" attr_body "}"
#line 262 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 975 "build/gen/icl_parser.cc"
    break;

  case 15: // module_item: range_block_kw "identifier" opt_range ";"
#line 267 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 982 "build/gen/icl_parser.cc"
    break;

  case 16: // module_item: port_decl
#line 269 "src/icl_parser.yy"
              { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 988 "build/gen/icl_parser.cc"
    break;

  case 17: // module_item: sel_block_kw "identifier" "SelectedBy" value "{" mux_body "}"
#line 271 "src/icl_parser.yy"
      {
        // `SelectedBy` is part of the standard; the selector may be a
        // hierarchical name such as `MyTap.M3_sel`, hence |value| rather than
        // a bare IDENT.
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[6].value.as < std::string > () + " " + yystack_[5].value.as < std::string > () + " SelectedBy " + yystack_[3].value.as < std::string > (),
                              std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 1001 "build/gen/icl_parser.cc"
    break;

  case 18: // module_item: of_block_kw "identifier" "Of" "identifier" "{" attr_body "}"
#line 280 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[6].value.as < std::string > () + " " + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 1010 "build/gen/icl_parser.cc"
    break;

  case 19: // module_item: of_block_kw "identifier" "Of" "identifier" ";"
#line 285 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " Of " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1017 "build/gen/icl_parser.cc"
    break;

  case 20: // module_item: "LogicSignal" "identifier" "{" attr_body "}"
#line 288 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("LogicSignal " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 1026 "build/gen/icl_parser.cc"
    break;

  case 21: // module_item: "Connection" "{" conn_body "}"
#line 293 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Connection", std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
      }
#line 1035 "build/gen/icl_parser.cc"
    break;

  case 22: // module_item: "PortGroup" "identifier" "{" ident_list "}"
#line 298 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("PortGroup " + yystack_[3].value.as < std::string > () + " {" + yystack_[1].value.as < std::string > () + "}",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1042 "build/gen/icl_parser.cc"
    break;

  case 23: // port_keyword: "ScanInPort"
#line 305 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanInPort"; }
#line 1048 "build/gen/icl_parser.cc"
    break;

  case 24: // port_keyword: "ScanOutPort"
#line 306 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanOutPort"; }
#line 1054 "build/gen/icl_parser.cc"
    break;

  case 25: // port_keyword: "ShiftEnPort"
#line 307 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ShiftEnPort"; }
#line 1060 "build/gen/icl_parser.cc"
    break;

  case 26: // port_keyword: "CaptureEnPort"
#line 308 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "CaptureEnPort"; }
#line 1066 "build/gen/icl_parser.cc"
    break;

  case 27: // port_keyword: "UpdateEnPort"
#line 309 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "UpdateEnPort"; }
#line 1072 "build/gen/icl_parser.cc"
    break;

  case 28: // port_keyword: "SelectPort"
#line 310 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "SelectPort"; }
#line 1078 "build/gen/icl_parser.cc"
    break;

  case 29: // port_keyword: "ResetPort"
#line 311 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ResetPort"; }
#line 1084 "build/gen/icl_parser.cc"
    break;

  case 30: // port_keyword: "TCKPort"
#line 312 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TCKPort"; }
#line 1090 "build/gen/icl_parser.cc"
    break;

  case 31: // port_keyword: "ClockPort"
#line 313 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ClockPort"; }
#line 1096 "build/gen/icl_parser.cc"
    break;

  case 32: // port_keyword: "ToClockPort"
#line 314 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToClockPort"; }
#line 1102 "build/gen/icl_parser.cc"
    break;

  case 33: // port_keyword: "TMSPort"
#line 315 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TMSPort"; }
#line 1108 "build/gen/icl_parser.cc"
    break;

  case 34: // port_keyword: "TRSTPort"
#line 316 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TRSTPort"; }
#line 1114 "build/gen/icl_parser.cc"
    break;

  case 35: // port_keyword: "ToTCKPort"
#line 317 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTCKPort"; }
#line 1120 "build/gen/icl_parser.cc"
    break;

  case 36: // port_keyword: "ToTMSPort"
#line 318 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTMSPort"; }
#line 1126 "build/gen/icl_parser.cc"
    break;

  case 37: // port_keyword: "ToTRSTPort"
#line 319 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTRSTPort"; }
#line 1132 "build/gen/icl_parser.cc"
    break;

  case 38: // port_keyword: "ToShiftEnPort"
#line 320 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToShiftEnPort"; }
#line 1138 "build/gen/icl_parser.cc"
    break;

  case 39: // port_keyword: "ToCaptureEnPort"
#line 321 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToCaptureEnPort"; }
#line 1144 "build/gen/icl_parser.cc"
    break;

  case 40: // port_keyword: "ToUpdateEnPort"
#line 322 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToUpdateEnPort"; }
#line 1150 "build/gen/icl_parser.cc"
    break;

  case 41: // port_keyword: "ToResetPort"
#line 323 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToResetPort"; }
#line 1156 "build/gen/icl_parser.cc"
    break;

  case 42: // port_keyword: "ToDoPort"
#line 324 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToDoPort"; }
#line 1162 "build/gen/icl_parser.cc"
    break;

  case 43: // port_keyword: "ToSelectPort"
#line 325 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToSelectPort"; }
#line 1168 "build/gen/icl_parser.cc"
    break;

  case 44: // port_keyword: "DataInPort"
#line 326 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataInPort"; }
#line 1174 "build/gen/icl_parser.cc"
    break;

  case 45: // port_keyword: "DataOutPort"
#line 327 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataOutPort"; }
#line 1180 "build/gen/icl_parser.cc"
    break;

  case 46: // range_bound: "number"
#line 333 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1186 "build/gen/icl_parser.cc"
    break;

  case 47: // range_bound: "parameter reference"
#line 334 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1192 "build/gen/icl_parser.cc"
    break;

  case 48: // opt_range: %empty
#line 338 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = std::string(); }
#line 1198 "build/gen/icl_parser.cc"
    break;

  case 49: // opt_range: "[" range_bound "]"
#line 339 "src/icl_parser.yy"
                                             { yylhs.value.as < std::string > () = "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1204 "build/gen/icl_parser.cc"
    break;

  case 50: // opt_range: "[" range_bound ":" range_bound "]"
#line 340 "src/icl_parser.yy"
                                                    { yylhs.value.as < std::string > () = "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1210 "build/gen/icl_parser.cc"
    break;

  case 51: // port_decl: port_keyword "identifier" opt_range ";"
#line 345 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
      }
#line 1219 "build/gen/icl_parser.cc"
    break;

  case 52: // port_decl: port_keyword "identifier" opt_range "{" attr_body "}"
#line 350 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 1227 "build/gen/icl_parser.cc"
    break;

  case 53: // attr_item: attr_name ";"
#line 362 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1234 "build/gen/icl_parser.cc"
    break;

  case 54: // attr_item: attr_name value ";"
#line 365 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1241 "build/gen/icl_parser.cc"
    break;

  case 55: // attr_item: attr_name "=" value ";"
#line 368 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 1248 "build/gen/icl_parser.cc"
    break;

  case 56: // attr_item: attr_name value "=" value ";"
#line 380 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1255 "build/gen/icl_parser.cc"
    break;

  case 57: // mux_body: %empty
#line 388 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1261 "build/gen/icl_parser.cc"
    break;

  case 58: // mux_body: mux_body "comment"
#line 390 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1267 "build/gen/icl_parser.cc"
    break;

  case 59: // mux_body: mux_body value ":" value ";"
#line 392 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[3].value.as < std::string > () + " : " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1275 "build/gen/icl_parser.cc"
    break;

  case 60: // mux_body: mux_body value ";"
#line 398 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1283 "build/gen/icl_parser.cc"
    break;

  case 61: // conn_body: %empty
#line 405 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1289 "build/gen/icl_parser.cc"
    break;

  case 62: // conn_body: conn_body "comment"
#line 407 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1295 "build/gen/icl_parser.cc"
    break;

  case 63: // conn_body: conn_body conn_expr ";"
#line 409 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement( yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1303 "build/gen/icl_parser.cc"
    break;

  case 64: // attr_body: %empty
#line 421 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1309 "build/gen/icl_parser.cc"
    break;

  case 65: // attr_body: attr_body "comment"
#line 423 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (),
                                       SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1317 "build/gen/icl_parser.cc"
    break;

  case 66: // attr_body: attr_body attr_item
#line 427 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 1323 "build/gen/icl_parser.cc"
    break;

  case 67: // attr_body: attr_body attr_name "{" attr_body "}"
#line 429 "src/icl_parser.yy"
      {
        AstBlock* nested = driver.MakeBlock(yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                                           SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
        yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(nested);
      }
#line 1334 "build/gen/icl_parser.cc"
    break;

  case 68: // ident_list: "identifier"
#line 440 "src/icl_parser.yy"
                           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1340 "build/gen/icl_parser.cc"
    break;

  case 69: // ident_list: ident_list "," "identifier"
#line 441 "src/icl_parser.yy"
                           { yylhs.value.as < std::string > () = std::move(yystack_[2].value.as < std::string > ()) + ", " + yystack_[0].value.as < std::string > (); }
#line 1346 "build/gen/icl_parser.cc"
    break;

  case 70: // attr_name: "identifier"
#line 462 "src/icl_parser.yy"
                 { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1352 "build/gen/icl_parser.cc"
    break;

  case 71: // attr_name: any_keyword
#line 463 "src/icl_parser.yy"
                 { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1358 "build/gen/icl_parser.cc"
    break;

  case 72: // name_block_kw: "Enum"
#line 470 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Enum"; }
#line 1364 "build/gen/icl_parser.cc"
    break;

  case 73: // name_block_kw: "ScanInterface"
#line 471 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ScanInterface"; }
#line 1370 "build/gen/icl_parser.cc"
    break;

  case 74: // name_block_kw: "OneHotScanInterface"
#line 472 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "OneHotScanInterface"; }
#line 1376 "build/gen/icl_parser.cc"
    break;

  case 75: // name_block_kw: "OneHotScanGroup"
#line 473 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "OneHotScanGroup"; }
#line 1382 "build/gen/icl_parser.cc"
    break;

  case 76: // name_block_kw: "OneHotDataGroup"
#line 474 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "OneHotDataGroup"; }
#line 1388 "build/gen/icl_parser.cc"
    break;

  case 77: // range_block_kw: "ScanRegister"
#line 478 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ScanRegister"; }
#line 1394 "build/gen/icl_parser.cc"
    break;

  case 78: // range_block_kw: "DataRegister"
#line 479 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "DataRegister"; }
#line 1400 "build/gen/icl_parser.cc"
    break;

  case 79: // range_block_kw: "Reg"
#line 480 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Reg"; }
#line 1406 "build/gen/icl_parser.cc"
    break;

  case 80: // range_block_kw: "Field"
#line 481 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Field"; }
#line 1412 "build/gen/icl_parser.cc"
    break;

  case 81: // sel_block_kw: "ScanMux"
#line 485 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ScanMux"; }
#line 1418 "build/gen/icl_parser.cc"
    break;

  case 82: // sel_block_kw: "DataMux"
#line 486 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "DataMux"; }
#line 1424 "build/gen/icl_parser.cc"
    break;

  case 83: // sel_block_kw: "ClockMux"
#line 487 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ClockMux"; }
#line 1430 "build/gen/icl_parser.cc"
    break;

  case 84: // of_block_kw: "Instance"
#line 491 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Instance"; }
#line 1436 "build/gen/icl_parser.cc"
    break;

  case 85: // of_block_kw: "AccessLink"
#line 492 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "AccessLink"; }
#line 1442 "build/gen/icl_parser.cc"
    break;

  case 86: // any_keyword: name_block_kw
#line 498 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1448 "build/gen/icl_parser.cc"
    break;

  case 87: // any_keyword: range_block_kw
#line 499 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1454 "build/gen/icl_parser.cc"
    break;

  case 88: // any_keyword: sel_block_kw
#line 500 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1460 "build/gen/icl_parser.cc"
    break;

  case 89: // any_keyword: of_block_kw
#line 501 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1466 "build/gen/icl_parser.cc"
    break;

  case 90: // any_keyword: port_keyword
#line 502 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1472 "build/gen/icl_parser.cc"
    break;

  case 91: // any_keyword: "Module"
#line 503 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Module"; }
#line 1478 "build/gen/icl_parser.cc"
    break;

  case 92: // any_keyword: "Parameter"
#line 504 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Parameter"; }
#line 1484 "build/gen/icl_parser.cc"
    break;

  case 93: // any_keyword: "Attribute"
#line 505 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Attribute"; }
#line 1490 "build/gen/icl_parser.cc"
    break;

  case 94: // any_keyword: "Alias"
#line 506 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Alias"; }
#line 1496 "build/gen/icl_parser.cc"
    break;

  case 95: // any_keyword: "SelectedBy"
#line 507 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "SelectedBy"; }
#line 1502 "build/gen/icl_parser.cc"
    break;

  case 96: // any_keyword: "LogicSignal"
#line 508 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "LogicSignal"; }
#line 1508 "build/gen/icl_parser.cc"
    break;

  case 97: // any_keyword: "Connection"
#line 509 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Connection"; }
#line 1514 "build/gen/icl_parser.cc"
    break;

  case 98: // any_keyword: "PortGroup"
#line 510 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "PortGroup"; }
#line 1520 "build/gen/icl_parser.cc"
    break;

  case 99: // any_keyword: "Of"
#line 511 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Of"; }
#line 1526 "build/gen/icl_parser.cc"
    break;

  case 100: // conn_expr: postfix
#line 517 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1532 "build/gen/icl_parser.cc"
    break;

  case 101: // conn_expr: postfix "->" postfix
#line 518 "src/icl_parser.yy"
                          { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + " -> " + yystack_[0].value.as < std::string > (); }
#line 1538 "build/gen/icl_parser.cc"
    break;

  case 102: // value: postfix
#line 522 "src/icl_parser.yy"
            { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1544 "build/gen/icl_parser.cc"
    break;

  case 103: // value: "operator" value
#line 524 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = yystack_[1].value.as < std::string > () + yystack_[0].value.as < std::string > (); }
#line 1550 "build/gen/icl_parser.cc"
    break;

  case 104: // value: value "operator" value
#line 527 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + " " + yystack_[0].value.as < std::string > (); }
#line 1556 "build/gen/icl_parser.cc"
    break;

  case 105: // value: "(" value ")"
#line 528 "src/icl_parser.yy"
                        { yylhs.value.as < std::string > () = "(" + yystack_[1].value.as < std::string > () + ")"; }
#line 1562 "build/gen/icl_parser.cc"
    break;

  case 106: // postfix: primary
#line 532 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1568 "build/gen/icl_parser.cc"
    break;

  case 107: // postfix: postfix "." "identifier"
#line 533 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 1574 "build/gen/icl_parser.cc"
    break;

  case 108: // postfix: postfix "." "number"
#line 534 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 1580 "build/gen/icl_parser.cc"
    break;

  case 109: // postfix: postfix "[" range_bound "]"
#line 537 "src/icl_parser.yy"
      { yylhs.value.as < std::string > () = yystack_[3].value.as < std::string > () + "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1586 "build/gen/icl_parser.cc"
    break;

  case 110: // postfix: postfix "[" range_bound ":" range_bound "]"
#line 539 "src/icl_parser.yy"
      { yylhs.value.as < std::string > () = yystack_[5].value.as < std::string > () + "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1592 "build/gen/icl_parser.cc"
    break;

  case 111: // primary: "identifier"
#line 543 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1598 "build/gen/icl_parser.cc"
    break;

  case 112: // primary: "number"
#line 544 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1604 "build/gen/icl_parser.cc"
    break;

  case 113: // primary: "string"
#line 545 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1610 "build/gen/icl_parser.cc"
    break;

  case 114: // primary: "parameter reference"
#line 546 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1616 "build/gen/icl_parser.cc"
    break;


#line 1620 "build/gen/icl_parser.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        context yyctx (*this, yyla);
        std::string msg = yysyntax_error_ (yyctx);
        error (yyla.location, YY_MOVE (msg));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.kind () == symbol_kind::S_YYEOF)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    // Pop stack until we find a state that shifts the error token.
    for (;;)
      {
        yyn = yypact_[+yystack_[0].state];
        if (!yy_pact_value_is_default_ (yyn))
          {
            yyn += symbol_kind::S_YYerror;
            if (0 <= yyn && yyn <= yylast_
                && yycheck_[yyn] == symbol_kind::S_YYerror)
              {
                yyn = yytable_[yyn];
                if (0 < yyn)
                  break;
              }
          }

        // Pop the current state because it cannot handle the error token.
        if (yystack_.size () == 1)
          YYABORT;

        yyerror_range[1].location = yystack_[0].location;
        yy_destroy_ ("Error: popping", yystack_[0]);
        yypop_ ();
        YY_STACK_PRINT ();
      }
    {
      stack_symbol_type error_token;

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      yy_lac_discard_ ("error recovery");
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    YY_STACK_PRINT ();
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  IclParser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  const char *
  IclParser::symbol_name (symbol_kind_type yysymbol)
  {
    static const char *const yy_sname[] =
    {
    "end of file", "error", "invalid token", "identifier", "number",
  "string", "comment", "parameter reference", "->", "operator", "(", ")",
  "Module", "Parameter", "Attribute", "Alias", "Enum", "ScanInPort",
  "ScanOutPort", "ShiftEnPort", "CaptureEnPort", "UpdateEnPort",
  "SelectPort", "ResetPort", "ClockPort", "ToClockPort", "TCKPort",
  "TMSPort", "TRSTPort", "ToTCKPort", "ToTMSPort", "ToTRSTPort",
  "ToShiftEnPort", "ToCaptureEnPort", "ToUpdateEnPort", "ToResetPort",
  "ToDoPort", "ToSelectPort", "DataInPort", "DataOutPort", "ScanInterface",
  "OneHotScanInterface", "ScanRegister", "DataRegister", "Reg", "Field",
  "Instance", "ScanMux", "DataMux", "ClockMux", "OneHotScanGroup",
  "OneHotDataGroup", "SelectedBy", "LogicSignal", "Connection",
  "PortGroup", "AccessLink", "Of", "{", "}", "[", "]", ";", ":", ",", ".",
  "=", "$accept", "file", "module_def", "module_item_list", "module_item",
  "port_keyword", "range_bound", "opt_range", "port_decl", "attr_item",
  "mux_body", "conn_body", "attr_body", "ident_list", "attr_name",
  "name_block_kw", "range_block_kw", "sel_block_kw", "of_block_kw",
  "any_keyword", "conn_expr", "value", "postfix", "primary", YY_NULLPTR
    };
    return yy_sname[yysymbol];
  }



  // IclParser::context.
  IclParser::context::context (const IclParser& yyparser, const symbol_type& yyla)
    : yyparser_ (yyparser)
    , yyla_ (yyla)
  {}

  int
  IclParser::context::expected_tokens (symbol_kind_type yyarg[], int yyargn) const
  {
    // Actual number of expected tokens
    int yycount = 0;

#if YYDEBUG
    // Execute LAC once. We don't care if it is successful, we
    // only do it for the sake of debugging output.
    if (!yyparser_.yy_lac_established_)
      yyparser_.yy_lac_check_ (yyla_.kind ());
#endif

    for (int yyx = 0; yyx < YYNTOKENS; ++yyx)
      {
        symbol_kind_type yysym = YY_CAST (symbol_kind_type, yyx);
        if (yysym != symbol_kind::S_YYerror
            && yysym != symbol_kind::S_YYUNDEF
            && yyparser_.yy_lac_check_ (yysym))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = yysym;
          }
      }
    if (yyarg && yycount == 0 && 0 < yyargn)
      yyarg[0] = symbol_kind::S_YYEMPTY;
    return yycount;
  }




  bool
  IclParser::yy_lac_check_ (symbol_kind_type yytoken) const
  {
    // Logically, the yylac_stack's lifetime is confined to this function.
    // Clear it, to get rid of potential left-overs from previous call.
    yylac_stack_.clear ();
    // Reduce until we encounter a shift and thereby accept the token.
#if YYDEBUG
    YYCDEBUG << "LAC: checking lookahead " << symbol_name (yytoken) << ':';
#endif
    std::ptrdiff_t lac_top = 0;
    while (true)
      {
        state_type top_state = (yylac_stack_.empty ()
                                ? yystack_[lac_top].state
                                : yylac_stack_.back ());
        int yyrule = yypact_[+top_state];
        if (yy_pact_value_is_default_ (yyrule)
            || (yyrule += yytoken) < 0 || yylast_ < yyrule
            || yycheck_[yyrule] != yytoken)
          {
            // Use the default action.
            yyrule = yydefact_[+top_state];
            if (yyrule == 0)
              {
                YYCDEBUG << " Err\n";
                return false;
              }
          }
        else
          {
            // Use the action from yytable.
            yyrule = yytable_[yyrule];
            if (yy_table_value_is_error_ (yyrule))
              {
                YYCDEBUG << " Err\n";
                return false;
              }
            if (0 < yyrule)
              {
                YYCDEBUG << " S" << yyrule << '\n';
                return true;
              }
            yyrule = -yyrule;
          }
        // By now we know we have to simulate a reduce.
        YYCDEBUG << " R" << yyrule - 1;
        // Pop the corresponding number of values from the stack.
        {
          std::ptrdiff_t yylen = yyr2_[yyrule];
          // First pop from the LAC stack as many tokens as possible.
          std::ptrdiff_t lac_size = std::ptrdiff_t (yylac_stack_.size ());
          if (yylen < lac_size)
            {
              yylac_stack_.resize (std::size_t (lac_size - yylen));
              yylen = 0;
            }
          else if (lac_size)
            {
              yylac_stack_.clear ();
              yylen -= lac_size;
            }
          // Only afterwards look at the main stack.
          // We simulate popping elements by incrementing lac_top.
          lac_top += yylen;
        }
        // Keep top_state in sync with the updated stack.
        top_state = (yylac_stack_.empty ()
                     ? yystack_[lac_top].state
                     : yylac_stack_.back ());
        // Push the resulting state of the reduction.
        state_type state = yy_lr_goto_state_ (top_state, yyr1_[yyrule]);
        YYCDEBUG << " G" << int (state);
        yylac_stack_.push_back (state);
      }
  }

  // Establish the initial context if no initial context currently exists.
  bool
  IclParser::yy_lac_establish_ (symbol_kind_type yytoken)
  {
    /* Establish the initial context for the current lookahead if no initial
       context is currently established.

       We define a context as a snapshot of the parser stacks.  We define
       the initial context for a lookahead as the context in which the
       parser initially examines that lookahead in order to select a
       syntactic action.  Thus, if the lookahead eventually proves
       syntactically unacceptable (possibly in a later context reached via a
       series of reductions), the initial context can be used to determine
       the exact set of tokens that would be syntactically acceptable in the
       lookahead's place.  Moreover, it is the context after which any
       further semantic actions would be erroneous because they would be
       determined by a syntactically unacceptable token.

       yy_lac_establish_ should be invoked when a reduction is about to be
       performed in an inconsistent state (which, for the purposes of LAC,
       includes consistent states that don't know they're consistent because
       their default reductions have been disabled).

       For parse.lac=full, the implementation of yy_lac_establish_ is as
       follows.  If no initial context is currently established for the
       current lookahead, then check if that lookahead can eventually be
       shifted if syntactic actions continue from the current context.  */
    if (yy_lac_established_)
      return true;
    else
      {
#if YYDEBUG
        YYCDEBUG << "LAC: initial context established for "
                 << symbol_name (yytoken) << '\n';
#endif
        yy_lac_established_ = true;
        return yy_lac_check_ (yytoken);
      }
  }

  // Discard any previous initial lookahead context.
  void
  IclParser::yy_lac_discard_ (const char* event)
  {
   /* Discard any previous initial lookahead context because of Event,
      which may be a lookahead change or an invalidation of the currently
      established initial context for the current lookahead.

      The most common example of a lookahead change is a shift.  An example
      of both cases is syntax error recovery.  That is, a syntax error
      occurs when the lookahead is syntactically erroneous for the
      currently established initial context, so error recovery manipulates
      the parser stacks to try to find a new initial context in which the
      current lookahead is syntactically acceptable.  If it fails to find
      such a context, it discards the lookahead.  */
    if (yy_lac_established_)
      {
        YYCDEBUG << "LAC: initial context discarded due to "
                 << event << '\n';
        yy_lac_established_ = false;
      }
  }


  int
  IclParser::yy_syntax_error_arguments_ (const context& yyctx,
                                                 symbol_kind_type yyarg[], int yyargn) const
  {
    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
         In the first two cases, it might appear that the current syntax
         error should have been detected in the previous state when
         yy_lac_check was invoked.  However, at that time, there might
         have been a different syntax error that discarded a different
         initial context during error recovery, leaving behind the
         current lookahead.
    */

    if (!yyctx.lookahead ().empty ())
      {
        if (yyarg)
          yyarg[0] = yyctx.token ();
        int yyn = yyctx.expected_tokens (yyarg ? yyarg + 1 : yyarg, yyargn - 1);
        return yyn + 1;
      }
    return 0;
  }

  // Generate an error message.
  std::string
  IclParser::yysyntax_error_ (const context& yyctx) const
  {
    // Its maximum.
    enum { YYARGS_MAX = 5 };
    // Arguments of yyformat.
    symbol_kind_type yyarg[YYARGS_MAX];
    int yycount = yy_syntax_error_arguments_ (yyctx, yyarg, YYARGS_MAX);

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += symbol_name (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const signed char IclParser::yypact_ninf_ = -100;

  const signed char IclParser::yytable_ninf_ = -1;

  const short
  IclParser::yypact_[] =
  {
    -100,    44,  -100,  -100,    10,  -100,   -29,  -100,   485,  -100,
      62,    78,    89,  -100,  -100,  -100,  -100,  -100,  -100,  -100,
    -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,
    -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,
    -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,   104,
     -19,   108,  -100,  -100,  -100,   109,  -100,   110,   160,   162,
     163,    20,   102,   152,   111,  -100,   164,   107,   165,   107,
     168,   167,    48,    48,    48,  -100,    30,   218,    83,     8,
    -100,    15,    48,   270,  -100,  -100,  -100,  -100,    48,    48,
      16,   -46,  -100,    23,    21,   103,  -100,  -100,   214,     4,
    -100,   -10,  -100,  -100,   -15,  -100,  -100,   158,  -100,  -100,
      36,    22,  -100,    91,    48,  -100,    83,   101,  -100,  -100,
    -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,  -100,
    -100,  -100,  -100,  -100,  -100,     1,  -100,  -100,  -100,  -100,
    -100,  -100,    94,  -100,   272,  -100,    83,   213,  -100,   268,
    -100,  -100,  -100,  -100,  -100,    47,  -100,  -100,   323,  -100,
    -100,    48,     9,   -46,  -100,   216,  -100,  -100,    17,   378,
    -100,    83,  -100,   433,    29,  -100,    48,  -100,  -100,  -100,
      -2,  -100,   217,  -100,  -100,    31,  -100,    48,  -100,  -100,
      34,  -100
  };

  const signed char
  IclParser::yydefact_[] =
  {
       2,     0,     1,     4,     0,     3,     0,     6,     0,     8,
       0,     0,     0,    72,    23,    24,    25,    26,    27,    28,
      29,    31,    32,    30,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    73,    74,    77,
      78,    79,    80,    84,    81,    82,    83,    75,    76,     0,
       0,     0,    85,     5,     7,     0,    16,     0,     0,     0,
       0,     0,     0,     0,     0,    61,     0,    48,     0,    48,
       0,     0,     0,     0,     0,    64,     0,     0,     0,     0,
      64,     0,     0,     0,   111,   112,   113,   114,     0,     0,
       0,   102,   106,     0,     0,     0,    62,    21,     0,   100,
      68,     0,    46,    47,     0,    64,    51,     0,    64,    15,
       0,     0,   103,     0,     0,     9,     0,     0,    10,    64,
      11,    70,    65,    91,    92,    93,    94,    95,    96,    97,
      98,    99,    20,    90,    66,     0,    86,    87,    88,    89,
      71,    63,     0,    22,     0,    49,     0,     0,    13,     0,
      57,    64,    19,   105,   104,     0,   107,   108,     0,    64,
      53,     0,     0,   101,    69,     0,    52,    14,     0,     0,
     109,     0,    12,     0,     0,    54,     0,    50,    58,    17,
       0,    18,     0,    67,    55,     0,    60,     0,   110,    56,
       0,    59
  };

  const short
  IclParser::yypgoto_[] =
  {
    -100,  -100,  -100,  -100,  -100,   271,   -99,   259,  -100,  -100,
    -100,  -100,   -77,  -100,  -100,   322,   324,   325,   326,  -100,
    -100,   -73,   -74,  -100
  };

  const unsigned char
  IclParser::yydefgoto_[] =
  {
       0,     1,     5,     8,    54,   133,   104,    79,    56,   134,
     168,    76,    95,   101,   135,   136,   137,   138,   139,   140,
      98,    90,    91,    92
  };

  const unsigned char
  IclParser::yytable_[] =
  {
      93,    94,    99,   107,    84,    85,    86,   114,    87,   110,
      88,    89,   142,     6,   116,   112,   113,   155,   114,   117,
      84,    85,    86,   178,    87,   114,    88,    89,   147,     7,
     114,   149,   114,    84,    85,    86,    96,    87,   114,    65,
     114,   154,   158,   114,     2,   114,   145,   165,   146,   143,
       3,    84,    85,    86,   144,    87,     4,    88,    89,   159,
     186,   187,   162,   160,   116,    61,   105,   161,   163,   117,
     106,   175,   182,   108,   169,   176,   179,   109,   115,   119,
     151,    62,   173,   120,   152,   118,    72,   102,   174,    97,
     103,   184,    63,   189,   150,   180,   191,    84,    85,    86,
     114,    87,   153,   185,   156,   157,   121,    64,   170,   122,
     171,    66,    67,    68,   190,   123,   124,   125,   126,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,   127,   128,   129,   130,    52,
     131,   121,   132,    69,   122,    70,    71,    78,    73,    75,
     123,   124,   125,   126,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
     127,   128,   129,   130,    52,   131,   121,   148,    74,   122,
      82,   100,    77,    80,    83,   123,   124,   125,   126,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,   127,   128,   129,   130,    52,
     131,   121,   166,   111,   122,   164,   141,   177,   188,    55,
     123,   124,   125,   126,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
     127,   128,   129,   130,    52,   131,   121,   167,    81,   122,
      57,     0,    58,    59,    60,   123,   124,   125,   126,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,   127,   128,   129,   130,    52,
     131,   121,   172,     0,   122,     0,     0,     0,     0,     0,
     123,   124,   125,   126,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
     127,   128,   129,   130,    52,   131,   121,   181,     0,   122,
       0,     0,     0,     0,     0,   123,   124,   125,   126,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,   127,   128,   129,   130,    52,
     131,     9,   183,     0,     0,     0,     0,     0,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,     0,    49,    50,
      51,    52,     0,     0,    53
  };

  const short
  IclParser::yycheck_[] =
  {
      73,    74,    76,    80,     3,     4,     5,     9,     7,    82,
       9,    10,     8,     3,    60,    88,    89,   116,     9,    65,
       3,     4,     5,     6,     7,     9,     9,    10,   105,    58,
       9,   108,     9,     3,     4,     5,     6,     7,     9,    58,
       9,   114,   119,     9,     0,     9,    61,   146,    63,    59,
       6,     3,     4,     5,    64,     7,    12,     9,    10,    58,
      62,    63,   135,    62,    60,     3,    58,    66,   142,    65,
      62,    62,   171,    58,   151,    66,    59,    62,    62,    58,
      58,     3,   159,    62,    62,    62,    66,     4,   161,    59,
       7,    62,     3,    62,    58,   168,    62,     3,     4,     5,
       9,     7,    11,   176,     3,     4,     3,     3,    61,     6,
      63,     3,     3,     3,   187,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,     3,    59,     3,     6,     3,     3,    60,    66,    58,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,     3,    59,    66,     6,
      52,     3,    58,    58,    57,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,     3,    59,     3,     6,     3,    62,    61,    61,     8,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,     3,    59,    69,     6,
       8,    -1,     8,     8,     8,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,     3,    59,    -1,     6,    -1,    -1,    -1,    -1,    -1,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,     3,    59,    -1,     6,
      -1,    -1,    -1,    -1,    -1,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,     6,    59,    -1,    -1,    -1,    -1,    -1,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    -1,    53,    54,
      55,    56,    -1,    -1,    59
  };

  const signed char
  IclParser::yystos_[] =
  {
       0,    68,     0,     6,    12,    69,     3,    58,    70,     6,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    53,
      54,    55,    56,    59,    71,    72,    75,    82,    83,    84,
      85,     3,     3,     3,     3,    58,     3,     3,     3,     3,
       3,     3,    66,    66,    66,    58,    78,    58,    60,    74,
      58,    74,    52,    57,     3,     4,     5,     7,     9,    10,
      88,    89,    90,    88,    88,    79,     6,    59,    87,    89,
       3,    80,     4,     7,    73,    58,    62,    79,    58,    62,
      88,     3,    88,    88,     9,    62,    60,    65,    62,    58,
      62,     3,     6,    12,    13,    14,    15,    52,    53,    54,
      55,    57,    59,    72,    76,    81,    82,    83,    84,    85,
      86,    62,     8,    59,    64,    61,    63,    79,    59,    79,
      58,    58,    62,    11,    88,    73,     3,     4,    79,    58,
      62,    66,    88,    89,     3,    73,    59,    59,    77,    79,
      61,    63,    59,    79,    88,    62,    66,    61,     6,    59,
      88,    59,    73,    59,    62,    88,    62,    63,    61,    62,
      88,    62
  };

  const signed char
  IclParser::yyr1_[] =
  {
       0,    67,    68,    68,    68,    69,    70,    70,    71,    71,
      71,    71,    71,    71,    71,    71,    71,    71,    71,    71,
      71,    71,    71,    72,    72,    72,    72,    72,    72,    72,
      72,    72,    72,    72,    72,    72,    72,    72,    72,    72,
      72,    72,    72,    72,    72,    72,    73,    73,    74,    74,
      74,    75,    75,    76,    76,    76,    76,    77,    77,    77,
      77,    78,    78,    78,    79,    79,    79,    79,    80,    80,
      81,    81,    82,    82,    82,    82,    82,    83,    83,    83,
      83,    84,    84,    84,    85,    85,    86,    86,    86,    86,
      86,    86,    86,    86,    86,    86,    86,    86,    86,    86,
      87,    87,    88,    88,    88,    88,    89,    89,    89,    89,
      89,    90,    90,    90,    90
  };

  const signed char
  IclParser::yyr2_[] =
  {
       0,     2,     0,     2,     2,     5,     0,     2,     1,     5,
       5,     5,     7,     5,     6,     4,     1,     7,     7,     5,
       5,     4,     5,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     0,     3,
       5,     4,     6,     2,     3,     4,     5,     0,     2,     5,
       3,     0,     2,     3,     0,     2,     2,     5,     1,     3,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     3,     1,     2,     3,     3,     1,     3,     3,     4,
       6,     1,     1,     1,     1
  };




#if YYDEBUG
  const short
  IclParser::yyrline_[] =
  {
       0,   211,   211,   212,   214,   224,   231,   233,   238,   239,
     242,   245,   248,   256,   261,   266,   269,   270,   279,   284,
     287,   292,   297,   305,   306,   307,   308,   309,   310,   311,
     312,   313,   314,   315,   316,   317,   318,   319,   320,   321,
     322,   323,   324,   325,   326,   327,   333,   334,   338,   339,
     340,   344,   349,   361,   364,   367,   379,   387,   389,   391,
     397,   404,   406,   408,   420,   422,   426,   428,   440,   441,
     462,   463,   470,   471,   472,   473,   474,   478,   479,   480,
     481,   485,   486,   487,   491,   492,   498,   499,   500,   501,
     502,   503,   504,   505,   506,   507,   508,   509,   510,   511,
     517,   518,   522,   524,   527,   528,   532,   533,   534,   536,
     538,   543,   544,   545,   546
  };

  void
  IclParser::yy_stack_print_ () const
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  void
  IclParser::yy_reduce_print_ (int yyrule) const
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 42 "src/icl_parser.yy"
} // icl
#line 2389 "build/gen/icl_parser.cc"

#line 549 "src/icl_parser.yy"

