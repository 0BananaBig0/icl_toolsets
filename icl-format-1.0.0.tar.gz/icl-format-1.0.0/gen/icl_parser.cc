// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.





#include "icl_parser.hh"


// Unqualified %code blocks.
#line 80 "src/icl_parser.yy"

// Declared by the generated scanner (see icl_lexer.l). It must be visible at
// the parser's call site; this block lands after the parser class definition,
// so |IclParser::symbol_type| is a complete type here.
namespace icl {
IclParser::symbol_type yylex(IclDriver& driver);
}  // namespace icl
#line 89 "src/icl_parser.yy"

#include "icl_driver.h"

namespace icl {

// Reports the (first) syntax error. The driver owns the diagnostic state (it
// used to be a file-scope global); it keeps only the earliest error because
// later ones are cascades of it.
void IclParser::error(const location& loc, const std::string& message) {
  driver.SetParseDiagnostic(loc.begin.line, message);
}

}  // namespace icl

#line 69 "build/gen/icl_parser.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif


// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yy_stack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YY_USE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 48 "src/icl_parser.yy"
namespace icl {
#line 162 "build/gen/icl_parser.cc"

  /// Build a parser object.
  IclParser::IclParser (icl::IclDriver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      yy_lac_established_ (false),
      driver (driver_yyarg)
  {}

  IclParser::~IclParser ()
  {}

  IclParser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------.
  | symbol.  |
  `---------*/



  // by_state.
  IclParser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  IclParser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  IclParser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  IclParser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  IclParser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  IclParser::symbol_kind_type
  IclParser::by_state::kind () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return symbol_kind::S_YYEMPTY;
    else
      return YY_CAST (symbol_kind_type, yystos_[+state]);
  }

  IclParser::stack_symbol_type::stack_symbol_type ()
  {}

  IclParser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.YY_MOVE_OR_COPY< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        value.YY_MOVE_OR_COPY< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.YY_MOVE_OR_COPY< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  IclParser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        value.move< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.kind_ = symbol_kind::S_YYEMPTY;
  }

#if YY_CPLUSPLUS < 201103L
  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.copy< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        value.copy< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.copy< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.copy< std::vector<AstNode*> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        value.move< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  IclParser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  IclParser::yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YY_USE (yyoutput);
    if (yysym.empty ())
      yyo << "empty symbol";
    else
      {
        symbol_kind_type yykind = yysym.kind ();
        yyo << (yykind < YYNTOKENS ? "token" : "nterm")
            << ' ' << yysym.name () << " ("
            << yysym.location << ": ";
        switch (yykind)
    {
      case symbol_kind::S_IDENT: // "identifier"
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 498 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_NUMBER: // "number"
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 504 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_STRING: // "string"
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 510 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_COMMENT: // "comment"
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 516 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_PARAMREF: // "parameter reference"
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 522 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_IPROCARG: // "<D>/<R>"
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 528 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_OPERATOR: // "operator"
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 534 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_port_keyword: // port_keyword
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 540 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_value: // attr_value
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 546 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 552 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value_list: // value_list
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 558 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_opt_range: // opt_range
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 564 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_ident_list: // ident_list
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 570 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 576 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_name: // attr_name
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 582 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_name_block_kw: // name_block_kw
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 588 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_range_block_kw: // range_block_kw
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 594 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_module_ref: // module_ref
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 600 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_sel_block_kw: // sel_block_kw
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 606 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_of_block_kw: // of_block_kw
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 612 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_any_keyword: // any_keyword
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 618 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value: // value
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 624 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_postfix: // postfix
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 630 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_primary: // primary
#line 218 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 636 "build/gen/icl_parser.cc"
        break;

      default:
        break;
    }
        yyo << ')';
      }
  }
#endif

  void
  IclParser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  IclParser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  IclParser::yypop_ (int n) YY_NOEXCEPT
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  IclParser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  IclParser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  IclParser::debug_level_type
  IclParser::debug_level () const
  {
    return yydebug_;
  }

  void
  IclParser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  IclParser::state_type
  IclParser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - YYNTOKENS] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - YYNTOKENS];
  }

  bool
  IclParser::yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  IclParser::yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yytable_ninf_;
  }

  int
  IclParser::operator() ()
  {
    return parse ();
  }

  int
  IclParser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

    // Discard the LAC context in case there still is one left from a
    // previous invocation.
    yy_lac_discard_ ("init");

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';
    YY_STACK_PRINT ();

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token\n";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    if (yyla.kind () == symbol_kind::S_YYerror)
    {
      // The scanner already issued an error message, process directly
      // to error recovery.  But do not keep the error token as
      // lookahead, it is too special and may lead us to an endless
      // loop in error recovery. */
      yyla.kind_ = symbol_kind::S_YYUNDEF;
      goto yyerrlab1;
    }

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.kind ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.kind ())
      {
        if (!yy_lac_establish_ (yyla.kind ()))
          goto yyerrlab;
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        if (!yy_lac_establish_ (yyla.kind ()))
          goto yyerrlab;

        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    yy_lac_discard_ ("shift");
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case symbol_kind::S_module_def: // module_def
        yylhs.value.emplace< AstBlock* > ();
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
      case symbol_kind::S_ns_stmt: // ns_stmt
        yylhs.value.emplace< AstNode* > ();
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_IPROCARG: // "<D>/<R>"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_attr_value: // attr_value
      case symbol_kind::S_value_no_lead_op: // value_no_lead_op
      case symbol_kind::S_value_list: // value_list
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_stmt_name: // attr_stmt_name
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_module_ref: // module_ref
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        yylhs.value.emplace< std::string > ();
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_logic_body: // logic_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        yylhs.value.emplace< std::vector<AstNode*> > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 3: // file: file module_def
#line 229 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(yystack_[0].value.as < AstBlock* > ()); }
#line 945 "build/gen/icl_parser.cc"
    break;

  case 4: // file: file ns_stmt
#line 231 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 951 "build/gen/icl_parser.cc"
    break;

  case 5: // file: file "comment"
#line 233 "src/icl_parser.yy"
      {
        // Unlike the nested bodies below, the top-level rule has no vector to
        // append to, so the comment must be pushed onto the unit explicitly.
        driver.unit().top_level().push_back(
            driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)));
      }
#line 962 "build/gen/icl_parser.cc"
    break;

  case 6: // module_def: "Module" "identifier" "{" module_item_list "}"
#line 243 "src/icl_parser.yy"
      {
        yylhs.value.as < AstBlock* > () = driver.MakeBlock("Module " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 970 "build/gen/icl_parser.cc"
    break;

  case 7: // module_item_list: %empty
#line 250 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 976 "build/gen/icl_parser.cc"
    break;

  case 8: // module_item_list: module_item_list module_item
#line 252 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 982 "build/gen/icl_parser.cc"
    break;

  case 9: // module_item: "comment"
#line 256 "src/icl_parser.yy"
            { yylhs.value.as < AstNode* > () = driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)); }
#line 988 "build/gen/icl_parser.cc"
    break;

  case 10: // module_item: "Parameter" "identifier" "=" value_list ";"
#line 258 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Parameter " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 995 "build/gen/icl_parser.cc"
    break;

  case 11: // module_item: "LocalParameter" "identifier" "=" value_list ";"
#line 261 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("LocalParameter " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1002 "build/gen/icl_parser.cc"
    break;

  case 12: // module_item: ns_stmt
#line 263 "src/icl_parser.yy"
            { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 1008 "build/gen/icl_parser.cc"
    break;

  case 13: // module_item: "Attribute" "identifier" "=" value_list ";"
#line 265 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Attribute " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1015 "build/gen/icl_parser.cc"
    break;

  case 14: // module_item: "Attribute" "identifier" ";"
#line 271 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Attribute " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1022 "build/gen/icl_parser.cc"
    break;

  case 15: // module_item: "Alias" "identifier" opt_range "=" value_list ";"
#line 281 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Alias " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line)); }
#line 1029 "build/gen/icl_parser.cc"
    break;

  case 16: // module_item: "Alias" "identifier" opt_range "=" value_list "{" attr_body "}"
#line 284 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Alias " + yystack_[6].value.as < std::string > () + yystack_[5].value.as < std::string > () + " = " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[7].location.begin.line, yystack_[0].location.end.line));
      }
#line 1038 "build/gen/icl_parser.cc"
    break;

  case 17: // module_item: name_block_kw "identifier" "{" attr_body "}"
#line 293 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 1047 "build/gen/icl_parser.cc"
    break;

  case 18: // module_item: range_block_kw "identifier" opt_range "{" attr_body "}"
#line 298 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 1056 "build/gen/icl_parser.cc"
    break;

  case 19: // module_item: range_block_kw "identifier" opt_range ";"
#line 303 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 1063 "build/gen/icl_parser.cc"
    break;

  case 20: // module_item: port_decl
#line 305 "src/icl_parser.yy"
              { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 1069 "build/gen/icl_parser.cc"
    break;

  case 21: // module_item: sel_block_kw "identifier" opt_range "SelectedBy" value_list "{" mux_body "}"
#line 307 "src/icl_parser.yy"
      {
        // `SelectedBy` is part of the standard; the selector may be a
        // hierarchical name such as `MyTap.M3_sel`, hence |value_list| rather
        // than a bare IDENT — and a *list*, because Tessent writes
        // `SelectedBy config_sib_shift_reg, enable_shift_reg` when a mux is
        // selected by more than one signal.
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[7].value.as < std::string > () + " " + yystack_[6].value.as < std::string > () + yystack_[5].value.as < std::string > () + " SelectedBy " + yystack_[3].value.as < std::string > (),
                              std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[7].location.begin.line, yystack_[0].location.end.line));
      }
#line 1084 "build/gen/icl_parser.cc"
    break;

  case 22: // module_item: sel_block_kw "identifier" opt_range value "{" mux_body "}"
#line 325 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[6].value.as < std::string > () + " " + yystack_[5].value.as < std::string > () + yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (),
                              std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 1094 "build/gen/icl_parser.cc"
    break;

  case 23: // module_item: of_block_kw "identifier" "Of" module_ref "{" attr_body "}"
#line 331 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[6].value.as < std::string > () + " " + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
      }
#line 1103 "build/gen/icl_parser.cc"
    break;

  case 24: // module_item: of_block_kw "identifier" "Of" module_ref ";"
#line 336 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " Of " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1110 "build/gen/icl_parser.cc"
    break;

  case 25: // module_item: "LogicSignal" "identifier" "{" logic_body "}"
#line 345 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("LogicSignal " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 1119 "build/gen/icl_parser.cc"
    break;

  case 26: // module_item: "Connection" "{" conn_body "}"
#line 350 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock("Connection", std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
      }
#line 1128 "build/gen/icl_parser.cc"
    break;

  case 27: // module_item: "PortGroup" "identifier" "{" ident_list "}"
#line 355 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("PortGroup " + yystack_[3].value.as < std::string > () + " {" + yystack_[1].value.as < std::string > () + "}",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1135 "build/gen/icl_parser.cc"
    break;

  case 28: // port_keyword: "ScanInPort"
#line 362 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanInPort"; }
#line 1141 "build/gen/icl_parser.cc"
    break;

  case 29: // port_keyword: "ToIRSelectPort"
#line 368 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToIRSelectPort"; }
#line 1147 "build/gen/icl_parser.cc"
    break;

  case 30: // port_keyword: "AddressPort"
#line 369 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "AddressPort"; }
#line 1153 "build/gen/icl_parser.cc"
    break;

  case 31: // port_keyword: "WriteEnPort"
#line 370 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "WriteEnPort"; }
#line 1159 "build/gen/icl_parser.cc"
    break;

  case 32: // port_keyword: "ReadEnPort"
#line 371 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ReadEnPort"; }
#line 1165 "build/gen/icl_parser.cc"
    break;

  case 33: // port_keyword: "ScanOutPort"
#line 372 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanOutPort"; }
#line 1171 "build/gen/icl_parser.cc"
    break;

  case 34: // port_keyword: "ShiftEnPort"
#line 373 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ShiftEnPort"; }
#line 1177 "build/gen/icl_parser.cc"
    break;

  case 35: // port_keyword: "CaptureEnPort"
#line 374 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "CaptureEnPort"; }
#line 1183 "build/gen/icl_parser.cc"
    break;

  case 36: // port_keyword: "UpdateEnPort"
#line 375 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "UpdateEnPort"; }
#line 1189 "build/gen/icl_parser.cc"
    break;

  case 37: // port_keyword: "SelectPort"
#line 376 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "SelectPort"; }
#line 1195 "build/gen/icl_parser.cc"
    break;

  case 38: // port_keyword: "ResetPort"
#line 377 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ResetPort"; }
#line 1201 "build/gen/icl_parser.cc"
    break;

  case 39: // port_keyword: "TCKPort"
#line 378 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TCKPort"; }
#line 1207 "build/gen/icl_parser.cc"
    break;

  case 40: // port_keyword: "ClockPort"
#line 379 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ClockPort"; }
#line 1213 "build/gen/icl_parser.cc"
    break;

  case 41: // port_keyword: "ToClockPort"
#line 380 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToClockPort"; }
#line 1219 "build/gen/icl_parser.cc"
    break;

  case 42: // port_keyword: "TMSPort"
#line 381 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TMSPort"; }
#line 1225 "build/gen/icl_parser.cc"
    break;

  case 43: // port_keyword: "TRSTPort"
#line 382 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TRSTPort"; }
#line 1231 "build/gen/icl_parser.cc"
    break;

  case 44: // port_keyword: "ToTCKPort"
#line 383 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTCKPort"; }
#line 1237 "build/gen/icl_parser.cc"
    break;

  case 45: // port_keyword: "ToTMSPort"
#line 384 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTMSPort"; }
#line 1243 "build/gen/icl_parser.cc"
    break;

  case 46: // port_keyword: "ToTRSTPort"
#line 385 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToTRSTPort"; }
#line 1249 "build/gen/icl_parser.cc"
    break;

  case 47: // port_keyword: "ToShiftEnPort"
#line 386 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToShiftEnPort"; }
#line 1255 "build/gen/icl_parser.cc"
    break;

  case 48: // port_keyword: "ToCaptureEnPort"
#line 387 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToCaptureEnPort"; }
#line 1261 "build/gen/icl_parser.cc"
    break;

  case 49: // port_keyword: "ToUpdateEnPort"
#line 388 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToUpdateEnPort"; }
#line 1267 "build/gen/icl_parser.cc"
    break;

  case 50: // port_keyword: "ToResetPort"
#line 389 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToResetPort"; }
#line 1273 "build/gen/icl_parser.cc"
    break;

  case 51: // port_keyword: "ToDoPort"
#line 390 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToDoPort"; }
#line 1279 "build/gen/icl_parser.cc"
    break;

  case 52: // port_keyword: "ToSelectPort"
#line 391 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToSelectPort"; }
#line 1285 "build/gen/icl_parser.cc"
    break;

  case 53: // port_keyword: "DataInPort"
#line 392 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataInPort"; }
#line 1291 "build/gen/icl_parser.cc"
    break;

  case 54: // port_keyword: "DataOutPort"
#line 393 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataOutPort"; }
#line 1297 "build/gen/icl_parser.cc"
    break;

  case 55: // attr_value: value_no_lead_op
#line 401 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1303 "build/gen/icl_parser.cc"
    break;

  case 56: // attr_value: attr_value "," value_no_lead_op
#line 402 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = std::move(yystack_[2].value.as < std::string > ()) + ", " + yystack_[0].value.as < std::string > (); }
#line 1309 "build/gen/icl_parser.cc"
    break;

  case 57: // attr_value: attr_value value_no_lead_op
#line 406 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = std::move(yystack_[1].value.as < std::string > ()) + " " + yystack_[0].value.as < std::string > (); }
#line 1315 "build/gen/icl_parser.cc"
    break;

  case 58: // value_no_lead_op: postfix
#line 410 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1321 "build/gen/icl_parser.cc"
    break;

  case 59: // value_no_lead_op: value_no_lead_op "::" postfix
#line 414 "src/icl_parser.yy"
                                    { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "::" + yystack_[0].value.as < std::string > (); }
#line 1327 "build/gen/icl_parser.cc"
    break;

  case 60: // logic_body: %empty
#line 422 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1333 "build/gen/icl_parser.cc"
    break;

  case 61: // logic_body: logic_body "comment"
#line 424 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (),
                                       SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1341 "build/gen/icl_parser.cc"
    break;

  case 62: // logic_body: logic_body value_list ";"
#line 428 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1349 "build/gen/icl_parser.cc"
    break;

  case 63: // logic_body: logic_body attr_name "=" value_list ";"
#line 432 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1357 "build/gen/icl_parser.cc"
    break;

  case 64: // logic_body: logic_body attr_name value_no_lead_op ";"
#line 440 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[3].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line))); }
#line 1365 "build/gen/icl_parser.cc"
    break;

  case 65: // logic_body: logic_body attr_name "{" attr_body "}"
#line 444 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeBlock(yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                                      SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1373 "build/gen/icl_parser.cc"
    break;

  case 66: // value_list: value
#line 456 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1379 "build/gen/icl_parser.cc"
    break;

  case 67: // value_list: value_list "," value
#line 457 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = std::move(yystack_[2].value.as < std::string > ()) + ", " + yystack_[0].value.as < std::string > (); }
#line 1385 "build/gen/icl_parser.cc"
    break;

  case 68: // opt_range: %empty
#line 465 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = std::string(); }
#line 1391 "build/gen/icl_parser.cc"
    break;

  case 69: // opt_range: "[" value "]"
#line 466 "src/icl_parser.yy"
                                       { yylhs.value.as < std::string > () = "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1397 "build/gen/icl_parser.cc"
    break;

  case 70: // opt_range: "[" value ":" value "]"
#line 467 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1403 "build/gen/icl_parser.cc"
    break;

  case 71: // port_decl: port_keyword "identifier" opt_range ";"
#line 472 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
      }
#line 1412 "build/gen/icl_parser.cc"
    break;

  case 72: // port_decl: port_keyword "identifier" opt_range "{" attr_body "}"
#line 477 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()), SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
      }
#line 1420 "build/gen/icl_parser.cc"
    break;

  case 73: // attr_item: attr_stmt_name ";"
#line 489 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1427 "build/gen/icl_parser.cc"
    break;

  case 74: // attr_item: attr_name attr_value ";"
#line 500 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1434 "build/gen/icl_parser.cc"
    break;

  case 75: // attr_item: attr_name "operator" value ";"
#line 506 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 1441 "build/gen/icl_parser.cc"
    break;

  case 76: // attr_item: attr_name "=" value_list ";"
#line 511 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 1448 "build/gen/icl_parser.cc"
    break;

  case 77: // attr_item: attr_name value "=" value_list ";"
#line 523 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1455 "build/gen/icl_parser.cc"
    break;

  case 78: // attr_item: attr_name postfix "{" attr_body "}"
#line 532 "src/icl_parser.yy"
      {
        // `postfix`, not `IDENT opt_range`: the name may be indexed
        // (`Field f[3:0] { ... }`), and using the same nonterminal as an
        // expression means the parser decides between "block" and
        // "statement" at `{` versus `;` — one token. Spelling it
        // `IDENT opt_range` instead makes it decide at `[`, which is one
        // token too early, and that is a real shift/reduce conflict: both
        // `Source a[3:0];` and `Field f[3:0] { }` start the same way.
        yylhs.value.as < AstNode* > () = driver.MakeBlock(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                              SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
      }
#line 1471 "build/gen/icl_parser.cc"
    break;

  case 79: // mux_body: %empty
#line 549 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1477 "build/gen/icl_parser.cc"
    break;

  case 80: // mux_body: mux_body "comment"
#line 551 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1483 "build/gen/icl_parser.cc"
    break;

  case 81: // mux_body: mux_body value_list ":" value_list ";"
#line 556 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[3].value.as < std::string > () + " : " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1491 "build/gen/icl_parser.cc"
    break;

  case 82: // mux_body: mux_body value ";"
#line 562 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1499 "build/gen/icl_parser.cc"
    break;

  case 83: // mux_body: mux_body attr_name "=" value_list ";"
#line 573 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1507 "build/gen/icl_parser.cc"
    break;

  case 84: // mux_body: mux_body attr_name "identifier" "=" value_list ";"
#line 579 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[5].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line))); }
#line 1515 "build/gen/icl_parser.cc"
    break;

  case 85: // conn_body: %empty
#line 586 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1521 "build/gen/icl_parser.cc"
    break;

  case 86: // conn_body: conn_body "comment"
#line 588 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1527 "build/gen/icl_parser.cc"
    break;

  case 87: // conn_body: conn_body value_list ";"
#line 590 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1535 "build/gen/icl_parser.cc"
    break;

  case 88: // attr_body: %empty
#line 602 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1541 "build/gen/icl_parser.cc"
    break;

  case 89: // attr_body: attr_body "comment"
#line 604 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (),
                                       SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1549 "build/gen/icl_parser.cc"
    break;

  case 90: // attr_body: attr_body attr_item
#line 608 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 1555 "build/gen/icl_parser.cc"
    break;

  case 91: // attr_body: attr_body attr_name "{" attr_body "}"
#line 610 "src/icl_parser.yy"
      {
        AstBlock* nested = driver.MakeBlock(yystack_[3].value.as < std::string > (), std::move(yystack_[1].value.as < std::vector<AstNode*> > ()),
                                           SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
        yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(nested);
      }
#line 1566 "build/gen/icl_parser.cc"
    break;

  case 92: // ident_list: "identifier"
#line 621 "src/icl_parser.yy"
                           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1572 "build/gen/icl_parser.cc"
    break;

  case 93: // ident_list: ident_list "," "identifier"
#line 622 "src/icl_parser.yy"
                           { yylhs.value.as < std::string > () = std::move(yystack_[2].value.as < std::string > ()) + ", " + yystack_[0].value.as < std::string > (); }
#line 1578 "build/gen/icl_parser.cc"
    break;

  case 94: // attr_stmt_name: any_keyword
#line 644 "src/icl_parser.yy"
                { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1584 "build/gen/icl_parser.cc"
    break;

  case 95: // attr_stmt_name: postfix
#line 645 "src/icl_parser.yy"
                { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1590 "build/gen/icl_parser.cc"
    break;

  case 96: // attr_name: "identifier"
#line 658 "src/icl_parser.yy"
                 { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1596 "build/gen/icl_parser.cc"
    break;

  case 97: // attr_name: any_keyword
#line 659 "src/icl_parser.yy"
                 { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1602 "build/gen/icl_parser.cc"
    break;

  case 98: // name_block_kw: "Enum"
#line 666 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Enum"; }
#line 1608 "build/gen/icl_parser.cc"
    break;

  case 99: // name_block_kw: "ScanInterface"
#line 667 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ScanInterface"; }
#line 1614 "build/gen/icl_parser.cc"
    break;

  case 100: // name_block_kw: "OneHotScanInterface"
#line 668 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "OneHotScanInterface"; }
#line 1620 "build/gen/icl_parser.cc"
    break;

  case 101: // name_block_kw: "OneHotScanGroup"
#line 669 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "OneHotScanGroup"; }
#line 1626 "build/gen/icl_parser.cc"
    break;

  case 102: // name_block_kw: "OneHotDataGroup"
#line 670 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "OneHotDataGroup"; }
#line 1632 "build/gen/icl_parser.cc"
    break;

  case 103: // range_block_kw: "ScanRegister"
#line 674 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ScanRegister"; }
#line 1638 "build/gen/icl_parser.cc"
    break;

  case 104: // range_block_kw: "DataRegister"
#line 675 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "DataRegister"; }
#line 1644 "build/gen/icl_parser.cc"
    break;

  case 105: // range_block_kw: "Reg"
#line 676 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Reg"; }
#line 1650 "build/gen/icl_parser.cc"
    break;

  case 106: // range_block_kw: "Field"
#line 677 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Field"; }
#line 1656 "build/gen/icl_parser.cc"
    break;

  case 107: // ns_stmt: "NameSpace" ";"
#line 684 "src/icl_parser.yy"
                                 { yylhs.value.as < AstNode* > () = driver.MakeStatement("NameSpace;",
                                     SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1663 "build/gen/icl_parser.cc"
    break;

  case 108: // ns_stmt: "NameSpace" "identifier" ";"
#line 686 "src/icl_parser.yy"
                                 { yylhs.value.as < AstNode* > () = driver.MakeStatement("NameSpace " + yystack_[1].value.as < std::string > () + ";",
                                     SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1670 "build/gen/icl_parser.cc"
    break;

  case 109: // ns_stmt: "UseNameSpace" ";"
#line 688 "src/icl_parser.yy"
                                 { yylhs.value.as < AstNode* > () = driver.MakeStatement("UseNameSpace;",
                                     SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1677 "build/gen/icl_parser.cc"
    break;

  case 110: // ns_stmt: "UseNameSpace" "identifier" ";"
#line 690 "src/icl_parser.yy"
                                 { yylhs.value.as < AstNode* > () = driver.MakeStatement("UseNameSpace " + yystack_[1].value.as < std::string > () + ";",
                                     SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1684 "build/gen/icl_parser.cc"
    break;

  case 111: // module_ref: "identifier"
#line 704 "src/icl_parser.yy"
                             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1690 "build/gen/icl_parser.cc"
    break;

  case 112: // module_ref: module_ref "::" "identifier"
#line 705 "src/icl_parser.yy"
                             { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "::" + yystack_[0].value.as < std::string > (); }
#line 1696 "build/gen/icl_parser.cc"
    break;

  case 113: // sel_block_kw: "ScanMux"
#line 710 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ScanMux"; }
#line 1702 "build/gen/icl_parser.cc"
    break;

  case 114: // sel_block_kw: "DataMux"
#line 711 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "DataMux"; }
#line 1708 "build/gen/icl_parser.cc"
    break;

  case 115: // sel_block_kw: "ClockMux"
#line 712 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "ClockMux"; }
#line 1714 "build/gen/icl_parser.cc"
    break;

  case 116: // of_block_kw: "Instance"
#line 716 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "Instance"; }
#line 1720 "build/gen/icl_parser.cc"
    break;

  case 117: // of_block_kw: "AccessLink"
#line 717 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = "AccessLink"; }
#line 1726 "build/gen/icl_parser.cc"
    break;

  case 118: // any_keyword: name_block_kw
#line 723 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1732 "build/gen/icl_parser.cc"
    break;

  case 119: // any_keyword: range_block_kw
#line 724 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1738 "build/gen/icl_parser.cc"
    break;

  case 120: // any_keyword: sel_block_kw
#line 725 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1744 "build/gen/icl_parser.cc"
    break;

  case 121: // any_keyword: of_block_kw
#line 726 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1750 "build/gen/icl_parser.cc"
    break;

  case 122: // any_keyword: port_keyword
#line 727 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1756 "build/gen/icl_parser.cc"
    break;

  case 123: // any_keyword: "Module"
#line 728 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Module"; }
#line 1762 "build/gen/icl_parser.cc"
    break;

  case 124: // any_keyword: "Parameter"
#line 729 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Parameter"; }
#line 1768 "build/gen/icl_parser.cc"
    break;

  case 125: // any_keyword: "Attribute"
#line 730 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Attribute"; }
#line 1774 "build/gen/icl_parser.cc"
    break;

  case 126: // any_keyword: "Alias"
#line 731 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Alias"; }
#line 1780 "build/gen/icl_parser.cc"
    break;

  case 127: // any_keyword: "SelectedBy"
#line 732 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "SelectedBy"; }
#line 1786 "build/gen/icl_parser.cc"
    break;

  case 128: // any_keyword: "LogicSignal"
#line 733 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "LogicSignal"; }
#line 1792 "build/gen/icl_parser.cc"
    break;

  case 129: // any_keyword: "Connection"
#line 734 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Connection"; }
#line 1798 "build/gen/icl_parser.cc"
    break;

  case 130: // any_keyword: "PortGroup"
#line 735 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "PortGroup"; }
#line 1804 "build/gen/icl_parser.cc"
    break;

  case 131: // any_keyword: "Of"
#line 736 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "Of"; }
#line 1810 "build/gen/icl_parser.cc"
    break;

  case 132: // any_keyword: "LocalParameter"
#line 737 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "LocalParameter"; }
#line 1816 "build/gen/icl_parser.cc"
    break;

  case 133: // any_keyword: "NameSpace"
#line 738 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "NameSpace"; }
#line 1822 "build/gen/icl_parser.cc"
    break;

  case 134: // any_keyword: "UseNameSpace"
#line 739 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "UseNameSpace"; }
#line 1828 "build/gen/icl_parser.cc"
    break;

  case 135: // value: postfix
#line 745 "src/icl_parser.yy"
            { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1834 "build/gen/icl_parser.cc"
    break;

  case 136: // value: postfix "->" postfix
#line 749 "src/icl_parser.yy"
                          { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + " -> " + yystack_[0].value.as < std::string > (); }
#line 1840 "build/gen/icl_parser.cc"
    break;

  case 137: // value: "operator" value
#line 751 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = yystack_[1].value.as < std::string > () + yystack_[0].value.as < std::string > (); }
#line 1846 "build/gen/icl_parser.cc"
    break;

  case 138: // value: value "operator" value
#line 754 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + " " + yystack_[0].value.as < std::string > (); }
#line 1852 "build/gen/icl_parser.cc"
    break;

  case 139: // value: "(" value_list ")"
#line 755 "src/icl_parser.yy"
                             { yylhs.value.as < std::string > () = "(" + yystack_[1].value.as < std::string > () + ")"; }
#line 1858 "build/gen/icl_parser.cc"
    break;

  case 140: // postfix: primary
#line 759 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1864 "build/gen/icl_parser.cc"
    break;

  case 141: // postfix: postfix "." "identifier"
#line 760 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 1870 "build/gen/icl_parser.cc"
    break;

  case 142: // postfix: postfix "[" value "]"
#line 763 "src/icl_parser.yy"
      { yylhs.value.as < std::string > () = yystack_[3].value.as < std::string > () + "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1876 "build/gen/icl_parser.cc"
    break;

  case 143: // postfix: postfix "[" value ":" value "]"
#line 765 "src/icl_parser.yy"
      { yylhs.value.as < std::string > () = yystack_[5].value.as < std::string > () + "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1882 "build/gen/icl_parser.cc"
    break;

  case 144: // primary: "identifier"
#line 769 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1888 "build/gen/icl_parser.cc"
    break;

  case 145: // primary: "number"
#line 770 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1894 "build/gen/icl_parser.cc"
    break;

  case 146: // primary: "string"
#line 771 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1900 "build/gen/icl_parser.cc"
    break;

  case 147: // primary: "parameter reference"
#line 772 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1906 "build/gen/icl_parser.cc"
    break;

  case 148: // primary: "<D>/<R>"
#line 774 "src/icl_parser.yy"
             { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1912 "build/gen/icl_parser.cc"
    break;


#line 1916 "build/gen/icl_parser.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        context yyctx (*this, yyla);
        std::string msg = yysyntax_error_ (yyctx);
        error (yyla.location, YY_MOVE (msg));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.kind () == symbol_kind::S_YYEOF)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    // Pop stack until we find a state that shifts the error token.
    for (;;)
      {
        yyn = yypact_[+yystack_[0].state];
        if (!yy_pact_value_is_default_ (yyn))
          {
            yyn += symbol_kind::S_YYerror;
            if (0 <= yyn && yyn <= yylast_
                && yycheck_[yyn] == symbol_kind::S_YYerror)
              {
                yyn = yytable_[yyn];
                if (0 < yyn)
                  break;
              }
          }

        // Pop the current state because it cannot handle the error token.
        if (yystack_.size () == 1)
          YYABORT;

        yyerror_range[1].location = yystack_[0].location;
        yy_destroy_ ("Error: popping", yystack_[0]);
        yypop_ ();
        YY_STACK_PRINT ();
      }
    {
      stack_symbol_type error_token;

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      yy_lac_discard_ ("error recovery");
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    YY_STACK_PRINT ();
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  IclParser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  const char *
  IclParser::symbol_name (symbol_kind_type yysymbol)
  {
    static const char *const yy_sname[] =
    {
    "end of file", "error", "invalid token", "identifier", "number",
  "string", "comment", "parameter reference", "<D>/<R>", "::",
  "ToIRSelectPort", "AddressPort", "WriteEnPort", "ReadEnPort",
  "NameSpace", "UseNameSpace", "LocalParameter", "->", "operator", "(",
  ")", "Module", "Parameter", "Attribute", "Alias", "Enum", "ScanInPort",
  "ScanOutPort", "ShiftEnPort", "CaptureEnPort", "UpdateEnPort",
  "SelectPort", "ResetPort", "ClockPort", "ToClockPort", "TCKPort",
  "TMSPort", "TRSTPort", "ToTCKPort", "ToTMSPort", "ToTRSTPort",
  "ToShiftEnPort", "ToCaptureEnPort", "ToUpdateEnPort", "ToResetPort",
  "ToDoPort", "ToSelectPort", "DataInPort", "DataOutPort", "ScanInterface",
  "OneHotScanInterface", "ScanRegister", "DataRegister", "Reg", "Field",
  "Instance", "ScanMux", "DataMux", "ClockMux", "OneHotScanGroup",
  "OneHotDataGroup", "SelectedBy", "LogicSignal", "Connection",
  "PortGroup", "AccessLink", "Of", "{", "}", "[", "]", ";", ":", ",", ".",
  "=", "$accept", "file", "module_def", "module_item_list", "module_item",
  "port_keyword", "attr_value", "value_no_lead_op", "logic_body",
  "value_list", "opt_range", "port_decl", "attr_item", "mux_body",
  "conn_body", "attr_body", "ident_list", "attr_stmt_name", "attr_name",
  "name_block_kw", "range_block_kw", "ns_stmt", "module_ref",
  "sel_block_kw", "of_block_kw", "any_keyword", "value", "postfix",
  "primary", YY_NULLPTR
    };
    return yy_sname[yysymbol];
  }



  // IclParser::context.
  IclParser::context::context (const IclParser& yyparser, const symbol_type& yyla)
    : yyparser_ (yyparser)
    , yyla_ (yyla)
  {}

  int
  IclParser::context::expected_tokens (symbol_kind_type yyarg[], int yyargn) const
  {
    // Actual number of expected tokens
    int yycount = 0;

#if YYDEBUG
    // Execute LAC once. We don't care if it is successful, we
    // only do it for the sake of debugging output.
    if (!yyparser_.yy_lac_established_)
      yyparser_.yy_lac_check_ (yyla_.kind ());
#endif

    for (int yyx = 0; yyx < YYNTOKENS; ++yyx)
      {
        symbol_kind_type yysym = YY_CAST (symbol_kind_type, yyx);
        if (yysym != symbol_kind::S_YYerror
            && yysym != symbol_kind::S_YYUNDEF
            && yyparser_.yy_lac_check_ (yysym))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = yysym;
          }
      }
    if (yyarg && yycount == 0 && 0 < yyargn)
      yyarg[0] = symbol_kind::S_YYEMPTY;
    return yycount;
  }




  bool
  IclParser::yy_lac_check_ (symbol_kind_type yytoken) const
  {
    // Logically, the yylac_stack's lifetime is confined to this function.
    // Clear it, to get rid of potential left-overs from previous call.
    yylac_stack_.clear ();
    // Reduce until we encounter a shift and thereby accept the token.
#if YYDEBUG
    YYCDEBUG << "LAC: checking lookahead " << symbol_name (yytoken) << ':';
#endif
    std::ptrdiff_t lac_top = 0;
    while (true)
      {
        state_type top_state = (yylac_stack_.empty ()
                                ? yystack_[lac_top].state
                                : yylac_stack_.back ());
        int yyrule = yypact_[+top_state];
        if (yy_pact_value_is_default_ (yyrule)
            || (yyrule += yytoken) < 0 || yylast_ < yyrule
            || yycheck_[yyrule] != yytoken)
          {
            // Use the default action.
            yyrule = yydefact_[+top_state];
            if (yyrule == 0)
              {
                YYCDEBUG << " Err\n";
                return false;
              }
          }
        else
          {
            // Use the action from yytable.
            yyrule = yytable_[yyrule];
            if (yy_table_value_is_error_ (yyrule))
              {
                YYCDEBUG << " Err\n";
                return false;
              }
            if (0 < yyrule)
              {
                YYCDEBUG << " S" << yyrule << '\n';
                return true;
              }
            yyrule = -yyrule;
          }
        // By now we know we have to simulate a reduce.
        YYCDEBUG << " R" << yyrule - 1;
        // Pop the corresponding number of values from the stack.
        {
          std::ptrdiff_t yylen = yyr2_[yyrule];
          // First pop from the LAC stack as many tokens as possible.
          std::ptrdiff_t lac_size = std::ptrdiff_t (yylac_stack_.size ());
          if (yylen < lac_size)
            {
              yylac_stack_.resize (std::size_t (lac_size - yylen));
              yylen = 0;
            }
          else if (lac_size)
            {
              yylac_stack_.clear ();
              yylen -= lac_size;
            }
          // Only afterwards look at the main stack.
          // We simulate popping elements by incrementing lac_top.
          lac_top += yylen;
        }
        // Keep top_state in sync with the updated stack.
        top_state = (yylac_stack_.empty ()
                     ? yystack_[lac_top].state
                     : yylac_stack_.back ());
        // Push the resulting state of the reduction.
        state_type state = yy_lr_goto_state_ (top_state, yyr1_[yyrule]);
        YYCDEBUG << " G" << int (state);
        yylac_stack_.push_back (state);
      }
  }

  // Establish the initial context if no initial context currently exists.
  bool
  IclParser::yy_lac_establish_ (symbol_kind_type yytoken)
  {
    /* Establish the initial context for the current lookahead if no initial
       context is currently established.

       We define a context as a snapshot of the parser stacks.  We define
       the initial context for a lookahead as the context in which the
       parser initially examines that lookahead in order to select a
       syntactic action.  Thus, if the lookahead eventually proves
       syntactically unacceptable (possibly in a later context reached via a
       series of reductions), the initial context can be used to determine
       the exact set of tokens that would be syntactically acceptable in the
       lookahead's place.  Moreover, it is the context after which any
       further semantic actions would be erroneous because they would be
       determined by a syntactically unacceptable token.

       yy_lac_establish_ should be invoked when a reduction is about to be
       performed in an inconsistent state (which, for the purposes of LAC,
       includes consistent states that don't know they're consistent because
       their default reductions have been disabled).

       For parse.lac=full, the implementation of yy_lac_establish_ is as
       follows.  If no initial context is currently established for the
       current lookahead, then check if that lookahead can eventually be
       shifted if syntactic actions continue from the current context.  */
    if (yy_lac_established_)
      return true;
    else
      {
#if YYDEBUG
        YYCDEBUG << "LAC: initial context established for "
                 << symbol_name (yytoken) << '\n';
#endif
        yy_lac_established_ = true;
        return yy_lac_check_ (yytoken);
      }
  }

  // Discard any previous initial lookahead context.
  void
  IclParser::yy_lac_discard_ (const char* event)
  {
   /* Discard any previous initial lookahead context because of Event,
      which may be a lookahead change or an invalidation of the currently
      established initial context for the current lookahead.

      The most common example of a lookahead change is a shift.  An example
      of both cases is syntax error recovery.  That is, a syntax error
      occurs when the lookahead is syntactically erroneous for the
      currently established initial context, so error recovery manipulates
      the parser stacks to try to find a new initial context in which the
      current lookahead is syntactically acceptable.  If it fails to find
      such a context, it discards the lookahead.  */
    if (yy_lac_established_)
      {
        YYCDEBUG << "LAC: initial context discarded due to "
                 << event << '\n';
        yy_lac_established_ = false;
      }
  }


  int
  IclParser::yy_syntax_error_arguments_ (const context& yyctx,
                                                 symbol_kind_type yyarg[], int yyargn) const
  {
    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
         In the first two cases, it might appear that the current syntax
         error should have been detected in the previous state when
         yy_lac_check was invoked.  However, at that time, there might
         have been a different syntax error that discarded a different
         initial context during error recovery, leaving behind the
         current lookahead.
    */

    if (!yyctx.lookahead ().empty ())
      {
        if (yyarg)
          yyarg[0] = yyctx.token ();
        int yyn = yyctx.expected_tokens (yyarg ? yyarg + 1 : yyarg, yyargn - 1);
        return yyn + 1;
      }
    return 0;
  }

  // Generate an error message.
  std::string
  IclParser::yysyntax_error_ (const context& yyctx) const
  {
    // Its maximum.
    enum { YYARGS_MAX = 5 };
    // Arguments of yyformat.
    symbol_kind_type yyarg[YYARGS_MAX];
    int yycount = yy_syntax_error_arguments_ (yyctx, yyarg, YYARGS_MAX);

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += symbol_name (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const signed char IclParser::yypact_ninf_ = -124;

  const short IclParser::yytable_ninf_ = -145;

  const short
  IclParser::yypact_[] =
  {
    -124,   135,  -124,  -124,     8,     9,    31,  -124,  -124,   -22,
    -124,    51,  -124,    72,  -124,  -124,  -124,   888,  -124,  -124,
    -124,  -124,  -124,   122,   131,   148,   156,  -124,  -124,  -124,
    -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,
    -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,
    -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,
    -124,  -124,  -124,   157,   101,   173,  -124,  -124,  -124,   181,
    -124,   184,   231,  -124,   239,   247,   178,   225,    61,   250,
     241,  -124,   249,   250,   307,   250,   250,   300,   961,   961,
    -124,   961,   961,   357,  -124,    65,   437,    81,  -124,   838,
     954,   495,  -124,  -124,  -124,  -124,  -124,   961,   961,   -58,
     488,    19,  -124,   311,   312,    29,   961,   167,  -124,  -124,
     377,  -124,   -18,  -124,  -124,   365,  -124,  -124,   961,    78,
    -124,    35,  -124,    18,  -124,   961,   961,   150,   961,   561,
    -124,  -124,  -124,   961,   -36,    93,  -124,  -124,  -124,  -124,
    -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,  -124,
    -124,   378,    38,  -124,  -124,  -124,  -124,  -124,  -124,  -124,
     569,   431,  -124,  -124,  -124,   559,    14,   567,    69,   497,
     -43,  -124,   693,  -124,  -124,  -124,   488,  -124,    69,    49,
    -124,    56,  -124,  -124,  -124,  -124,   961,    16,    69,  -124,
    -124,  -124,   961,  -124,   961,    57,   703,    45,    40,  -124,
    -124,   233,  -124,   563,  -124,   961,  -124,   629,   695,   443,
     150,  -124,   633,   761,   444,  -124,   150,   703,   961,  -124,
     299,  -124,  -124,   -46,     2,    58,  -124,    67,  -124,  -124,
    -124,    69,  -124,  -124,  -124,   703,   509,   827,  -124,   961,
     638,   961,  -124,  -124,  -124,  -124,   510,   961,   575,  -124,
     576,  -124,  -124,    73
  };

  const unsigned char
  IclParser::yydefact_[] =
  {
       2,     0,     1,     5,     0,     0,     0,     3,     4,     0,
     107,     0,   109,     0,   108,   110,     7,     0,     9,    29,
      30,    31,    32,     0,     0,     0,     0,    98,    28,    33,
      34,    35,    36,    37,    38,    40,    41,    39,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    99,   100,   103,   104,   105,   106,   116,   113,   114,
     115,   101,   102,     0,     0,     0,   117,     6,     8,     0,
      20,     0,     0,    12,     0,     0,     0,     0,     0,    68,
       0,    85,     0,    68,     0,    68,    68,     0,     0,     0,
      14,     0,     0,     0,    60,     0,     0,     0,    88,     0,
       0,     0,   144,   145,   146,   147,   148,     0,     0,     0,
      66,   135,   140,     0,     0,     0,     0,     0,    86,    26,
       0,    92,     0,    88,    71,     0,    88,    19,     0,     0,
     111,     0,   137,     0,    11,     0,     0,     0,     0,     0,
      10,    13,    69,     0,     0,    96,    61,   133,   134,   132,
     123,   124,   125,   126,   127,   128,   129,   130,   131,    25,
     122,     0,     0,   118,   119,   120,   121,    97,    87,    27,
       0,     0,    89,    17,    90,     0,     0,    97,    95,     0,
       0,    79,     0,    88,    24,   139,    67,   138,   136,     0,
     141,     0,    88,    15,    62,    88,     0,     0,    58,    93,
      72,    73,     0,    88,     0,     0,    55,     0,    58,    18,
      79,     0,   112,     0,   142,     0,    70,     0,     0,     0,
       0,    64,   137,     0,     0,    74,     0,    57,     0,    88,
       0,    80,    22,     0,     0,    66,    23,     0,    16,    65,
      63,    59,    75,    91,    76,    56,     0,     0,    21,     0,
       0,     0,    82,   143,    77,    78,     0,     0,     0,    81,
       0,    83,    84,    96
  };

  const short
  IclParser::yypgoto_[] =
  {
    -124,  -124,  -124,  -124,  -124,   697,  -124,   773,  -124,   -88,
     891,  -124,  -124,   505,  -124,  -117,  -124,  -124,  -113,   745,
     753,   762,  -124,   763,   764,  -107,   -84,  -123,  -124
  };

  const unsigned char
  IclParser::yydefgoto_[] =
  {
       0,     1,     7,    17,    68,   160,   205,   197,   117,   233,
      93,    70,   174,   211,    95,   125,   122,   175,   176,   163,
     164,     8,   131,   165,   166,   177,   110,   111,   112
  };

  const short
  IclParser::yytable_[] =
  {
     109,   113,   178,   114,   162,   250,   171,   120,   115,   179,
     167,     9,    11,   134,   188,   135,   129,   102,   103,   104,
     133,   105,   106,   132,   210,   220,   249,   135,   144,   161,
     135,   192,   202,   108,    13,   193,   137,   135,   185,   198,
     180,   102,   103,   104,   182,   105,   106,   136,   178,    14,
     169,   186,   187,   208,   189,   170,   178,   137,  -135,   191,
     102,   103,   104,   136,   105,   106,   213,   136,   102,   103,
     104,   118,   105,   106,   136,   217,   136,   251,   218,    10,
      12,   203,   198,   107,   108,   136,   223,   221,   138,   204,
     178,   135,   207,   139,   178,   178,   136,   241,   234,   142,
     178,   143,   183,   198,   167,   195,   184,   229,   219,   138,
    -144,  -144,   247,   196,   139,  -135,   224,   234,   222,   214,
     228,   215,    15,   167,   178,    76,   216,   235,   225,   252,
     226,   237,    90,   119,    77,     2,    91,   253,   138,    16,
     246,     3,  -144,   139,  -144,   181,   235,  -144,   123,     4,
       5,    78,   124,   102,   103,   104,     6,   105,   106,    79,
      80,   256,  -144,   258,  -144,  -144,  -144,  -144,    81,   260,
     145,   103,   104,   146,   105,   106,    82,    19,    20,    21,
      22,   147,   148,   149,    83,   107,   108,    84,   150,   151,
     152,   153,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,   154,   155,
     156,   157,    66,   158,    85,   159,   145,   103,   104,   231,
     105,   106,    86,    19,    20,    21,    22,   147,   148,   149,
      87,   107,   108,    88,   150,   151,   152,   153,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,   154,   155,   156,   157,    66,   158,
      89,   232,   145,   103,   104,   231,   105,   106,    94,    19,
      20,    21,    22,   147,   148,   149,    96,   107,   108,    92,
     150,   151,   152,   153,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
     154,   155,   156,   157,    66,   158,   101,   248,   263,   103,
     104,   172,   105,   106,    98,    19,    20,    21,    22,   147,
     148,   149,   140,   141,   135,   135,   150,   151,   152,   153,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,   154,   155,   156,   157,
      66,   158,   116,   173,   263,   103,   104,   172,   105,   106,
     121,    19,    20,    21,    22,   147,   148,   149,   168,   194,
     135,   135,   150,   151,   152,   153,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,   154,   155,   156,   157,    66,   158,   130,   200,
     263,   103,   104,   172,   105,   106,   136,    19,    20,    21,
      22,   147,   148,   149,   240,   244,   135,   135,   150,   151,
     152,   153,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,   154,   155,
     156,   157,    66,   158,   190,   209,   263,   103,   104,   172,
     105,   106,   199,    19,    20,    21,    22,   147,   148,   149,
     254,   259,   135,   135,   150,   151,   152,   153,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,   154,   155,   156,   157,    66,   158,
     201,   236,   263,   103,   104,   172,   105,   106,   -94,    19,
      20,    21,    22,   147,   148,   149,   261,   262,   135,   135,
     150,   151,   152,   153,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
     154,   155,   156,   157,    66,   158,   212,   238,   263,   103,
     104,   172,   105,   106,   242,    19,    20,    21,    22,   147,
     148,   149,   220,   257,    69,   230,   150,   151,   152,   153,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,   154,   155,   156,   157,
      66,   158,    71,   239,   263,   103,   104,   172,   105,   106,
      72,    19,    20,    21,    22,   147,   148,   149,     0,    73,
      74,    75,   150,   151,   152,   153,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,   154,   155,   156,   157,    66,   158,     0,   243,
     263,   103,   104,   172,   105,   106,     0,    19,    20,    21,
      22,   147,   148,   149,     0,     0,     0,     0,   150,   151,
     152,   153,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,   154,   155,
     156,   157,    66,   158,    18,   255,     0,     0,    19,    20,
      21,    22,     4,     5,    23,   126,     0,     0,     0,   127,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,   206,
      63,    64,    65,    66,     0,     0,    67,   102,   103,   104,
       0,   105,   106,     0,   102,   103,   104,     0,   105,   106,
       0,     0,   107,   108,    97,     0,    99,   100,   227,   107,
     108,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   245,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   128
  };

  const short
  IclParser::yycheck_[] =
  {
      88,    89,   125,    91,   117,     3,   123,    95,    92,   126,
     117,     3,     3,    71,   137,    73,   100,     3,     4,     5,
     108,     7,     8,   107,    67,     9,    72,    73,   116,   117,
      73,    67,    18,    19,     3,    71,    17,    73,    20,   162,
     128,     3,     4,     5,     9,     7,     8,    18,   171,    71,
      68,   135,   136,   176,   138,    73,   179,    17,    18,   143,
       3,     4,     5,    18,     7,     8,   183,    18,     3,     4,
       5,     6,     7,     8,    18,   192,    18,    75,   195,    71,
      71,    67,   205,    18,    19,    18,   203,    71,    69,    75,
     213,    73,   176,    74,   217,   218,    18,   220,   211,    70,
     223,    72,    67,   226,   211,    67,    71,    67,   196,    69,
      17,    18,   229,    75,    74,    75,   204,   230,   202,    70,
      75,    72,    71,   230,   247,     3,    70,   211,    71,    71,
      73,   215,    71,    68,     3,     0,    75,    70,    69,    67,
     228,     6,    69,    74,    71,    67,   230,    74,    67,    14,
      15,     3,    71,     3,     4,     5,    21,     7,     8,     3,
       3,   249,    69,   251,    71,    72,    73,    74,    67,   257,
       3,     4,     5,     6,     7,     8,     3,    10,    11,    12,
      13,    14,    15,    16,     3,    18,    19,     3,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,     3,    68,     3,     4,     5,     6,
       7,     8,     3,    10,    11,    12,    13,    14,    15,    16,
       3,    18,    19,    75,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      75,    68,     3,     4,     5,     6,     7,     8,    67,    10,
      11,    12,    13,    14,    15,    16,    67,    18,    19,    69,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    66,    68,     3,     4,
       5,     6,     7,     8,    67,    10,    11,    12,    13,    14,
      15,    16,    71,    71,    73,    73,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    75,    68,     3,     4,     5,     6,     7,     8,
       3,    10,    11,    12,    13,    14,    15,    16,    71,    71,
      73,    73,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,     3,    68,
       3,     4,     5,     6,     7,     8,    18,    10,    11,    12,
      13,    14,    15,    16,    71,    71,    73,    73,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,     3,    68,     3,     4,     5,     6,
       7,     8,     3,    10,    11,    12,    13,    14,    15,    16,
      71,    71,    73,    73,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      71,    68,     3,     4,     5,     6,     7,     8,    71,    10,
      11,    12,    13,    14,    15,    16,    71,    71,    73,    73,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,     3,    68,     3,     4,
       5,     6,     7,     8,    71,    10,    11,    12,    13,    14,
      15,    16,     9,    75,    17,   210,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    17,    68,     3,     4,     5,     6,     7,     8,
      17,    10,    11,    12,    13,    14,    15,    16,    -1,    17,
      17,    17,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    -1,    68,
       3,     4,     5,     6,     7,     8,    -1,    10,    11,    12,
      13,    14,    15,    16,    -1,    -1,    -1,    -1,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,     6,    68,    -1,    -1,    10,    11,
      12,    13,    14,    15,    16,    67,    -1,    -1,    -1,    71,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,   176,
      62,    63,    64,    65,    -1,    -1,    68,     3,     4,     5,
      -1,     7,     8,    -1,     3,     4,     5,    -1,     7,     8,
      -1,    -1,    18,    19,    83,    -1,    85,    86,   205,    18,
      19,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   226,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    61
  };

  const signed char
  IclParser::yystos_[] =
  {
       0,    77,     0,     6,    14,    15,    21,    78,    97,     3,
      71,     3,    71,     3,    71,    71,    67,    79,     6,    10,
      11,    12,    13,    16,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    62,    63,    64,    65,    68,    80,    81,
      87,    95,    96,    97,    99,   100,     3,     3,     3,     3,
       3,    67,     3,     3,     3,     3,     3,     3,    75,    75,
      71,    75,    69,    86,    67,    90,    67,    86,    67,    86,
      86,    66,     3,     4,     5,     7,     8,    18,    19,    85,
     102,   103,   104,    85,    85,   102,    75,    84,     6,    68,
      85,     3,    92,    67,    71,    91,    67,    71,    61,   102,
       3,    98,   102,    85,    71,    73,    18,    17,    69,    74,
      71,    71,    70,    72,    85,     3,     6,    14,    15,    16,
      21,    22,    23,    24,    61,    62,    63,    64,    66,    68,
      81,    85,    94,    95,    96,    99,   100,   101,    71,    68,
      73,    91,     6,    68,    88,    93,    94,   101,   103,    91,
      85,    67,     9,    67,    71,    20,   102,   102,   103,   102,
       3,   102,    67,    71,    71,    67,    75,    83,   103,     3,
      68,    71,    18,    67,    75,    82,    83,   102,   103,    68,
      67,    89,     3,    91,    70,    72,    70,    91,    91,    85,
       9,    71,   102,    91,    85,    71,    73,    83,    75,    67,
      89,     6,    68,    85,    94,   102,    68,   102,    68,    68,
      71,   103,    71,    68,    71,    83,    85,    91,    68,    72,
       3,    75,    71,    70,    71,    68,    85,    75,    85,    71,
      85,    71,    71,     3
  };

  const signed char
  IclParser::yyr1_[] =
  {
       0,    76,    77,    77,    77,    77,    78,    79,    79,    80,
      80,    80,    80,    80,    80,    80,    80,    80,    80,    80,
      80,    80,    80,    80,    80,    80,    80,    80,    81,    81,
      81,    81,    81,    81,    81,    81,    81,    81,    81,    81,
      81,    81,    81,    81,    81,    81,    81,    81,    81,    81,
      81,    81,    81,    81,    81,    82,    82,    82,    83,    83,
      84,    84,    84,    84,    84,    84,    85,    85,    86,    86,
      86,    87,    87,    88,    88,    88,    88,    88,    88,    89,
      89,    89,    89,    89,    89,    90,    90,    90,    91,    91,
      91,    91,    92,    92,    93,    93,    94,    94,    95,    95,
      95,    95,    95,    96,    96,    96,    96,    97,    97,    97,
      97,    98,    98,    99,    99,    99,   100,   100,   101,   101,
     101,   101,   101,   101,   101,   101,   101,   101,   101,   101,
     101,   101,   101,   101,   101,   102,   102,   102,   102,   102,
     103,   103,   103,   103,   104,   104,   104,   104,   104
  };

  const signed char
  IclParser::yyr2_[] =
  {
       0,     2,     0,     2,     2,     2,     5,     0,     2,     1,
       5,     5,     1,     5,     3,     6,     8,     5,     6,     4,
       1,     8,     7,     7,     5,     5,     4,     5,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     2,     1,     3,
       0,     2,     3,     5,     4,     5,     1,     3,     0,     3,
       5,     4,     6,     2,     3,     4,     4,     5,     5,     0,
       2,     5,     3,     5,     6,     0,     2,     3,     0,     2,
       2,     5,     1,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     3,     2,
       3,     1,     3,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     2,     3,     3,
       1,     3,     4,     6,     1,     1,     1,     1,     1
  };




#if YYDEBUG
  const short
  IclParser::yyrline_[] =
  {
       0,   227,   227,   228,   230,   232,   242,   249,   251,   256,
     257,   260,   263,   264,   270,   280,   283,   292,   297,   302,
     305,   306,   324,   330,   335,   344,   349,   354,   362,   368,
     369,   370,   371,   372,   373,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,   387,   388,
     389,   390,   391,   392,   393,   401,   402,   406,   410,   414,
     421,   423,   427,   431,   439,   443,   456,   457,   465,   466,
     467,   471,   476,   488,   499,   505,   510,   522,   531,   548,
     550,   555,   561,   572,   578,   585,   587,   589,   601,   603,
     607,   609,   621,   622,   644,   645,   658,   659,   666,   667,
     668,   669,   670,   674,   675,   676,   677,   684,   686,   688,
     690,   704,   705,   710,   711,   712,   716,   717,   723,   724,
     725,   726,   727,   728,   729,   730,   731,   732,   733,   734,
     735,   736,   737,   738,   739,   745,   749,   751,   754,   755,
     759,   760,   762,   764,   769,   770,   771,   772,   774
  };

  void
  IclParser::yy_stack_print_ () const
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  void
  IclParser::yy_reduce_print_ (int yyrule) const
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 48 "src/icl_parser.yy"
} // icl
#line 2813 "build/gen/icl_parser.cc"

#line 777 "src/icl_parser.yy"

