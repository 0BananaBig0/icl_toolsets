// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.





#include "icl_parser.hh"


// Unqualified %code blocks.
#line 66 "src/icl_parser.yy"

// Declared by the generated scanner (see icl_lexer.l). It must be visible at
// the parser's call site; this block lands after the parser class definition,
// so |IclParser::symbol_type| is a complete type here.
namespace icl {
IclParser::symbol_type yylex(IclDriver& driver);
}  // namespace icl
#line 75 "src/icl_parser.yy"

#include "icl_driver.h"

namespace icl {

// Reports the (first) syntax error. The driver owns the diagnostic state (it
// used to be a file-scope global); it keeps only the earliest error because
// later ones are cascades of it.
void IclParser::error(const location& loc, const std::string& message) {
  driver.SetParseDiagnostic(loc.begin.line, message);
}

}  // namespace icl

#line 69 "build/gen/icl_parser.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif


// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yy_stack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YY_USE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

#line 42 "src/icl_parser.yy"
namespace icl {
#line 162 "build/gen/icl_parser.cc"

  /// Build a parser object.
  IclParser::IclParser (icl::IclDriver& driver_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      driver (driver_yyarg)
  {}

  IclParser::~IclParser ()
  {}

  IclParser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------.
  | symbol.  |
  `---------*/



  // by_state.
  IclParser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  IclParser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  IclParser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  IclParser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  IclParser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  IclParser::symbol_kind_type
  IclParser::by_state::kind () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return symbol_kind::S_YYEMPTY;
    else
      return YY_CAST (symbol_kind_type, yystos_[+state]);
  }

  IclParser::stack_symbol_type::stack_symbol_type ()
  {}

  IclParser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.YY_MOVE_OR_COPY< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.YY_MOVE_OR_COPY< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        value.YY_MOVE_OR_COPY< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  IclParser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.move< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        value.move< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.kind_ = symbol_kind::S_YYEMPTY;
  }

#if YY_CPLUSPLUS < 201103L
  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.copy< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.copy< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.copy< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        value.copy< std::vector<AstNode*> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  IclParser::stack_symbol_type&
  IclParser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (that.value);
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.move< AstNode* > (that.value);
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (that.value);
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        value.move< std::vector<AstNode*> > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  IclParser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  IclParser::yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YY_USE (yyoutput);
    if (yysym.empty ())
      yyo << "empty symbol";
    else
      {
        symbol_kind_type yykind = yysym.kind ();
        yyo << (yykind < YYNTOKENS ? "token" : "nterm")
            << ' ' << yysym.name () << " ("
            << yysym.location << ": ";
        switch (yykind)
    {
      case symbol_kind::S_IDENT: // "identifier"
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 445 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_NUMBER: // "number"
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 451 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_STRING: // "string"
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 457 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_COMMENT: // "comment"
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 463 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_port_keyword: // port_keyword
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 469 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_opt_range: // opt_range
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 475 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_ident_list: // ident_list
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 481 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_attr_name: // attr_name
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 487 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_conn_expr: // conn_expr
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 493 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_value: // value
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 499 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_postfix: // postfix
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 505 "build/gen/icl_parser.cc"
        break;

      case symbol_kind::S_primary: // primary
#line 163 "src/icl_parser.yy"
                 { yyoutput << yysym.value.template as < std::string > (); }
#line 511 "build/gen/icl_parser.cc"
        break;

      default:
        break;
    }
        yyo << ')';
      }
  }
#endif

  void
  IclParser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  IclParser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  IclParser::yypop_ (int n) YY_NOEXCEPT
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  IclParser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  IclParser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  IclParser::debug_level_type
  IclParser::debug_level () const
  {
    return yydebug_;
  }

  void
  IclParser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  IclParser::state_type
  IclParser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - YYNTOKENS] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - YYNTOKENS];
  }

  bool
  IclParser::yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  IclParser::yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yytable_ninf_;
  }

  int
  IclParser::operator() ()
  {
    return parse ();
  }

  int
  IclParser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';
    YY_STACK_PRINT ();

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token\n";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (driver));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    if (yyla.kind () == symbol_kind::S_YYerror)
    {
      // The scanner already issued an error message, process directly
      // to error recovery.  But do not keep the error token as
      // lookahead, it is too special and may lead us to an endless
      // loop in error recovery. */
      yyla.kind_ = symbol_kind::S_YYUNDEF;
      goto yyerrlab1;
    }

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.kind ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.kind ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case symbol_kind::S_module_def: // module_def
        yylhs.value.emplace< AstBlock* > ();
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        yylhs.value.emplace< AstNode* > ();
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        yylhs.value.emplace< std::string > ();
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_attr_body: // attr_body
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_al_body: // al_body
        yylhs.value.emplace< std::vector<AstNode*> > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 3: // file: file module_def
#line 174 "src/icl_parser.yy"
      { driver.unit().top_level().push_back(yystack_[0].value.as < AstBlock* > ()); }
#line 797 "build/gen/icl_parser.cc"
    break;

  case 4: // file: file "comment"
#line 176 "src/icl_parser.yy"
      {
        // Unlike the nested bodies below, the top-level rule has no vector to
        // append to, so the comment must be pushed onto the unit explicitly.
        driver.unit().top_level().push_back(
            driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)));
      }
#line 808 "build/gen/icl_parser.cc"
    break;

  case 5: // module_def: "Module" "identifier" "{" module_item_list "}"
#line 186 "src/icl_parser.yy"
      {
        AstBlock* module = driver.MakeBlock("Module " + yystack_[3].value.as < std::string > (),
                                            SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        module->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstBlock* > () = module;
      }
#line 819 "build/gen/icl_parser.cc"
    break;

  case 6: // module_item_list: %empty
#line 196 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 825 "build/gen/icl_parser.cc"
    break;

  case 7: // module_item_list: module_item_list module_item
#line 198 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 831 "build/gen/icl_parser.cc"
    break;

  case 8: // module_item: "comment"
#line 202 "src/icl_parser.yy"
            { yylhs.value.as < AstNode* > () = driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line)); }
#line 837 "build/gen/icl_parser.cc"
    break;

  case 9: // module_item: "Parameter" "identifier" "=" value ";"
#line 204 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Parameter " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 844 "build/gen/icl_parser.cc"
    break;

  case 10: // module_item: "Attribute" "identifier" "=" "string" ";"
#line 207 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Attribute " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 851 "build/gen/icl_parser.cc"
    break;

  case 11: // module_item: "Alias" "identifier" "=" value ";"
#line 210 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Alias " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 858 "build/gen/icl_parser.cc"
    break;

  case 12: // module_item: "Alias" "identifier" "=" value "{" attr_body "}"
#line 213 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("Alias " + yystack_[5].value.as < std::string > () + " = " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 869 "build/gen/icl_parser.cc"
    break;

  case 13: // module_item: "Enum" "identifier" "{" attr_body "}"
#line 220 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("Enum " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 880 "build/gen/icl_parser.cc"
    break;

  case 14: // module_item: port_decl
#line 226 "src/icl_parser.yy"
              { yylhs.value.as < AstNode* > () = yystack_[0].value.as < AstNode* > (); }
#line 886 "build/gen/icl_parser.cc"
    break;

  case 15: // module_item: "ScanInterface" "identifier" "{" attr_body "}"
#line 228 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("ScanInterface " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 897 "build/gen/icl_parser.cc"
    break;

  case 16: // module_item: "OneHotScanInterface" "identifier" "{" attr_body "}"
#line 235 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("OneHotScanInterface " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 908 "build/gen/icl_parser.cc"
    break;

  case 17: // module_item: "ScanRegister" "identifier" opt_range "{" attr_body "}"
#line 242 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("ScanRegister " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 919 "build/gen/icl_parser.cc"
    break;

  case 18: // module_item: "ScanRegister" "identifier" opt_range ";"
#line 249 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("ScanRegister " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 926 "build/gen/icl_parser.cc"
    break;

  case 19: // module_item: "Reg" "identifier" opt_range "{" attr_body "}"
#line 252 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("Reg " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 937 "build/gen/icl_parser.cc"
    break;

  case 20: // module_item: "Reg" "identifier" opt_range ";"
#line 259 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement( "Reg " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 944 "build/gen/icl_parser.cc"
    break;

  case 21: // module_item: "Field" "identifier" opt_range "Of" "identifier" "{" attr_body "}"
#line 262 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("Field " + yystack_[6].value.as < std::string > () + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[7].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 955 "build/gen/icl_parser.cc"
    break;

  case 22: // module_item: "Field" "identifier" opt_range "Of" "identifier" ";"
#line 269 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement( "Field " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > () + " Of " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line)); }
#line 962 "build/gen/icl_parser.cc"
    break;

  case 23: // module_item: "Instance" "identifier" "Of" "identifier" "{" attr_body "}"
#line 272 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("Instance " + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 973 "build/gen/icl_parser.cc"
    break;

  case 24: // module_item: "Instance" "identifier" "Of" "identifier" ";"
#line 279 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("Instance " + yystack_[3].value.as < std::string > () + " Of " + yystack_[1].value.as < std::string > () + ";",
                                 SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 980 "build/gen/icl_parser.cc"
    break;

  case 25: // module_item: "ScanMux" "identifier" "identifier" "{" mux_body "}"
#line 282 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("ScanMux " + yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 991 "build/gen/icl_parser.cc"
    break;

  case 26: // module_item: "LogicSignal" "identifier" "{" attr_body "}"
#line 289 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("LogicSignal " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 1002 "build/gen/icl_parser.cc"
    break;

  case 27: // module_item: "Connection" "{" conn_body "}"
#line 296 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("Connection",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 1013 "build/gen/icl_parser.cc"
    break;

  case 28: // module_item: "PortGroup" "identifier" "{" ident_list "}"
#line 303 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement("PortGroup " + yystack_[3].value.as < std::string > () + " {" + yystack_[1].value.as < std::string > () + "}",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1020 "build/gen/icl_parser.cc"
    break;

  case 29: // module_item: "AccessLink" "identifier" "Of" "identifier" "{" al_body "}"
#line 306 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock("AccessLink " + yystack_[5].value.as < std::string > () + " Of " + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[6].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = block;
      }
#line 1031 "build/gen/icl_parser.cc"
    break;

  case 30: // port_keyword: "ScanInPort"
#line 317 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanInPort"; }
#line 1037 "build/gen/icl_parser.cc"
    break;

  case 31: // port_keyword: "ScanOutPort"
#line 318 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ScanOutPort"; }
#line 1043 "build/gen/icl_parser.cc"
    break;

  case 32: // port_keyword: "ShiftEnPort"
#line 319 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ShiftEnPort"; }
#line 1049 "build/gen/icl_parser.cc"
    break;

  case 33: // port_keyword: "CaptureEnPort"
#line 320 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "CaptureEnPort"; }
#line 1055 "build/gen/icl_parser.cc"
    break;

  case 34: // port_keyword: "UpdateEnPort"
#line 321 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "UpdateEnPort"; }
#line 1061 "build/gen/icl_parser.cc"
    break;

  case 35: // port_keyword: "SelectPort"
#line 322 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "SelectPort"; }
#line 1067 "build/gen/icl_parser.cc"
    break;

  case 36: // port_keyword: "ResetPort"
#line 323 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ResetPort"; }
#line 1073 "build/gen/icl_parser.cc"
    break;

  case 37: // port_keyword: "TCKPort"
#line 324 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TCKPort"; }
#line 1079 "build/gen/icl_parser.cc"
    break;

  case 38: // port_keyword: "TMSPort"
#line 325 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "TMSPort"; }
#line 1085 "build/gen/icl_parser.cc"
    break;

  case 39: // port_keyword: "ToDoPort"
#line 326 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToDoPort"; }
#line 1091 "build/gen/icl_parser.cc"
    break;

  case 40: // port_keyword: "ToSelectPort"
#line 327 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "ToSelectPort"; }
#line 1097 "build/gen/icl_parser.cc"
    break;

  case 41: // port_keyword: "DataInPort"
#line 328 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataInPort"; }
#line 1103 "build/gen/icl_parser.cc"
    break;

  case 42: // port_keyword: "DataOutPort"
#line 329 "src/icl_parser.yy"
                     { yylhs.value.as < std::string > () = "DataOutPort"; }
#line 1109 "build/gen/icl_parser.cc"
    break;

  case 43: // opt_range: %empty
#line 333 "src/icl_parser.yy"
                              { yylhs.value.as < std::string > () = std::string(); }
#line 1115 "build/gen/icl_parser.cc"
    break;

  case 44: // opt_range: "[" "number" "]"
#line 334 "src/icl_parser.yy"
                                        { yylhs.value.as < std::string > () = "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1121 "build/gen/icl_parser.cc"
    break;

  case 45: // opt_range: "[" "number" ":" "number" "]"
#line 335 "src/icl_parser.yy"
                                          { yylhs.value.as < std::string > () = "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1127 "build/gen/icl_parser.cc"
    break;

  case 46: // port_decl: port_keyword "identifier" opt_range ";"
#line 340 "src/icl_parser.yy"
      {
        yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " " + yystack_[2].value.as < std::string > () + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
      }
#line 1136 "build/gen/icl_parser.cc"
    break;

  case 47: // port_decl: port_keyword "identifier" opt_range "{" attr_body "}"
#line 345 "src/icl_parser.yy"
      {
        AstBlock* port = driver.MakeBlock(yystack_[5].value.as < std::string > () + " " + yystack_[4].value.as < std::string > () + yystack_[3].value.as < std::string > (),
                                          SpanOf(yystack_[5].location.begin.line, yystack_[0].location.end.line));
        port->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < AstNode* > () = port;
      }
#line 1147 "build/gen/icl_parser.cc"
    break;

  case 48: // attr_item: attr_name ";"
#line 360 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line)); }
#line 1154 "build/gen/icl_parser.cc"
    break;

  case 49: // attr_item: attr_name value ";"
#line 363 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[2].value.as < std::string > () + " " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[2].location.begin.line, yystack_[0].location.end.line)); }
#line 1161 "build/gen/icl_parser.cc"
    break;

  case 50: // attr_item: attr_name "=" value ";"
#line 366 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line)); }
#line 1168 "build/gen/icl_parser.cc"
    break;

  case 51: // attr_item: attr_name "identifier" "=" value ";"
#line 369 "src/icl_parser.yy"
      { yylhs.value.as < AstNode* > () = driver.MakeStatement(yystack_[4].value.as < std::string > () + " " + yystack_[3].value.as < std::string > () + " = " + yystack_[1].value.as < std::string > () + ";",
                                  SpanOf(yystack_[4].location.begin.line, yystack_[0].location.end.line)); }
#line 1175 "build/gen/icl_parser.cc"
    break;

  case 52: // attr_body: %empty
#line 375 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1181 "build/gen/icl_parser.cc"
    break;

  case 53: // attr_body: attr_body "comment"
#line 377 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (),
                                       SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1189 "build/gen/icl_parser.cc"
    break;

  case 54: // attr_body: attr_body attr_item
#line 381 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 1195 "build/gen/icl_parser.cc"
    break;

  case 55: // mux_body: %empty
#line 386 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1201 "build/gen/icl_parser.cc"
    break;

  case 56: // mux_body: mux_body "comment"
#line 388 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1207 "build/gen/icl_parser.cc"
    break;

  case 57: // mux_body: mux_body value ":" value ";"
#line 390 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement(yystack_[3].value.as < std::string > () + " : " + yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line))); }
#line 1215 "build/gen/icl_parser.cc"
    break;

  case 58: // conn_body: %empty
#line 397 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1221 "build/gen/icl_parser.cc"
    break;

  case 59: // conn_body: conn_body "comment"
#line 399 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (), SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1227 "build/gen/icl_parser.cc"
    break;

  case 60: // conn_body: conn_body conn_expr ";"
#line 401 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[2].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.MakeStatement( yystack_[1].value.as < std::string > () + ";",
                                          SpanOf(yystack_[1].location.begin.line, yystack_[0].location.end.line))); }
#line 1235 "build/gen/icl_parser.cc"
    break;

  case 61: // al_body: %empty
#line 409 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::vector<AstNode*>(); }
#line 1241 "build/gen/icl_parser.cc"
    break;

  case 62: // al_body: al_body "comment"
#line 411 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(driver.AddComment(yystack_[0].value.as < std::string > (),
                                       SpanOf(yystack_[0].location.begin.line, yystack_[0].location.end.line))); }
#line 1249 "build/gen/icl_parser.cc"
    break;

  case 63: // al_body: al_body attr_item
#line 415 "src/icl_parser.yy"
      { yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[1].value.as < std::vector<AstNode*> > ()); yylhs.value.as < std::vector<AstNode*> > ().push_back(yystack_[0].value.as < AstNode* > ()); }
#line 1255 "build/gen/icl_parser.cc"
    break;

  case 64: // al_body: al_body attr_name "{" al_body "}"
#line 417 "src/icl_parser.yy"
      {
        AstBlock* block = driver.MakeBlock(yystack_[3].value.as < std::string > (),
                                           SpanOf(yystack_[3].location.begin.line, yystack_[0].location.end.line));
        block->body() = std::move(yystack_[1].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > () = std::move(yystack_[4].value.as < std::vector<AstNode*> > ());
        yylhs.value.as < std::vector<AstNode*> > ().push_back(block);
      }
#line 1267 "build/gen/icl_parser.cc"
    break;

  case 65: // ident_list: "identifier"
#line 429 "src/icl_parser.yy"
                           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1273 "build/gen/icl_parser.cc"
    break;

  case 66: // ident_list: ident_list "," "identifier"
#line 430 "src/icl_parser.yy"
                           { yylhs.value.as < std::string > () = std::move(yystack_[2].value.as < std::string > ()) + ", " + yystack_[0].value.as < std::string > (); }
#line 1279 "build/gen/icl_parser.cc"
    break;

  case 67: // attr_name: "identifier"
#line 442 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1285 "build/gen/icl_parser.cc"
    break;

  case 68: // attr_name: "Module"
#line 443 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Module"; }
#line 1291 "build/gen/icl_parser.cc"
    break;

  case 69: // attr_name: "Parameter"
#line 444 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Parameter"; }
#line 1297 "build/gen/icl_parser.cc"
    break;

  case 70: // attr_name: "Attribute"
#line 445 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Attribute"; }
#line 1303 "build/gen/icl_parser.cc"
    break;

  case 71: // attr_name: "Alias"
#line 446 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Alias"; }
#line 1309 "build/gen/icl_parser.cc"
    break;

  case 72: // attr_name: "Enum"
#line 447 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Enum"; }
#line 1315 "build/gen/icl_parser.cc"
    break;

  case 73: // attr_name: "ScanInPort"
#line 448 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanInPort"; }
#line 1321 "build/gen/icl_parser.cc"
    break;

  case 74: // attr_name: "ScanOutPort"
#line 449 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanOutPort"; }
#line 1327 "build/gen/icl_parser.cc"
    break;

  case 75: // attr_name: "ShiftEnPort"
#line 450 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ShiftEnPort"; }
#line 1333 "build/gen/icl_parser.cc"
    break;

  case 76: // attr_name: "CaptureEnPort"
#line 451 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "CaptureEnPort"; }
#line 1339 "build/gen/icl_parser.cc"
    break;

  case 77: // attr_name: "UpdateEnPort"
#line 452 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "UpdateEnPort"; }
#line 1345 "build/gen/icl_parser.cc"
    break;

  case 78: // attr_name: "SelectPort"
#line 453 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "SelectPort"; }
#line 1351 "build/gen/icl_parser.cc"
    break;

  case 79: // attr_name: "ResetPort"
#line 454 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ResetPort"; }
#line 1357 "build/gen/icl_parser.cc"
    break;

  case 80: // attr_name: "TCKPort"
#line 455 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "TCKPort"; }
#line 1363 "build/gen/icl_parser.cc"
    break;

  case 81: // attr_name: "TMSPort"
#line 456 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "TMSPort"; }
#line 1369 "build/gen/icl_parser.cc"
    break;

  case 82: // attr_name: "ToDoPort"
#line 457 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToDoPort"; }
#line 1375 "build/gen/icl_parser.cc"
    break;

  case 83: // attr_name: "ToSelectPort"
#line 458 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ToSelectPort"; }
#line 1381 "build/gen/icl_parser.cc"
    break;

  case 84: // attr_name: "DataInPort"
#line 459 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "DataInPort"; }
#line 1387 "build/gen/icl_parser.cc"
    break;

  case 85: // attr_name: "DataOutPort"
#line 460 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "DataOutPort"; }
#line 1393 "build/gen/icl_parser.cc"
    break;

  case 86: // attr_name: "ScanInterface"
#line 461 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanInterface"; }
#line 1399 "build/gen/icl_parser.cc"
    break;

  case 87: // attr_name: "OneHotScanInterface"
#line 462 "src/icl_parser.yy"
                        { yylhs.value.as < std::string > () = "OneHotScanInterface"; }
#line 1405 "build/gen/icl_parser.cc"
    break;

  case 88: // attr_name: "ScanRegister"
#line 463 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanRegister"; }
#line 1411 "build/gen/icl_parser.cc"
    break;

  case 89: // attr_name: "Reg"
#line 464 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Reg"; }
#line 1417 "build/gen/icl_parser.cc"
    break;

  case 90: // attr_name: "Field"
#line 465 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Field"; }
#line 1423 "build/gen/icl_parser.cc"
    break;

  case 91: // attr_name: "Instance"
#line 466 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Instance"; }
#line 1429 "build/gen/icl_parser.cc"
    break;

  case 92: // attr_name: "ScanMux"
#line 467 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "ScanMux"; }
#line 1435 "build/gen/icl_parser.cc"
    break;

  case 93: // attr_name: "LogicSignal"
#line 468 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "LogicSignal"; }
#line 1441 "build/gen/icl_parser.cc"
    break;

  case 94: // attr_name: "Connection"
#line 469 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Connection"; }
#line 1447 "build/gen/icl_parser.cc"
    break;

  case 95: // attr_name: "PortGroup"
#line 470 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "PortGroup"; }
#line 1453 "build/gen/icl_parser.cc"
    break;

  case 96: // attr_name: "AccessLink"
#line 471 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "AccessLink"; }
#line 1459 "build/gen/icl_parser.cc"
    break;

  case 97: // attr_name: "iProcsForModule"
#line 472 "src/icl_parser.yy"
                    { yylhs.value.as < std::string > () = "iProcsForModule"; }
#line 1465 "build/gen/icl_parser.cc"
    break;

  case 98: // attr_name: "Of"
#line 473 "src/icl_parser.yy"
                   { yylhs.value.as < std::string > () = "Of"; }
#line 1471 "build/gen/icl_parser.cc"
    break;

  case 99: // conn_expr: postfix
#line 479 "src/icl_parser.yy"
                         { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1477 "build/gen/icl_parser.cc"
    break;

  case 100: // conn_expr: postfix "->" postfix
#line 480 "src/icl_parser.yy"
                          { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + " -> " + yystack_[0].value.as < std::string > (); }
#line 1483 "build/gen/icl_parser.cc"
    break;

  case 101: // value: postfix
#line 484 "src/icl_parser.yy"
            { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1489 "build/gen/icl_parser.cc"
    break;

  case 102: // postfix: primary
#line 488 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1495 "build/gen/icl_parser.cc"
    break;

  case 103: // postfix: postfix "." "identifier"
#line 489 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 1501 "build/gen/icl_parser.cc"
    break;

  case 104: // postfix: postfix "." "number"
#line 490 "src/icl_parser.yy"
                                      { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "." + yystack_[0].value.as < std::string > (); }
#line 1507 "build/gen/icl_parser.cc"
    break;

  case 105: // postfix: postfix "[" "number" "]"
#line 491 "src/icl_parser.yy"
                                                { yylhs.value.as < std::string > () = yystack_[3].value.as < std::string > () + "[" + yystack_[1].value.as < std::string > () + "]"; }
#line 1513 "build/gen/icl_parser.cc"
    break;

  case 106: // postfix: postfix "[" "number" ":" "number" "]"
#line 492 "src/icl_parser.yy"
                                                  { yylhs.value.as < std::string > () = yystack_[5].value.as < std::string > () + "[" + yystack_[3].value.as < std::string > () + ":" + yystack_[1].value.as < std::string > () + "]"; }
#line 1519 "build/gen/icl_parser.cc"
    break;

  case 107: // primary: "identifier"
#line 496 "src/icl_parser.yy"
           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1525 "build/gen/icl_parser.cc"
    break;

  case 108: // primary: "number"
#line 497 "src/icl_parser.yy"
           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1531 "build/gen/icl_parser.cc"
    break;

  case 109: // primary: "string"
#line 498 "src/icl_parser.yy"
           { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 1537 "build/gen/icl_parser.cc"
    break;


#line 1541 "build/gen/icl_parser.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        std::string msg = YY_("syntax error");
        error (yyla.location, YY_MOVE (msg));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.kind () == symbol_kind::S_YYEOF)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    // Pop stack until we find a state that shifts the error token.
    for (;;)
      {
        yyn = yypact_[+yystack_[0].state];
        if (!yy_pact_value_is_default_ (yyn))
          {
            yyn += symbol_kind::S_YYerror;
            if (0 <= yyn && yyn <= yylast_
                && yycheck_[yyn] == symbol_kind::S_YYerror)
              {
                yyn = yytable_[yyn];
                if (0 < yyn)
                  break;
              }
          }

        // Pop the current state because it cannot handle the error token.
        if (yystack_.size () == 1)
          YYABORT;

        yyerror_range[1].location = yystack_[0].location;
        yy_destroy_ ("Error: popping", yystack_[0]);
        yypop_ ();
        YY_STACK_PRINT ();
      }
    {
      stack_symbol_type error_token;

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    YY_STACK_PRINT ();
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  IclParser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

#if YYDEBUG || 0
  const char *
  IclParser::symbol_name (symbol_kind_type yysymbol)
  {
    return yytname_[yysymbol];
  }
#endif // #if YYDEBUG || 0









  const short IclParser::yypact_ninf_ = -174;

  const signed char IclParser::yytable_ninf_ = -1;

  const short
  IclParser::yypact_[] =
  {
    -174,    25,  -174,  -174,    12,  -174,     2,  -174,    49,  -174,
      23,    45,    51,    90,  -174,  -174,  -174,  -174,  -174,  -174,
    -174,  -174,  -174,  -174,  -174,  -174,  -174,    95,   106,   107,
     109,   110,   111,   113,   114,    79,   116,   117,  -174,  -174,
     118,  -174,    75,    76,    77,    86,    87,    88,    89,    89,
      89,    94,   125,   130,  -174,   132,   167,    89,    97,   202,
      97,  -174,  -174,  -174,   129,    -3,     8,   203,   240,   238,
    -174,    13,   276,   310,    47,  -174,  -174,  -174,   306,   -17,
    -174,   342,    48,   128,   164,   200,    61,  -174,  -174,  -174,
    -174,   312,    53,  -174,   236,  -174,  -174,   378,    -2,  -174,
     -13,   348,  -174,  -174,  -174,   347,   104,  -174,  -174,  -174,
    -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,
    -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,
    -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,  -174,
    -174,  -174,  -174,  -174,  -174,     9,  -174,  -174,  -174,   419,
     272,   308,    56,  -174,  -174,    17,  -174,  -174,    97,  -174,
     454,  -174,   344,    62,  -174,  -174,   380,   412,  -174,    97,
     450,   453,  -174,  -174,  -174,  -174,   416,  -174,  -174,   485,
     -17,  -174,   452,  -174,  -174,   527,  -174,    97,   520,  -174,
    -174,   488,  -174,    97,  -174,  -174,  -174,     3,   523,   525,
    -174,  -174,   526,  -174,  -174,  -174,  -174,   524,  -174
  };

  const signed char
  IclParser::yydefact_[] =
  {
       2,     0,     1,     4,     0,     3,     0,     6,     0,     8,
       0,     0,     0,     0,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     5,     7,
       0,    14,     0,     0,     0,     0,     0,     0,    43,    43,
      43,     0,     0,     0,    58,     0,     0,    43,     0,     0,
       0,    52,    52,    52,     0,     0,     0,     0,     0,     0,
      52,     0,     0,     0,     0,   107,   108,   109,     0,   101,
     102,     0,     0,     0,     0,     0,     0,    52,    18,    52,
      20,     0,     0,    55,     0,    59,    27,     0,    99,    65,
       0,     0,    52,    46,     9,     0,     0,    10,    52,    11,
      67,    53,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
      96,    97,    98,    13,    54,     0,    15,    16,    44,     0,
       0,     0,     0,    52,    24,     0,    26,    60,     0,    28,
       0,    61,     0,     0,   103,   104,     0,   107,    48,     0,
       0,     0,    17,    19,    52,    22,     0,    56,    25,     0,
     100,    66,     0,    47,   105,     0,    12,     0,     0,    49,
      45,     0,    23,     0,    62,    29,    63,     0,     0,     0,
      50,    21,     0,    61,   106,    51,    57,     0,    64
  };

  const short
  IclParser::yypgoto_[] =
  {
    -174,  -174,  -174,  -174,  -174,  -174,   -12,  -174,  -173,   -59,
    -174,  -174,   363,  -174,  -172,  -174,   -58,   -70,  -174
  };

  const unsigned char
  IclParser::yydefgoto_[] =
  {
       0,     1,     5,     8,    39,    40,    65,    41,   144,    83,
     155,    71,   182,   100,   145,    97,   170,    79,    80
  };

  const unsigned char
  IclParser::yytable_[] =
  {
      78,    98,    82,    84,    85,   158,   167,    76,    77,   196,
     197,    94,   167,    76,    77,     6,    75,    76,    77,    95,
      75,    76,    77,   177,   105,     2,    42,   159,   150,   106,
     151,     3,   160,     4,   196,   197,    87,    66,    67,   105,
      88,     7,   203,   162,   106,    74,   168,    89,    43,   166,
     169,    90,   168,    96,    44,     9,   169,   178,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,   102,   108,   180,    38,
     103,   109,   153,    45,   176,   174,   154,   179,    46,   175,
      75,    76,    77,   148,   184,   149,   185,   164,   165,    47,
      48,   188,    49,    50,    51,   191,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    69,   199,
      64,   110,    68,    86,   111,   202,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
     136,   137,   138,   139,   140,   141,   142,   110,   143,    70,
     111,    72,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
     130,   131,   132,   133,   134,   135,   136,   137,   138,   139,
     140,   141,   142,   110,   146,    73,   111,    81,   112,   113,
     114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
     134,   135,   136,   137,   138,   139,   140,   141,   142,   110,
     147,    91,   111,    92,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   121,   122,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,   134,   135,   136,   137,
     138,   139,   140,   141,   142,   110,   156,    93,   111,    99,
     112,   113,   114,   115,   116,   117,   118,   119,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   110,   172,   101,   111,   152,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
     136,   137,   138,   139,   140,   141,   142,   110,   173,   104,
     111,   163,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
     130,   131,   132,   133,   134,   135,   136,   137,   138,   139,
     140,   141,   142,   110,   183,   107,   111,   161,   112,   113,
     114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
     134,   135,   136,   137,   138,   139,   140,   141,   142,   110,
     186,   157,   111,   171,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   121,   122,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,   134,   135,   136,   137,
     138,   139,   140,   141,   142,   110,   192,   181,   194,   187,
     112,   113,   114,   115,   116,   117,   118,   119,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   110,   195,   189,   111,   190,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
     136,   137,   138,   139,   140,   141,   142,   110,   201,   193,
     194,   198,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
     130,   131,   132,   133,   134,   135,   136,   137,   138,   139,
     140,   141,   142,   200,   208,   204,   207,     0,   205,   206
  };

  const short
  IclParser::yycheck_[] =
  {
      58,    71,    60,    62,    63,     7,     3,     4,     5,   182,
     182,    70,     3,     4,     5,     3,     3,     4,     5,     6,
       3,     4,     5,     6,    41,     0,     3,    40,    87,    46,
      89,     6,    45,     8,   207,   207,    39,    49,    50,    41,
      43,    39,    39,   102,    46,    57,    43,    39,     3,   108,
      47,    43,    43,    40,     3,     6,    47,    40,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    39,    39,   158,    40,
      43,    43,    39,     3,   153,    39,    43,   155,     3,    43,
       3,     4,     5,    42,    42,    44,    44,     3,     4,     3,
       3,   169,     3,     3,     3,   174,     3,     3,    39,     3,
       3,     3,    47,    47,    47,    39,    39,    39,     3,   187,
      41,     3,    38,     4,     6,   193,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,     3,    40,    39,
       6,    39,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,     3,    40,    38,     6,     5,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,     3,
      40,    38,     6,     3,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,     3,    40,    39,     6,     3,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,     3,    40,     3,     6,     3,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,     3,    40,    43,
       6,     4,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,     3,    40,    43,     6,    39,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,     3,
      40,    43,     6,     4,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,     3,    40,     3,     6,    47,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,     3,    40,    43,     6,    42,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,     3,    40,    44,
       6,     4,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    43,    40,    42,   203,    -1,    43,    43
  };

  const signed char
  IclParser::yystos_[] =
  {
       0,    49,     0,     6,     8,    50,     3,    39,    51,     6,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    40,    52,
      53,    55,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,    39,     3,     3,     3,    47,    47,
      47,    39,    39,    39,    41,    54,    54,    54,    38,     3,
      39,    59,    39,    38,    54,     3,     4,     5,    64,    65,
      66,     5,    64,    57,    57,    57,     4,    39,    43,    39,
      43,    38,     3,    39,    57,     6,    40,    63,    65,     3,
      61,     3,    39,    43,    43,    41,    46,    43,    39,    43,
       3,     6,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    40,    56,    62,    40,    40,    42,    44,
      57,    57,     3,    39,    43,    58,    40,    43,     7,    40,
      45,    39,    57,     4,     3,     4,    57,     3,    43,    47,
      64,     4,    40,    40,    39,    43,    57,     6,    40,    64,
      65,     3,    60,    40,    42,    44,    40,    47,    64,    43,
      42,    57,    40,    44,     6,    40,    56,    62,     4,    64,
      43,    40,    64,    39,    42,    43,    43,    60,    40
  };

  const signed char
  IclParser::yyr1_[] =
  {
       0,    48,    49,    49,    49,    50,    51,    51,    52,    52,
      52,    52,    52,    52,    52,    52,    52,    52,    52,    52,
      52,    52,    52,    52,    52,    52,    52,    52,    52,    52,
      53,    53,    53,    53,    53,    53,    53,    53,    53,    53,
      53,    53,    53,    54,    54,    54,    55,    55,    56,    56,
      56,    56,    57,    57,    57,    58,    58,    58,    59,    59,
      59,    60,    60,    60,    60,    61,    61,    62,    62,    62,
      62,    62,    62,    62,    62,    62,    62,    62,    62,    62,
      62,    62,    62,    62,    62,    62,    62,    62,    62,    62,
      62,    62,    62,    62,    62,    62,    62,    62,    62,    63,
      63,    64,    65,    65,    65,    65,    65,    66,    66,    66
  };

  const signed char
  IclParser::yyr2_[] =
  {
       0,     2,     0,     2,     2,     5,     0,     2,     1,     5,
       5,     5,     7,     5,     1,     5,     5,     6,     4,     6,
       4,     8,     6,     7,     5,     6,     5,     4,     5,     7,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     3,     5,     4,     6,     2,     3,
       4,     5,     0,     2,     2,     0,     2,     5,     0,     2,
       3,     0,     2,     2,     5,     1,     3,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       3,     1,     1,     3,     3,     4,     6,     1,     1,     1
  };


#if YYDEBUG
  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a YYNTOKENS, nonterminals.
  const char*
  const IclParser::yytname_[] =
  {
  "\"end of file\"", "error", "\"invalid token\"", "\"identifier\"",
  "\"number\"", "\"string\"", "\"comment\"", "\"->\"", "\"Module\"",
  "\"Parameter\"", "\"Attribute\"", "\"Alias\"", "\"Enum\"",
  "\"ScanInPort\"", "\"ScanOutPort\"", "\"ShiftEnPort\"",
  "\"CaptureEnPort\"", "\"UpdateEnPort\"", "\"SelectPort\"",
  "\"ResetPort\"", "\"TCKPort\"", "\"TMSPort\"", "\"ToDoPort\"",
  "\"ToSelectPort\"", "\"DataInPort\"", "\"DataOutPort\"",
  "\"ScanInterface\"", "\"OneHotScanInterface\"", "\"ScanRegister\"",
  "\"Reg\"", "\"Field\"", "\"Instance\"", "\"ScanMux\"", "\"LogicSignal\"",
  "\"Connection\"", "\"PortGroup\"", "\"AccessLink\"",
  "\"iProcsForModule\"", "\"Of\"", "\"{\"", "\"}\"", "\"[\"", "\"]\"",
  "\";\"", "\":\"", "\",\"", "\".\"", "\"=\"", "$accept", "file",
  "module_def", "module_item_list", "module_item", "port_keyword",
  "opt_range", "port_decl", "attr_item", "attr_body", "mux_body",
  "conn_body", "al_body", "ident_list", "attr_name", "conn_expr", "value",
  "postfix", "primary", YY_NULLPTR
  };
#endif


#if YYDEBUG
  const short
  IclParser::yyrline_[] =
  {
       0,   172,   172,   173,   175,   185,   195,   197,   202,   203,
     206,   209,   212,   219,   226,   227,   234,   241,   248,   251,
     258,   261,   268,   271,   278,   281,   288,   295,   302,   305,
     317,   318,   319,   320,   321,   322,   323,   324,   325,   326,
     327,   328,   329,   333,   334,   335,   339,   344,   359,   362,
     365,   368,   374,   376,   380,   385,   387,   389,   396,   398,
     400,   408,   410,   414,   416,   429,   430,   442,   443,   444,
     445,   446,   447,   448,   449,   450,   451,   452,   453,   454,
     455,   456,   457,   458,   459,   460,   461,   462,   463,   464,
     465,   466,   467,   468,   469,   470,   471,   472,   473,   479,
     480,   484,   488,   489,   490,   491,   492,   496,   497,   498
  };

  void
  IclParser::yy_stack_print_ () const
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  void
  IclParser::yy_reduce_print_ (int yyrule) const
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


#line 42 "src/icl_parser.yy"
} // icl
#line 2060 "build/gen/icl_parser.cc"

#line 501 "src/icl_parser.yy"

