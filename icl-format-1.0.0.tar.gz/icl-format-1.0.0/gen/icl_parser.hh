// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton interface for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.


/**
 ** \file build/gen/icl_parser.hh
 ** Define the icl::parser class.
 */

// C++ LALR(1) parser skeleton written by Akim Demaille.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.

#ifndef YY_YY_BUILD_GEN_ICL_PARSER_HH_INCLUDED
# define YY_YY_BUILD_GEN_ICL_PARSER_HH_INCLUDED
// "%code requires" blocks.
#line 59 "src/icl_parser.yy"

#include <string>
#include <vector>

#include "icl_ast.h"

namespace icl {

class IclDriver;

}  // namespace icl

#line 62 "build/gen/icl_parser.hh"

# include <cassert>
# include <cstdlib> // std::abort
# include <iostream>
# include <stdexcept>
# include <string>
# include <vector>

#if defined __cplusplus
# define YY_CPLUSPLUS __cplusplus
#else
# define YY_CPLUSPLUS 199711L
#endif

// Support move semantics when possible.
#if 201103L <= YY_CPLUSPLUS
# define YY_MOVE           std::move
# define YY_MOVE_OR_COPY   move
# define YY_MOVE_REF(Type) Type&&
# define YY_RVREF(Type)    Type&&
# define YY_COPY(Type)     Type
#else
# define YY_MOVE
# define YY_MOVE_OR_COPY   copy
# define YY_MOVE_REF(Type) Type&
# define YY_RVREF(Type)    const Type&
# define YY_COPY(Type)     const Type&
#endif

// Support noexcept when possible.
#if 201103L <= YY_CPLUSPLUS
# define YY_NOEXCEPT noexcept
# define YY_NOTHROW
#else
# define YY_NOEXCEPT
# define YY_NOTHROW throw ()
#endif

// Support constexpr when possible.
#if 201703 <= YY_CPLUSPLUS
# define YY_CONSTEXPR constexpr
#else
# define YY_CONSTEXPR
#endif
# include "location.hh"
#include <typeinfo>
#ifndef YY_ASSERT
# include <cassert>
# define YY_ASSERT assert
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

#line 42 "src/icl_parser.yy"
namespace icl {
#line 203 "build/gen/icl_parser.hh"




  /// A Bison parser.
  class IclParser
  {
  public:
#ifdef YYSTYPE
# ifdef __GNUC__
#  pragma GCC message "bison: do not #define YYSTYPE in C++, use %define api.value.type"
# endif
    typedef YYSTYPE value_type;
#else
  /// A buffer to store and retrieve objects.
  ///
  /// Sort of a variant, but does not keep track of the nature
  /// of the stored data, since that knowledge is available
  /// via the current parser state.
  class value_type
  {
  public:
    /// Type of *this.
    typedef value_type self_type;

    /// Empty construction.
    value_type () YY_NOEXCEPT
      : yyraw_ ()
      , yytypeid_ (YY_NULLPTR)
    {}

    /// Construct and fill.
    template <typename T>
    value_type (YY_RVREF (T) t)
      : yytypeid_ (&typeid (T))
    {
      YY_ASSERT (sizeof (T) <= size);
      new (yyas_<T> ()) T (YY_MOVE (t));
    }

#if 201103L <= YY_CPLUSPLUS
    /// Non copyable.
    value_type (const self_type&) = delete;
    /// Non copyable.
    self_type& operator= (const self_type&) = delete;
#endif

    /// Destruction, allowed only if empty.
    ~value_type () YY_NOEXCEPT
    {
      YY_ASSERT (!yytypeid_);
    }

# if 201103L <= YY_CPLUSPLUS
    /// Instantiate a \a T in here from \a t.
    template <typename T, typename... U>
    T&
    emplace (U&&... u)
    {
      YY_ASSERT (!yytypeid_);
      YY_ASSERT (sizeof (T) <= size);
      yytypeid_ = & typeid (T);
      return *new (yyas_<T> ()) T (std::forward <U>(u)...);
    }
# else
    /// Instantiate an empty \a T in here.
    template <typename T>
    T&
    emplace ()
    {
      YY_ASSERT (!yytypeid_);
      YY_ASSERT (sizeof (T) <= size);
      yytypeid_ = & typeid (T);
      return *new (yyas_<T> ()) T ();
    }

    /// Instantiate a \a T in here from \a t.
    template <typename T>
    T&
    emplace (const T& t)
    {
      YY_ASSERT (!yytypeid_);
      YY_ASSERT (sizeof (T) <= size);
      yytypeid_ = & typeid (T);
      return *new (yyas_<T> ()) T (t);
    }
# endif

    /// Instantiate an empty \a T in here.
    /// Obsolete, use emplace.
    template <typename T>
    T&
    build ()
    {
      return emplace<T> ();
    }

    /// Instantiate a \a T in here from \a t.
    /// Obsolete, use emplace.
    template <typename T>
    T&
    build (const T& t)
    {
      return emplace<T> (t);
    }

    /// Accessor to a built \a T.
    template <typename T>
    T&
    as () YY_NOEXCEPT
    {
      YY_ASSERT (yytypeid_);
      YY_ASSERT (*yytypeid_ == typeid (T));
      YY_ASSERT (sizeof (T) <= size);
      return *yyas_<T> ();
    }

    /// Const accessor to a built \a T (for %printer).
    template <typename T>
    const T&
    as () const YY_NOEXCEPT
    {
      YY_ASSERT (yytypeid_);
      YY_ASSERT (*yytypeid_ == typeid (T));
      YY_ASSERT (sizeof (T) <= size);
      return *yyas_<T> ();
    }

    /// Swap the content with \a that, of same type.
    ///
    /// Both variants must be built beforehand, because swapping the actual
    /// data requires reading it (with as()), and this is not possible on
    /// unconstructed variants: it would require some dynamic testing, which
    /// should not be the variant's responsibility.
    /// Swapping between built and (possibly) non-built is done with
    /// self_type::move ().
    template <typename T>
    void
    swap (self_type& that) YY_NOEXCEPT
    {
      YY_ASSERT (yytypeid_);
      YY_ASSERT (*yytypeid_ == *that.yytypeid_);
      std::swap (as<T> (), that.as<T> ());
    }

    /// Move the content of \a that to this.
    ///
    /// Destroys \a that.
    template <typename T>
    void
    move (self_type& that)
    {
# if 201103L <= YY_CPLUSPLUS
      emplace<T> (std::move (that.as<T> ()));
# else
      emplace<T> ();
      swap<T> (that);
# endif
      that.destroy<T> ();
    }

# if 201103L <= YY_CPLUSPLUS
    /// Move the content of \a that to this.
    template <typename T>
    void
    move (self_type&& that)
    {
      emplace<T> (std::move (that.as<T> ()));
      that.destroy<T> ();
    }
#endif

    /// Copy the content of \a that to this.
    template <typename T>
    void
    copy (const self_type& that)
    {
      emplace<T> (that.as<T> ());
    }

    /// Destroy the stored \a T.
    template <typename T>
    void
    destroy ()
    {
      as<T> ().~T ();
      yytypeid_ = YY_NULLPTR;
    }

  private:
#if YY_CPLUSPLUS < 201103L
    /// Non copyable.
    value_type (const self_type&);
    /// Non copyable.
    self_type& operator= (const self_type&);
#endif

    /// Accessor to raw memory as \a T.
    template <typename T>
    T*
    yyas_ () YY_NOEXCEPT
    {
      void *yyp = yyraw_;
      return static_cast<T*> (yyp);
     }

    /// Const accessor to raw memory as \a T.
    template <typename T>
    const T*
    yyas_ () const YY_NOEXCEPT
    {
      const void *yyp = yyraw_;
      return static_cast<const T*> (yyp);
     }

    /// An auxiliary type to compute the largest semantic type.
    union union_type
    {
      // module_def
      char dummy1[sizeof (AstBlock*)];

      // module_item
      // port_decl
      // attr_item
      char dummy2[sizeof (AstNode*)];

      // "identifier"
      // "number"
      // "string"
      // "comment"
      // "parameter reference"
      // "operator"
      // port_keyword
      // range_bound
      // opt_range
      // ident_list
      // attr_name
      // name_block_kw
      // range_block_kw
      // sel_block_kw
      // of_block_kw
      // any_keyword
      // conn_expr
      // value
      // postfix
      // primary
      char dummy3[sizeof (std::string)];

      // module_item_list
      // mux_body
      // conn_body
      // attr_body
      char dummy4[sizeof (std::vector<AstNode*>)];
    };

    /// The size of the largest semantic type.
    enum { size = sizeof (union_type) };

    /// A buffer to store semantic values.
    union
    {
      /// Strongest alignment constraints.
      long double yyalign_me_;
      /// A buffer large enough to store any of the semantic values.
      char yyraw_[size];
    };

    /// Whether the content is built: if defined, the name of the stored type.
    const std::type_info *yytypeid_;
  };

#endif
    /// Backward compatibility (Bison 3.8).
    typedef value_type semantic_type;

    /// Symbol locations.
    typedef location location_type;

    /// Syntax errors thrown from user actions.
    struct syntax_error : std::runtime_error
    {
      syntax_error (const location_type& l, const std::string& m)
        : std::runtime_error (m)
        , location (l)
      {}

      syntax_error (const syntax_error& s)
        : std::runtime_error (s.what ())
        , location (s.location)
      {}

      ~syntax_error () YY_NOEXCEPT YY_NOTHROW;

      location_type location;
    };

    /// Token kinds.
    struct token
    {
      enum token_kind_type
      {
        YYEMPTY = -2,
    END = 0,                       // "end of file"
    YYerror = 256,                 // error
    YYUNDEF = 257,                 // "invalid token"
    IDENT = 258,                   // "identifier"
    NUMBER = 259,                  // "number"
    STRING = 260,                  // "string"
    COMMENT = 261,                 // "comment"
    PARAMREF = 262,                // "parameter reference"
    ARROW = 263,                   // "->"
    OPERATOR = 264,                // "operator"
    LPAREN = 265,                  // "("
    RPAREN = 266,                  // ")"
    MODULE = 267,                  // "Module"
    PARAMETER = 268,               // "Parameter"
    ATTRIBUTE = 269,               // "Attribute"
    ALIAS = 270,                   // "Alias"
    ENUM = 271,                    // "Enum"
    SCANINPORT = 272,              // "ScanInPort"
    SCANOUTPORT = 273,             // "ScanOutPort"
    SHIFTENPORT = 274,             // "ShiftEnPort"
    CAPTUREENPORT = 275,           // "CaptureEnPort"
    UPDATEENPORT = 276,            // "UpdateEnPort"
    SELECTPORT = 277,              // "SelectPort"
    RESETPORT = 278,               // "ResetPort"
    CLOCKPORT = 279,               // "ClockPort"
    TOCLOCKPORT = 280,             // "ToClockPort"
    TCKPORT = 281,                 // "TCKPort"
    TMSPORT = 282,                 // "TMSPort"
    TRSTPORT = 283,                // "TRSTPort"
    TOTCKPORT = 284,               // "ToTCKPort"
    TOTMSPORT = 285,               // "ToTMSPort"
    TOTRSTPORT = 286,              // "ToTRSTPort"
    TOSHIFTENPORT = 287,           // "ToShiftEnPort"
    TOCAPTUREENPORT = 288,         // "ToCaptureEnPort"
    TOUPDATEENPORT = 289,          // "ToUpdateEnPort"
    TORESETPORT = 290,             // "ToResetPort"
    TODOPORT = 291,                // "ToDoPort"
    TOSELECTPORT = 292,            // "ToSelectPort"
    DATAINPORT = 293,              // "DataInPort"
    DATAOUTPORT = 294,             // "DataOutPort"
    SCANINTERFACE = 295,           // "ScanInterface"
    ONEHOTSCANINTERFACE = 296,     // "OneHotScanInterface"
    SCANREGISTER = 297,            // "ScanRegister"
    DATAREGISTER = 298,            // "DataRegister"
    REG = 299,                     // "Reg"
    FIELD = 300,                   // "Field"
    INSTANCE = 301,                // "Instance"
    SCANMUX = 302,                 // "ScanMux"
    DATAMUX = 303,                 // "DataMux"
    CLOCKMUX = 304,                // "ClockMux"
    ONEHOTSCANGROUP = 305,         // "OneHotScanGroup"
    ONEHOTDATAGROUP = 306,         // "OneHotDataGroup"
    SELECTEDBY = 307,              // "SelectedBy"
    LOGICSIGNAL = 308,             // "LogicSignal"
    CONNECTION = 309,              // "Connection"
    PORTGROUP = 310,               // "PortGroup"
    ACCESSLINK = 311,              // "AccessLink"
    OF = 312,                      // "Of"
    LBRACE = 313,                  // "{"
    RBRACE = 314,                  // "}"
    LBRACKET = 315,                // "["
    RBRACKET = 316,                // "]"
    SEMICOLON = 317,               // ";"
    COLON = 318,                   // ":"
    COMMA = 319,                   // ","
    DOT = 320,                     // "."
    EQUALS = 321                   // "="
      };
      /// Backward compatibility alias (Bison 3.6).
      typedef token_kind_type yytokentype;
    };

    /// Token kind, as returned by yylex.
    typedef token::token_kind_type token_kind_type;

    /// Backward compatibility alias (Bison 3.6).
    typedef token_kind_type token_type;

    /// Symbol kinds.
    struct symbol_kind
    {
      enum symbol_kind_type
      {
        YYNTOKENS = 67, ///< Number of tokens.
        S_YYEMPTY = -2,
        S_YYEOF = 0,                             // "end of file"
        S_YYerror = 1,                           // error
        S_YYUNDEF = 2,                           // "invalid token"
        S_IDENT = 3,                             // "identifier"
        S_NUMBER = 4,                            // "number"
        S_STRING = 5,                            // "string"
        S_COMMENT = 6,                           // "comment"
        S_PARAMREF = 7,                          // "parameter reference"
        S_ARROW = 8,                             // "->"
        S_OPERATOR = 9,                          // "operator"
        S_LPAREN = 10,                           // "("
        S_RPAREN = 11,                           // ")"
        S_MODULE = 12,                           // "Module"
        S_PARAMETER = 13,                        // "Parameter"
        S_ATTRIBUTE = 14,                        // "Attribute"
        S_ALIAS = 15,                            // "Alias"
        S_ENUM = 16,                             // "Enum"
        S_SCANINPORT = 17,                       // "ScanInPort"
        S_SCANOUTPORT = 18,                      // "ScanOutPort"
        S_SHIFTENPORT = 19,                      // "ShiftEnPort"
        S_CAPTUREENPORT = 20,                    // "CaptureEnPort"
        S_UPDATEENPORT = 21,                     // "UpdateEnPort"
        S_SELECTPORT = 22,                       // "SelectPort"
        S_RESETPORT = 23,                        // "ResetPort"
        S_CLOCKPORT = 24,                        // "ClockPort"
        S_TOCLOCKPORT = 25,                      // "ToClockPort"
        S_TCKPORT = 26,                          // "TCKPort"
        S_TMSPORT = 27,                          // "TMSPort"
        S_TRSTPORT = 28,                         // "TRSTPort"
        S_TOTCKPORT = 29,                        // "ToTCKPort"
        S_TOTMSPORT = 30,                        // "ToTMSPort"
        S_TOTRSTPORT = 31,                       // "ToTRSTPort"
        S_TOSHIFTENPORT = 32,                    // "ToShiftEnPort"
        S_TOCAPTUREENPORT = 33,                  // "ToCaptureEnPort"
        S_TOUPDATEENPORT = 34,                   // "ToUpdateEnPort"
        S_TORESETPORT = 35,                      // "ToResetPort"
        S_TODOPORT = 36,                         // "ToDoPort"
        S_TOSELECTPORT = 37,                     // "ToSelectPort"
        S_DATAINPORT = 38,                       // "DataInPort"
        S_DATAOUTPORT = 39,                      // "DataOutPort"
        S_SCANINTERFACE = 40,                    // "ScanInterface"
        S_ONEHOTSCANINTERFACE = 41,              // "OneHotScanInterface"
        S_SCANREGISTER = 42,                     // "ScanRegister"
        S_DATAREGISTER = 43,                     // "DataRegister"
        S_REG = 44,                              // "Reg"
        S_FIELD = 45,                            // "Field"
        S_INSTANCE = 46,                         // "Instance"
        S_SCANMUX = 47,                          // "ScanMux"
        S_DATAMUX = 48,                          // "DataMux"
        S_CLOCKMUX = 49,                         // "ClockMux"
        S_ONEHOTSCANGROUP = 50,                  // "OneHotScanGroup"
        S_ONEHOTDATAGROUP = 51,                  // "OneHotDataGroup"
        S_SELECTEDBY = 52,                       // "SelectedBy"
        S_LOGICSIGNAL = 53,                      // "LogicSignal"
        S_CONNECTION = 54,                       // "Connection"
        S_PORTGROUP = 55,                        // "PortGroup"
        S_ACCESSLINK = 56,                       // "AccessLink"
        S_OF = 57,                               // "Of"
        S_LBRACE = 58,                           // "{"
        S_RBRACE = 59,                           // "}"
        S_LBRACKET = 60,                         // "["
        S_RBRACKET = 61,                         // "]"
        S_SEMICOLON = 62,                        // ";"
        S_COLON = 63,                            // ":"
        S_COMMA = 64,                            // ","
        S_DOT = 65,                              // "."
        S_EQUALS = 66,                           // "="
        S_YYACCEPT = 67,                         // $accept
        S_file = 68,                             // file
        S_module_def = 69,                       // module_def
        S_module_item_list = 70,                 // module_item_list
        S_module_item = 71,                      // module_item
        S_port_keyword = 72,                     // port_keyword
        S_range_bound = 73,                      // range_bound
        S_opt_range = 74,                        // opt_range
        S_port_decl = 75,                        // port_decl
        S_attr_item = 76,                        // attr_item
        S_mux_body = 77,                         // mux_body
        S_conn_body = 78,                        // conn_body
        S_attr_body = 79,                        // attr_body
        S_ident_list = 80,                       // ident_list
        S_attr_name = 81,                        // attr_name
        S_name_block_kw = 82,                    // name_block_kw
        S_range_block_kw = 83,                   // range_block_kw
        S_sel_block_kw = 84,                     // sel_block_kw
        S_of_block_kw = 85,                      // of_block_kw
        S_any_keyword = 86,                      // any_keyword
        S_conn_expr = 87,                        // conn_expr
        S_value = 88,                            // value
        S_postfix = 89,                          // postfix
        S_primary = 90                           // primary
      };
    };

    /// (Internal) symbol kind.
    typedef symbol_kind::symbol_kind_type symbol_kind_type;

    /// The number of tokens.
    static const symbol_kind_type YYNTOKENS = symbol_kind::YYNTOKENS;

    /// A complete symbol.
    ///
    /// Expects its Base type to provide access to the symbol kind
    /// via kind ().
    ///
    /// Provide access to semantic value and location.
    template <typename Base>
    struct basic_symbol : Base
    {
      /// Alias to Base.
      typedef Base super_type;

      /// Default constructor.
      basic_symbol () YY_NOEXCEPT
        : value ()
        , location ()
      {}

#if 201103L <= YY_CPLUSPLUS
      /// Move constructor.
      basic_symbol (basic_symbol&& that)
        : Base (std::move (that))
        , value ()
        , location (std::move (that.location))
      {
        switch (this->kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (std::move (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.move< AstNode* > (std::move (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_range_bound: // range_bound
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (std::move (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (std::move (that.value));
        break;

      default:
        break;
    }

      }
#endif

      /// Copy constructor.
      basic_symbol (const basic_symbol& that);

      /// Constructors for typed symbols.
#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, location_type&& l)
        : Base (t)
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const location_type& l)
        : Base (t)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, AstBlock*&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const AstBlock*& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, AstNode*&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const AstNode*& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, std::string&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const std::string& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

#if 201103L <= YY_CPLUSPLUS
      basic_symbol (typename Base::kind_type t, std::vector<AstNode*>&& v, location_type&& l)
        : Base (t)
        , value (std::move (v))
        , location (std::move (l))
      {}
#else
      basic_symbol (typename Base::kind_type t, const std::vector<AstNode*>& v, const location_type& l)
        : Base (t)
        , value (v)
        , location (l)
      {}
#endif

      /// Destroy the symbol.
      ~basic_symbol ()
      {
        clear ();
      }



      /// Destroy contents, and record that is empty.
      void clear () YY_NOEXCEPT
      {
        // User destructor.
        symbol_kind_type yykind = this->kind ();
        basic_symbol<Base>& yysym = *this;
        (void) yysym;
        switch (yykind)
        {
       default:
          break;
        }

        // Value type destructor.
switch (yykind)
    {
      case symbol_kind::S_module_def: // module_def
        value.template destroy< AstBlock* > ();
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.template destroy< AstNode* > ();
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_range_bound: // range_bound
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.template destroy< std::string > ();
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.template destroy< std::vector<AstNode*> > ();
        break;

      default:
        break;
    }

        Base::clear ();
      }

      /// The user-facing name of this symbol.
      const char *name () const YY_NOEXCEPT
      {
        return IclParser::symbol_name (this->kind ());
      }

      /// Backward compatibility (Bison 3.6).
      symbol_kind_type type_get () const YY_NOEXCEPT;

      /// Whether empty.
      bool empty () const YY_NOEXCEPT;

      /// Destructive move, \a s is emptied into this.
      void move (basic_symbol& s);

      /// The semantic value.
      value_type value;

      /// The location.
      location_type location;

    private:
#if YY_CPLUSPLUS < 201103L
      /// Assignment operator.
      basic_symbol& operator= (const basic_symbol& that);
#endif
    };

    /// Type access provider for token (enum) based symbols.
    struct by_kind
    {
      /// The symbol kind as needed by the constructor.
      typedef token_kind_type kind_type;

      /// Default constructor.
      by_kind () YY_NOEXCEPT;

#if 201103L <= YY_CPLUSPLUS
      /// Move constructor.
      by_kind (by_kind&& that) YY_NOEXCEPT;
#endif

      /// Copy constructor.
      by_kind (const by_kind& that) YY_NOEXCEPT;

      /// Constructor from (external) token numbers.
      by_kind (kind_type t) YY_NOEXCEPT;



      /// Record that this symbol is empty.
      void clear () YY_NOEXCEPT;

      /// Steal the symbol kind from \a that.
      void move (by_kind& that);

      /// The (internal) type number (corresponding to \a type).
      /// \a empty when empty.
      symbol_kind_type kind () const YY_NOEXCEPT;

      /// Backward compatibility (Bison 3.6).
      symbol_kind_type type_get () const YY_NOEXCEPT;

      /// The symbol kind.
      /// \a S_YYEMPTY when empty.
      symbol_kind_type kind_;
    };

    /// Backward compatibility for a private implementation detail (Bison 3.6).
    typedef by_kind by_type;

    /// "External" symbols: returned by the scanner.
    struct symbol_type : basic_symbol<by_kind>
    {
      /// Superclass.
      typedef basic_symbol<by_kind> super_type;

      /// Empty symbol.
      symbol_type () YY_NOEXCEPT {}

      /// Constructor for valueless symbols, and symbols from each type.
#if 201103L <= YY_CPLUSPLUS
      symbol_type (int tok, location_type l)
        : super_type (token_kind_type (tok), std::move (l))
#else
      symbol_type (int tok, const location_type& l)
        : super_type (token_kind_type (tok), l)
#endif
      {
#if !defined _MSC_VER || defined __clang__
        YY_ASSERT (tok == token::END
                   || (token::YYerror <= tok && tok <= token::YYUNDEF)
                   || tok == token::ARROW
                   || (token::LPAREN <= tok && tok <= token::EQUALS));
#endif
      }
#if 201103L <= YY_CPLUSPLUS
      symbol_type (int tok, std::string v, location_type l)
        : super_type (token_kind_type (tok), std::move (v), std::move (l))
#else
      symbol_type (int tok, const std::string& v, const location_type& l)
        : super_type (token_kind_type (tok), v, l)
#endif
      {
#if !defined _MSC_VER || defined __clang__
        YY_ASSERT ((token::IDENT <= tok && tok <= token::PARAMREF)
                   || tok == token::OPERATOR);
#endif
      }
    };

    /// Build a parser object.
    IclParser (icl::IclDriver& driver_yyarg);
    virtual ~IclParser ();

#if 201103L <= YY_CPLUSPLUS
    /// Non copyable.
    IclParser (const IclParser&) = delete;
    /// Non copyable.
    IclParser& operator= (const IclParser&) = delete;
#endif

    /// Parse.  An alias for parse ().
    /// \returns  0 iff parsing succeeded.
    int operator() ();

    /// Parse.
    /// \returns  0 iff parsing succeeded.
    virtual int parse ();

#if YYDEBUG
    /// The current debugging stream.
    std::ostream& debug_stream () const YY_ATTRIBUTE_PURE;
    /// Set the current debugging stream.
    void set_debug_stream (std::ostream &);

    /// Type for debugging levels.
    typedef int debug_level_type;
    /// The current debugging level.
    debug_level_type debug_level () const YY_ATTRIBUTE_PURE;
    /// Set the current debugging level.
    void set_debug_level (debug_level_type l);
#endif

    /// Report a syntax error.
    /// \param loc    where the syntax error is found.
    /// \param msg    a description of the syntax error.
    virtual void error (const location_type& loc, const std::string& msg);

    /// Report a syntax error.
    void error (const syntax_error& err);

    /// The user-facing name of the symbol whose (internal) number is
    /// YYSYMBOL.  No bounds checking.
    static const char *symbol_name (symbol_kind_type yysymbol);

    // Implementation of make_symbol for each token kind.
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_END (location_type l)
      {
        return symbol_type (token::END, std::move (l));
      }
#else
      static
      symbol_type
      make_END (const location_type& l)
      {
        return symbol_type (token::END, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_YYerror (location_type l)
      {
        return symbol_type (token::YYerror, std::move (l));
      }
#else
      static
      symbol_type
      make_YYerror (const location_type& l)
      {
        return symbol_type (token::YYerror, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_YYUNDEF (location_type l)
      {
        return symbol_type (token::YYUNDEF, std::move (l));
      }
#else
      static
      symbol_type
      make_YYUNDEF (const location_type& l)
      {
        return symbol_type (token::YYUNDEF, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_IDENT (std::string v, location_type l)
      {
        return symbol_type (token::IDENT, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_IDENT (const std::string& v, const location_type& l)
      {
        return symbol_type (token::IDENT, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_NUMBER (std::string v, location_type l)
      {
        return symbol_type (token::NUMBER, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_NUMBER (const std::string& v, const location_type& l)
      {
        return symbol_type (token::NUMBER, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_STRING (std::string v, location_type l)
      {
        return symbol_type (token::STRING, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_STRING (const std::string& v, const location_type& l)
      {
        return symbol_type (token::STRING, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_COMMENT (std::string v, location_type l)
      {
        return symbol_type (token::COMMENT, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_COMMENT (const std::string& v, const location_type& l)
      {
        return symbol_type (token::COMMENT, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PARAMREF (std::string v, location_type l)
      {
        return symbol_type (token::PARAMREF, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_PARAMREF (const std::string& v, const location_type& l)
      {
        return symbol_type (token::PARAMREF, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ARROW (location_type l)
      {
        return symbol_type (token::ARROW, std::move (l));
      }
#else
      static
      symbol_type
      make_ARROW (const location_type& l)
      {
        return symbol_type (token::ARROW, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_OPERATOR (std::string v, location_type l)
      {
        return symbol_type (token::OPERATOR, std::move (v), std::move (l));
      }
#else
      static
      symbol_type
      make_OPERATOR (const std::string& v, const location_type& l)
      {
        return symbol_type (token::OPERATOR, v, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LPAREN (location_type l)
      {
        return symbol_type (token::LPAREN, std::move (l));
      }
#else
      static
      symbol_type
      make_LPAREN (const location_type& l)
      {
        return symbol_type (token::LPAREN, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_RPAREN (location_type l)
      {
        return symbol_type (token::RPAREN, std::move (l));
      }
#else
      static
      symbol_type
      make_RPAREN (const location_type& l)
      {
        return symbol_type (token::RPAREN, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_MODULE (location_type l)
      {
        return symbol_type (token::MODULE, std::move (l));
      }
#else
      static
      symbol_type
      make_MODULE (const location_type& l)
      {
        return symbol_type (token::MODULE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PARAMETER (location_type l)
      {
        return symbol_type (token::PARAMETER, std::move (l));
      }
#else
      static
      symbol_type
      make_PARAMETER (const location_type& l)
      {
        return symbol_type (token::PARAMETER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ATTRIBUTE (location_type l)
      {
        return symbol_type (token::ATTRIBUTE, std::move (l));
      }
#else
      static
      symbol_type
      make_ATTRIBUTE (const location_type& l)
      {
        return symbol_type (token::ATTRIBUTE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ALIAS (location_type l)
      {
        return symbol_type (token::ALIAS, std::move (l));
      }
#else
      static
      symbol_type
      make_ALIAS (const location_type& l)
      {
        return symbol_type (token::ALIAS, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ENUM (location_type l)
      {
        return symbol_type (token::ENUM, std::move (l));
      }
#else
      static
      symbol_type
      make_ENUM (const location_type& l)
      {
        return symbol_type (token::ENUM, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SCANINPORT (location_type l)
      {
        return symbol_type (token::SCANINPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_SCANINPORT (const location_type& l)
      {
        return symbol_type (token::SCANINPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SCANOUTPORT (location_type l)
      {
        return symbol_type (token::SCANOUTPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_SCANOUTPORT (const location_type& l)
      {
        return symbol_type (token::SCANOUTPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SHIFTENPORT (location_type l)
      {
        return symbol_type (token::SHIFTENPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_SHIFTENPORT (const location_type& l)
      {
        return symbol_type (token::SHIFTENPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_CAPTUREENPORT (location_type l)
      {
        return symbol_type (token::CAPTUREENPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_CAPTUREENPORT (const location_type& l)
      {
        return symbol_type (token::CAPTUREENPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_UPDATEENPORT (location_type l)
      {
        return symbol_type (token::UPDATEENPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_UPDATEENPORT (const location_type& l)
      {
        return symbol_type (token::UPDATEENPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SELECTPORT (location_type l)
      {
        return symbol_type (token::SELECTPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_SELECTPORT (const location_type& l)
      {
        return symbol_type (token::SELECTPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_RESETPORT (location_type l)
      {
        return symbol_type (token::RESETPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_RESETPORT (const location_type& l)
      {
        return symbol_type (token::RESETPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_CLOCKPORT (location_type l)
      {
        return symbol_type (token::CLOCKPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_CLOCKPORT (const location_type& l)
      {
        return symbol_type (token::CLOCKPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOCLOCKPORT (location_type l)
      {
        return symbol_type (token::TOCLOCKPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TOCLOCKPORT (const location_type& l)
      {
        return symbol_type (token::TOCLOCKPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TCKPORT (location_type l)
      {
        return symbol_type (token::TCKPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TCKPORT (const location_type& l)
      {
        return symbol_type (token::TCKPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TMSPORT (location_type l)
      {
        return symbol_type (token::TMSPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TMSPORT (const location_type& l)
      {
        return symbol_type (token::TMSPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TRSTPORT (location_type l)
      {
        return symbol_type (token::TRSTPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TRSTPORT (const location_type& l)
      {
        return symbol_type (token::TRSTPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOTCKPORT (location_type l)
      {
        return symbol_type (token::TOTCKPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TOTCKPORT (const location_type& l)
      {
        return symbol_type (token::TOTCKPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOTMSPORT (location_type l)
      {
        return symbol_type (token::TOTMSPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TOTMSPORT (const location_type& l)
      {
        return symbol_type (token::TOTMSPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOTRSTPORT (location_type l)
      {
        return symbol_type (token::TOTRSTPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TOTRSTPORT (const location_type& l)
      {
        return symbol_type (token::TOTRSTPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOSHIFTENPORT (location_type l)
      {
        return symbol_type (token::TOSHIFTENPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TOSHIFTENPORT (const location_type& l)
      {
        return symbol_type (token::TOSHIFTENPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOCAPTUREENPORT (location_type l)
      {
        return symbol_type (token::TOCAPTUREENPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TOCAPTUREENPORT (const location_type& l)
      {
        return symbol_type (token::TOCAPTUREENPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOUPDATEENPORT (location_type l)
      {
        return symbol_type (token::TOUPDATEENPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TOUPDATEENPORT (const location_type& l)
      {
        return symbol_type (token::TOUPDATEENPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TORESETPORT (location_type l)
      {
        return symbol_type (token::TORESETPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TORESETPORT (const location_type& l)
      {
        return symbol_type (token::TORESETPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TODOPORT (location_type l)
      {
        return symbol_type (token::TODOPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TODOPORT (const location_type& l)
      {
        return symbol_type (token::TODOPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_TOSELECTPORT (location_type l)
      {
        return symbol_type (token::TOSELECTPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_TOSELECTPORT (const location_type& l)
      {
        return symbol_type (token::TOSELECTPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DATAINPORT (location_type l)
      {
        return symbol_type (token::DATAINPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_DATAINPORT (const location_type& l)
      {
        return symbol_type (token::DATAINPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DATAOUTPORT (location_type l)
      {
        return symbol_type (token::DATAOUTPORT, std::move (l));
      }
#else
      static
      symbol_type
      make_DATAOUTPORT (const location_type& l)
      {
        return symbol_type (token::DATAOUTPORT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SCANINTERFACE (location_type l)
      {
        return symbol_type (token::SCANINTERFACE, std::move (l));
      }
#else
      static
      symbol_type
      make_SCANINTERFACE (const location_type& l)
      {
        return symbol_type (token::SCANINTERFACE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ONEHOTSCANINTERFACE (location_type l)
      {
        return symbol_type (token::ONEHOTSCANINTERFACE, std::move (l));
      }
#else
      static
      symbol_type
      make_ONEHOTSCANINTERFACE (const location_type& l)
      {
        return symbol_type (token::ONEHOTSCANINTERFACE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SCANREGISTER (location_type l)
      {
        return symbol_type (token::SCANREGISTER, std::move (l));
      }
#else
      static
      symbol_type
      make_SCANREGISTER (const location_type& l)
      {
        return symbol_type (token::SCANREGISTER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DATAREGISTER (location_type l)
      {
        return symbol_type (token::DATAREGISTER, std::move (l));
      }
#else
      static
      symbol_type
      make_DATAREGISTER (const location_type& l)
      {
        return symbol_type (token::DATAREGISTER, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_REG (location_type l)
      {
        return symbol_type (token::REG, std::move (l));
      }
#else
      static
      symbol_type
      make_REG (const location_type& l)
      {
        return symbol_type (token::REG, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_FIELD (location_type l)
      {
        return symbol_type (token::FIELD, std::move (l));
      }
#else
      static
      symbol_type
      make_FIELD (const location_type& l)
      {
        return symbol_type (token::FIELD, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_INSTANCE (location_type l)
      {
        return symbol_type (token::INSTANCE, std::move (l));
      }
#else
      static
      symbol_type
      make_INSTANCE (const location_type& l)
      {
        return symbol_type (token::INSTANCE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SCANMUX (location_type l)
      {
        return symbol_type (token::SCANMUX, std::move (l));
      }
#else
      static
      symbol_type
      make_SCANMUX (const location_type& l)
      {
        return symbol_type (token::SCANMUX, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DATAMUX (location_type l)
      {
        return symbol_type (token::DATAMUX, std::move (l));
      }
#else
      static
      symbol_type
      make_DATAMUX (const location_type& l)
      {
        return symbol_type (token::DATAMUX, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_CLOCKMUX (location_type l)
      {
        return symbol_type (token::CLOCKMUX, std::move (l));
      }
#else
      static
      symbol_type
      make_CLOCKMUX (const location_type& l)
      {
        return symbol_type (token::CLOCKMUX, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ONEHOTSCANGROUP (location_type l)
      {
        return symbol_type (token::ONEHOTSCANGROUP, std::move (l));
      }
#else
      static
      symbol_type
      make_ONEHOTSCANGROUP (const location_type& l)
      {
        return symbol_type (token::ONEHOTSCANGROUP, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ONEHOTDATAGROUP (location_type l)
      {
        return symbol_type (token::ONEHOTDATAGROUP, std::move (l));
      }
#else
      static
      symbol_type
      make_ONEHOTDATAGROUP (const location_type& l)
      {
        return symbol_type (token::ONEHOTDATAGROUP, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SELECTEDBY (location_type l)
      {
        return symbol_type (token::SELECTEDBY, std::move (l));
      }
#else
      static
      symbol_type
      make_SELECTEDBY (const location_type& l)
      {
        return symbol_type (token::SELECTEDBY, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LOGICSIGNAL (location_type l)
      {
        return symbol_type (token::LOGICSIGNAL, std::move (l));
      }
#else
      static
      symbol_type
      make_LOGICSIGNAL (const location_type& l)
      {
        return symbol_type (token::LOGICSIGNAL, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_CONNECTION (location_type l)
      {
        return symbol_type (token::CONNECTION, std::move (l));
      }
#else
      static
      symbol_type
      make_CONNECTION (const location_type& l)
      {
        return symbol_type (token::CONNECTION, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_PORTGROUP (location_type l)
      {
        return symbol_type (token::PORTGROUP, std::move (l));
      }
#else
      static
      symbol_type
      make_PORTGROUP (const location_type& l)
      {
        return symbol_type (token::PORTGROUP, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_ACCESSLINK (location_type l)
      {
        return symbol_type (token::ACCESSLINK, std::move (l));
      }
#else
      static
      symbol_type
      make_ACCESSLINK (const location_type& l)
      {
        return symbol_type (token::ACCESSLINK, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_OF (location_type l)
      {
        return symbol_type (token::OF, std::move (l));
      }
#else
      static
      symbol_type
      make_OF (const location_type& l)
      {
        return symbol_type (token::OF, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LBRACE (location_type l)
      {
        return symbol_type (token::LBRACE, std::move (l));
      }
#else
      static
      symbol_type
      make_LBRACE (const location_type& l)
      {
        return symbol_type (token::LBRACE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_RBRACE (location_type l)
      {
        return symbol_type (token::RBRACE, std::move (l));
      }
#else
      static
      symbol_type
      make_RBRACE (const location_type& l)
      {
        return symbol_type (token::RBRACE, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_LBRACKET (location_type l)
      {
        return symbol_type (token::LBRACKET, std::move (l));
      }
#else
      static
      symbol_type
      make_LBRACKET (const location_type& l)
      {
        return symbol_type (token::LBRACKET, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_RBRACKET (location_type l)
      {
        return symbol_type (token::RBRACKET, std::move (l));
      }
#else
      static
      symbol_type
      make_RBRACKET (const location_type& l)
      {
        return symbol_type (token::RBRACKET, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_SEMICOLON (location_type l)
      {
        return symbol_type (token::SEMICOLON, std::move (l));
      }
#else
      static
      symbol_type
      make_SEMICOLON (const location_type& l)
      {
        return symbol_type (token::SEMICOLON, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_COLON (location_type l)
      {
        return symbol_type (token::COLON, std::move (l));
      }
#else
      static
      symbol_type
      make_COLON (const location_type& l)
      {
        return symbol_type (token::COLON, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_COMMA (location_type l)
      {
        return symbol_type (token::COMMA, std::move (l));
      }
#else
      static
      symbol_type
      make_COMMA (const location_type& l)
      {
        return symbol_type (token::COMMA, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_DOT (location_type l)
      {
        return symbol_type (token::DOT, std::move (l));
      }
#else
      static
      symbol_type
      make_DOT (const location_type& l)
      {
        return symbol_type (token::DOT, l);
      }
#endif
#if 201103L <= YY_CPLUSPLUS
      static
      symbol_type
      make_EQUALS (location_type l)
      {
        return symbol_type (token::EQUALS, std::move (l));
      }
#else
      static
      symbol_type
      make_EQUALS (const location_type& l)
      {
        return symbol_type (token::EQUALS, l);
      }
#endif


    class context
    {
    public:
      context (const IclParser& yyparser, const symbol_type& yyla);
      const symbol_type& lookahead () const YY_NOEXCEPT { return yyla_; }
      symbol_kind_type token () const YY_NOEXCEPT { return yyla_.kind (); }
      const location_type& location () const YY_NOEXCEPT { return yyla_.location; }

      /// Put in YYARG at most YYARGN of the expected tokens, and return the
      /// number of tokens stored in YYARG.  If YYARG is null, return the
      /// number of expected tokens (guaranteed to be less than YYNTOKENS).
      int expected_tokens (symbol_kind_type yyarg[], int yyargn) const;

    private:
      const IclParser& yyparser_;
      const symbol_type& yyla_;
    };

  private:
#if YY_CPLUSPLUS < 201103L
    /// Non copyable.
    IclParser (const IclParser&);
    /// Non copyable.
    IclParser& operator= (const IclParser&);
#endif

    /// Check the lookahead yytoken.
    /// \returns  true iff the token will be eventually shifted.
    bool yy_lac_check_ (symbol_kind_type yytoken) const;
    /// Establish the initial context if no initial context currently exists.
    /// \returns  true iff the token will be eventually shifted.
    bool yy_lac_establish_ (symbol_kind_type yytoken);
    /// Discard any previous initial lookahead context because of event.
    /// \param event  the event which caused the lookahead to be discarded.
    ///               Only used for debbuging output.
    void yy_lac_discard_ (const char* event);

    /// Stored state numbers (used for stacks).
    typedef unsigned char state_type;

    /// The arguments of the error message.
    int yy_syntax_error_arguments_ (const context& yyctx,
                                    symbol_kind_type yyarg[], int yyargn) const;

    /// Generate an error message.
    /// \param yyctx     the context in which the error occurred.
    virtual std::string yysyntax_error_ (const context& yyctx) const;
    /// Compute post-reduction state.
    /// \param yystate   the current state
    /// \param yysym     the nonterminal to push on the stack
    static state_type yy_lr_goto_state_ (state_type yystate, int yysym);

    /// Whether the given \c yypact_ value indicates a defaulted state.
    /// \param yyvalue   the value to check
    static bool yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT;

    /// Whether the given \c yytable_ value indicates a syntax error.
    /// \param yyvalue   the value to check
    static bool yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT;

    static const signed char yypact_ninf_;
    static const signed char yytable_ninf_;

    /// Convert a scanner token kind \a t to a symbol kind.
    /// In theory \a t should be a token_kind_type, but character literals
    /// are valid, yet not members of the token_kind_type enum.
    static symbol_kind_type yytranslate_ (int t) YY_NOEXCEPT;



    // Tables.
    // YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
    // STATE-NUM.
    static const short yypact_[];

    // YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
    // Performed when YYTABLE does not specify something else to do.  Zero
    // means the default is an error.
    static const signed char yydefact_[];

    // YYPGOTO[NTERM-NUM].
    static const short yypgoto_[];

    // YYDEFGOTO[NTERM-NUM].
    static const unsigned char yydefgoto_[];

    // YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
    // positive, shift that token.  If negative, reduce the rule whose
    // number is the opposite.  If YYTABLE_NINF, syntax error.
    static const unsigned char yytable_[];

    static const short yycheck_[];

    // YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
    // state STATE-NUM.
    static const signed char yystos_[];

    // YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.
    static const signed char yyr1_[];

    // YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.
    static const signed char yyr2_[];


#if YYDEBUG
    // YYRLINE[YYN] -- Source line where rule number YYN was defined.
    static const short yyrline_[];
    /// Report on the debug stream that the rule \a r is going to be reduced.
    virtual void yy_reduce_print_ (int r) const;
    /// Print the state stack on the debug stream.
    virtual void yy_stack_print_ () const;

    /// Debugging level.
    int yydebug_;
    /// Debug stream.
    std::ostream* yycdebug_;

    /// \brief Display a symbol kind, value and location.
    /// \param yyo    The output stream.
    /// \param yysym  The symbol.
    template <typename Base>
    void yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const;
#endif

    /// \brief Reclaim the memory associated to a symbol.
    /// \param yymsg     Why this token is reclaimed.
    ///                  If null, print nothing.
    /// \param yysym     The symbol.
    template <typename Base>
    void yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const;

  private:
    /// Type access provider for state based symbols.
    struct by_state
    {
      /// Default constructor.
      by_state () YY_NOEXCEPT;

      /// The symbol kind as needed by the constructor.
      typedef state_type kind_type;

      /// Constructor.
      by_state (kind_type s) YY_NOEXCEPT;

      /// Copy constructor.
      by_state (const by_state& that) YY_NOEXCEPT;

      /// Record that this symbol is empty.
      void clear () YY_NOEXCEPT;

      /// Steal the symbol kind from \a that.
      void move (by_state& that);

      /// The symbol kind (corresponding to \a state).
      /// \a symbol_kind::S_YYEMPTY when empty.
      symbol_kind_type kind () const YY_NOEXCEPT;

      /// The state number used to denote an empty symbol.
      /// We use the initial state, as it does not have a value.
      enum { empty_state = 0 };

      /// The state.
      /// \a empty when empty.
      state_type state;
    };

    /// "Internal" symbol: element of the stack.
    struct stack_symbol_type : basic_symbol<by_state>
    {
      /// Superclass.
      typedef basic_symbol<by_state> super_type;
      /// Construct an empty symbol.
      stack_symbol_type ();
      /// Move or copy construction.
      stack_symbol_type (YY_RVREF (stack_symbol_type) that);
      /// Steal the contents from \a sym to build this.
      stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) sym);
#if YY_CPLUSPLUS < 201103L
      /// Assignment, needed by push_back by some old implementations.
      /// Moves the contents of that.
      stack_symbol_type& operator= (stack_symbol_type& that);

      /// Assignment, needed by push_back by other implementations.
      /// Needed by some other old implementations.
      stack_symbol_type& operator= (const stack_symbol_type& that);
#endif
    };

    /// A stack with random access from its top.
    template <typename T, typename S = std::vector<T> >
    class stack
    {
    public:
      // Hide our reversed order.
      typedef typename S::iterator iterator;
      typedef typename S::const_iterator const_iterator;
      typedef typename S::size_type size_type;
      typedef typename std::ptrdiff_t index_type;

      stack (size_type n = 200) YY_NOEXCEPT
        : seq_ (n)
      {}

#if 201103L <= YY_CPLUSPLUS
      /// Non copyable.
      stack (const stack&) = delete;
      /// Non copyable.
      stack& operator= (const stack&) = delete;
#endif

      /// Random access.
      ///
      /// Index 0 returns the topmost element.
      const T&
      operator[] (index_type i) const
      {
        return seq_[size_type (size () - 1 - i)];
      }

      /// Random access.
      ///
      /// Index 0 returns the topmost element.
      T&
      operator[] (index_type i)
      {
        return seq_[size_type (size () - 1 - i)];
      }

      /// Steal the contents of \a t.
      ///
      /// Close to move-semantics.
      void
      push (YY_MOVE_REF (T) t)
      {
        seq_.push_back (T ());
        operator[] (0).move (t);
      }

      /// Pop elements from the stack.
      void
      pop (std::ptrdiff_t n = 1) YY_NOEXCEPT
      {
        for (; 0 < n; --n)
          seq_.pop_back ();
      }

      /// Pop all elements from the stack.
      void
      clear () YY_NOEXCEPT
      {
        seq_.clear ();
      }

      /// Number of elements on the stack.
      index_type
      size () const YY_NOEXCEPT
      {
        return index_type (seq_.size ());
      }

      /// Iterator on top of the stack (going downwards).
      const_iterator
      begin () const YY_NOEXCEPT
      {
        return seq_.begin ();
      }

      /// Bottom of the stack.
      const_iterator
      end () const YY_NOEXCEPT
      {
        return seq_.end ();
      }

      /// Present a slice of the top of a stack.
      class slice
      {
      public:
        slice (const stack& stack, index_type range) YY_NOEXCEPT
          : stack_ (stack)
          , range_ (range)
        {}

        const T&
        operator[] (index_type i) const
        {
          return stack_[range_ - i];
        }

      private:
        const stack& stack_;
        index_type range_;
      };

    private:
#if YY_CPLUSPLUS < 201103L
      /// Non copyable.
      stack (const stack&);
      /// Non copyable.
      stack& operator= (const stack&);
#endif
      /// The wrapped container.
      S seq_;
    };


    /// Stack type.
    typedef stack<stack_symbol_type> stack_type;

    /// The stack.
    stack_type yystack_;
    /// The stack for LAC.
    /// Logically, the yy_lac_stack's lifetime is confined to the function
    /// yy_lac_check_. We just store it as a member of this class to hold
    /// on to the memory and to avoid frequent reallocations.
    /// Since yy_lac_check_ is const, this member must be mutable.
    mutable std::vector<state_type> yylac_stack_;
    /// Whether an initial LAC context was established.
    bool yy_lac_established_;


    /// Push a new state on the stack.
    /// \param m    a debug message to display
    ///             if null, no trace is output.
    /// \param sym  the symbol
    /// \warning the contents of \a s.value is stolen.
    void yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym);

    /// Push a new look ahead token on the state on the stack.
    /// \param m    a debug message to display
    ///             if null, no trace is output.
    /// \param s    the state
    /// \param sym  the symbol (for its value and location).
    /// \warning the contents of \a sym.value is stolen.
    void yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym);

    /// Pop \a n symbols from the stack.
    void yypop_ (int n = 1) YY_NOEXCEPT;

    /// Constants.
    enum
    {
      yylast_ = 544,     ///< Last index in yytable_.
      yynnts_ = 24,  ///< Number of nonterminal symbols.
      yyfinal_ = 2 ///< Termination state number.
    };


    // User arguments.
    icl::IclDriver& driver;

  };

  inline
  IclParser::symbol_kind_type
  IclParser::yytranslate_ (int t) YY_NOEXCEPT
  {
    // YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to
    // TOKEN-NUM as returned by yylex.
    static
    const signed char
    translate_table[] =
    {
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66
    };
    // Last valid token kind.
    const int code_max = 321;

    if (t <= 0)
      return symbol_kind::S_YYEOF;
    else if (t <= code_max)
      return static_cast <symbol_kind_type> (translate_table[t]);
    else
      return symbol_kind::S_YYUNDEF;
  }

  // basic_symbol.
  template <typename Base>
  IclParser::basic_symbol<Base>::basic_symbol (const basic_symbol& that)
    : Base (that)
    , value ()
    , location (that.location)
  {
    switch (this->kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.copy< AstBlock* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.copy< AstNode* > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_range_bound: // range_bound
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.copy< std::string > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.copy< std::vector<AstNode*> > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

  }




  template <typename Base>
  IclParser::symbol_kind_type
  IclParser::basic_symbol<Base>::type_get () const YY_NOEXCEPT
  {
    return this->kind ();
  }


  template <typename Base>
  bool
  IclParser::basic_symbol<Base>::empty () const YY_NOEXCEPT
  {
    return this->kind () == symbol_kind::S_YYEMPTY;
  }

  template <typename Base>
  void
  IclParser::basic_symbol<Base>::move (basic_symbol& s)
  {
    super_type::move (s);
    switch (this->kind ())
    {
      case symbol_kind::S_module_def: // module_def
        value.move< AstBlock* > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_module_item: // module_item
      case symbol_kind::S_port_decl: // port_decl
      case symbol_kind::S_attr_item: // attr_item
        value.move< AstNode* > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_IDENT: // "identifier"
      case symbol_kind::S_NUMBER: // "number"
      case symbol_kind::S_STRING: // "string"
      case symbol_kind::S_COMMENT: // "comment"
      case symbol_kind::S_PARAMREF: // "parameter reference"
      case symbol_kind::S_OPERATOR: // "operator"
      case symbol_kind::S_port_keyword: // port_keyword
      case symbol_kind::S_range_bound: // range_bound
      case symbol_kind::S_opt_range: // opt_range
      case symbol_kind::S_ident_list: // ident_list
      case symbol_kind::S_attr_name: // attr_name
      case symbol_kind::S_name_block_kw: // name_block_kw
      case symbol_kind::S_range_block_kw: // range_block_kw
      case symbol_kind::S_sel_block_kw: // sel_block_kw
      case symbol_kind::S_of_block_kw: // of_block_kw
      case symbol_kind::S_any_keyword: // any_keyword
      case symbol_kind::S_conn_expr: // conn_expr
      case symbol_kind::S_value: // value
      case symbol_kind::S_postfix: // postfix
      case symbol_kind::S_primary: // primary
        value.move< std::string > (YY_MOVE (s.value));
        break;

      case symbol_kind::S_module_item_list: // module_item_list
      case symbol_kind::S_mux_body: // mux_body
      case symbol_kind::S_conn_body: // conn_body
      case symbol_kind::S_attr_body: // attr_body
        value.move< std::vector<AstNode*> > (YY_MOVE (s.value));
        break;

      default:
        break;
    }

    location = YY_MOVE (s.location);
  }

  // by_kind.
  inline
  IclParser::by_kind::by_kind () YY_NOEXCEPT
    : kind_ (symbol_kind::S_YYEMPTY)
  {}

#if 201103L <= YY_CPLUSPLUS
  inline
  IclParser::by_kind::by_kind (by_kind&& that) YY_NOEXCEPT
    : kind_ (that.kind_)
  {
    that.clear ();
  }
#endif

  inline
  IclParser::by_kind::by_kind (const by_kind& that) YY_NOEXCEPT
    : kind_ (that.kind_)
  {}

  inline
  IclParser::by_kind::by_kind (token_kind_type t) YY_NOEXCEPT
    : kind_ (yytranslate_ (t))
  {}



  inline
  void
  IclParser::by_kind::clear () YY_NOEXCEPT
  {
    kind_ = symbol_kind::S_YYEMPTY;
  }

  inline
  void
  IclParser::by_kind::move (by_kind& that)
  {
    kind_ = that.kind_;
    that.clear ();
  }

  inline
  IclParser::symbol_kind_type
  IclParser::by_kind::kind () const YY_NOEXCEPT
  {
    return kind_;
  }


  inline
  IclParser::symbol_kind_type
  IclParser::by_kind::type_get () const YY_NOEXCEPT
  {
    return this->kind ();
  }


#line 42 "src/icl_parser.yy"
} // icl
#line 2667 "build/gen/icl_parser.hh"




#endif // !YY_YY_BUILD_GEN_ICL_PARSER_HH_INCLUDED
