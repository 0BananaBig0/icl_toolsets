Module m { Foo x; }
