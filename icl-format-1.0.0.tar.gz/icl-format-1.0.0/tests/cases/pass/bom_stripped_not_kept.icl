﻿Module m {
  ScanInPort SI;
}
