// Copyright 2024 The ICL Format Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "icl_driver.h"

#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>

#include "format_tree.h"
#include "icl_parser.hh"

// Declared by the generated scanner.
extern icl::IclParser::symbol_type yylex(icl::IclDriver& driver);
void icl_reset_lexer(FILE* input);

namespace icl {
namespace {

// Reads a whole file. Returns false when the file cannot be opened or is not
// valid UTF-8-ish text (binary input must never be silently reformatted).
bool ReadFile(const std::string& path, std::string* text, std::string* error) {
  std::ifstream stream(path, std::ios::binary);
  if (!stream) {
    *error = "cannot open '" + path + "'";
    return false;
  }
  std::ostringstream buffer;
  buffer << stream.rdbuf();
  *text = buffer.str();
  // Reject files containing NUL bytes: they are not source text, and writing
  // them back would corrupt them.
  if (text->find('\0') != std::string::npos) {
    *error = "not a text file (contains NUL bytes): '" + path + "'";
    return false;
  }
  return true;
}

void DumpNode(const AstNode& node, int depth);

void DumpChildren(const std::vector<AstNode*>& body, int depth) {
  for (AstNode* child : body) {
    DumpNode(*child, depth + 1);
  }
}

void DumpNode(const AstNode& node, int depth) {
  const std::string pad(depth * 2, ' ');
  const std::string kind(AstKindName(node.kind()));
  switch (node.kind()) {
    case AstKind::kComment: {
      const auto& comment = static_cast<const AstComment&>(node);
      std::string text = comment.text();
      const size_t newline = text.find('\n');
      if (newline != std::string::npos) text = text.substr(0, newline) + "...";
      std::cout << pad << kind << " " << text << "\n";
      return;
    }
    case AstKind::kModule: {
      const auto& module = static_cast<const AstModule&>(node);
      std::cout << pad << kind << " " << module.name() << "\n";
      DumpChildren(module.body(), depth);
      return;
    }
    case AstKind::kPort: {
      const auto& port = static_cast<const AstPort&>(node);
      std::cout << pad << kind << " " << port.header() << "\n";
      DumpChildren(port.body(), depth);
      return;
    }
    case AstKind::kPortGroup: {
      const auto& group = static_cast<const AstPortGroup&>(node);
      std::cout << pad << kind << " " << group.name() << " [";
      for (size_t i = 0; i < group.idents().size(); ++i) {
        if (i != 0) std::cout << ", ";
        std::cout << group.idents()[i];
      }
      std::cout << "]\n";
      return;
    }
    default:
      if (const AstBlock* block = dynamic_cast<const AstBlock*>(&node)) {
        // The block header already contains the keyword ("Instance x Of Y"),
        // so printing the kind name too would read "Instance Instance ...".
        std::cout << pad << block->header() << "\n";
        DumpChildren(block->body(), depth);
        return;
      }
      std::cout << pad << kind << " "
                << static_cast<const AstStatement&>(node).text() << "\n";
      return;
  }
}

}  // namespace

bool IclDriver::Parse(const std::string& text, std::string* error) {
  ClearParseDiagnostic();

  // The scanner reads from a pipe; feed the text through a temp file so that
  // flex can use stdio (simplest portable option, and inputs are small).
  FILE* input = fmemopen(const_cast<char*>(text.data()), text.size(), "r");
  if (input == nullptr) {
    input = tmpfile();
    if (input == nullptr) {
      *error = "cannot open input buffer";
      return false;
    }
    fwrite(text.data(), 1, text.size(), input);
    rewind(input);
  }
  icl_reset_lexer(input);

  IclParser parser(*this);
  const int result = parser.parse();
  fclose(input);

  if (result != 0 || HasParseDiagnostic()) {
    *error = "line " + std::to_string(ParseDiagnosticLine()) + ": " +
             ParseDiagnosticMessage();
    return false;
  }
  return true;
}

bool IclDriver::FormatText(const std::string& text, std::string* output,
                           std::string* error) {
  if (!Parse(text, error)) return false;
  const FormatTree tree = BuildFormatTree(unit_, style_);
  *output = RenderFormatTree(tree, style_.indent_width);
  return true;
}

bool IclDriver::FormatFile(const std::string& path, std::string* output,
                           std::string* error) {
  std::string text;
  if (!ReadFile(path, &text, error)) return false;
  // Strip a UTF-8 BOM; leaving it in would put an invisible character in the
  // middle of the output.
  if (text.size() >= 3 && static_cast<unsigned char>(text[0]) == 0xEF &&
      static_cast<unsigned char>(text[1]) == 0xBB &&
      static_cast<unsigned char>(text[2]) == 0xBF) {
    text.erase(0, 3);
  }
  if (!Parse(text, error)) return false;
  const FormatTree tree = BuildFormatTree(unit_, style_);
  *output = RenderFormatTree(tree, style_.indent_width);
  return true;
}

void IclDriver::DumpAst() const {
  for (AstNode* node : unit_.top_level()) {
    DumpNode(*node, 0);
  }
}

}  // namespace icl
