// Copyright 2024 The ICL Format Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// The driver ties the three passes together and owns the resulting AST:
//
//   input text --[bison+flex]--> AST --[layout]--> FormatTree --[render]--> text
//
// It also exposes the small factory helpers the grammar actions call, so the
// .yy file stays readable.

#ifndef ICL_FORMAT_SRC_ICL_DRIVER_H_
#define ICL_FORMAT_SRC_ICL_DRIVER_H_

#include <string>
#include <vector>

#include "icl_ast.h"
#include "format_tree.h"

namespace icl {

// SpanOf() helpers live in icl_ast.h next to SourceSpan.

class IclDriver {
 public:
  IclDriver() = default;

  // Runs the whole pipeline. Returns false and fills |error| when the input is
  // not valid IEEE 1687 ICL, or when it cannot be read.
  bool FormatFile(const std::string& path, std::string* output,
                  std::string* error);

  bool FormatText(const std::string& text, std::string* output,
                  std::string* error);

  // ---- factory helpers used by the grammar actions ----
  AstUnit& unit() { return unit_; }

  AstModule* MakeAstModule(const std::string& name, SourceSpan span) {
    return unit_.Make<AstModule>(name, span);
  }

  AstStatement* MakeStatement(AstKind kind, const std::string& text,
                              SourceSpan span) {
    return unit_.Make<AstStatement>(kind, text, span);
  }

  AstBlock* MakeBlock(AstKind kind, const std::string& header,
                      SourceSpan span) {
    return unit_.Make<AstBlock>(kind, header, span);
  }

  AstPort* MakePort(const std::string& header, SourceSpan span) {
    return unit_.Make<AstPort>(header, span);
  }

  AstPortGroup* MakePortGroup(const std::string& name,
                              std::vector<std::string> idents,
                              SourceSpan span) {
    return unit_.Make<AstPortGroup>(name, std::move(idents), span);
  }

  AstNode* AddComment(const std::string& text, SourceSpan span) {
    return unit_.Make<AstComment>(text, span);
  }

  const FormatStyle& style() const { return style_; }
  void set_style(const FormatStyle& style) { style_ = style; }

  // Dumps the AST to stdout; used by `--ast`.
  void DumpAst() const;

 private:
  bool Parse(const std::string& text, std::string* error);

  AstUnit unit_;
  FormatStyle style_;
};

}  // namespace icl

#endif  // ICL_FORMAT_SRC_ICL_DRIVER_H_
