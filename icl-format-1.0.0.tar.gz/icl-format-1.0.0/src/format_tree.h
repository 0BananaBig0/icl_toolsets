// Copyright 2024 The ICL Format Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Phase 2 of the pipeline: the Format Tree (a.k.a. layout tree, doc tree).
//
// Wikipedia calls this family of structures a "document tree"; clang-format
// calls the analogous concept an "unwrapped line". Either way the job of this
// pass is to turn the AST's *semantic* structure into *visual* structure:
// decide where lines break, how much each line is indented, which nodes stay
// on one line, and where blank lines belong.
//
// Why not format straight from the AST? Because the AST answers "what is this
// construct", not "how should it look". Two examples from ICL:
//
//   * `PortGroup tap_side {si, so, en}` is a comma list, semantically close to
//     `PortGroup tap_side { Source si; ... }`, but visually it must stay on a
//     single line. That is a layout decision, not a grammar one.
//   * `} // trailing note` — the comment belongs to the closing brace's line
//     even though the AST visited it as a sibling node afterwards.
//
// Keeping this pass separate means the parser stays free of formatting policy,
// and a future style (2-space indent, Allman braces) is a change here only.

#ifndef ICL_FORMAT_SRC_FORMAT_TREE_H_
#define ICL_FORMAT_SRC_FORMAT_TREE_H_

#include <string>
#include <vector>

#include "icl_ast.h"

namespace icl {

// Style knobs. Defaults follow the Google C++ style guide: 2-space indent.
struct FormatStyle {
  // Number of spaces per indentation level.
  int indent_width = 2;

  // Maximum consecutive blank lines to keep from the input.
  int max_blank_lines = 1;

  // Whether to insert a blank line between top-level modules.
  bool blank_line_between_modules = false;
};

// What a FormatNode renders to.
enum class FormatKind {
  kLine,       // One source line of text.
  kComment,    // One or more comment lines.
  kGroupOpen,  // `HEADER {` — increases the indent of what follows.
  kGroupClose  // `}`        — decreases its own indent.
};

class FormatNode {
 public:
  FormatNode(FormatKind kind, std::string text, int indent)
      : kind_(kind), text_(std::move(text)), indent_(indent) {}

  FormatKind kind() const { return kind_; }
  const std::string& text() const { return text_; }
  int indent() const { return indent_; }

  // Source line the text came from (1-based). Used to decide whether a blank
  // line separates this node from the previous one.
  int source_line() const { return source_line_; }
  void set_source_line(int line) { source_line_ = line; }

  // True for a node that continues the previous output line (`} // note`).
  bool trailing() const { return trailing_; }
  void set_trailing(bool value) { trailing_ = value; }

 private:
  FormatKind kind_;
  std::string text_;
  int indent_ = 0;
  int source_line_ = 0;
  bool trailing_ = false;
};

// A flat list of renderable lines. Flat on purpose: indentation has already
// been resolved into every node, so printing is a simple walk with no state.
class FormatTree {
 public:
  FormatTree() = default;

  std::vector<FormatNode>& nodes() { return nodes_; }
  const std::vector<FormatNode>& nodes() const { return nodes_; }

 private:
  std::vector<FormatNode> nodes_;
};

// Phase 2 entry point: AST -> FormatTree.
//
// Decides line breaks, indentation (as absolute levels), blank-line
// preservation and trailing-comment attachment.
FormatTree BuildFormatTree(const AstUnit& unit, const FormatStyle& style);

// Renders a FormatTree to text. Phase 3.
//
// |indent_width| converts each node's indentation *level* into spaces; levels
// are stored in the tree so that style changes do not require a re-layout.
std::string RenderFormatTree(const FormatTree& tree, int indent_width);

}  // namespace icl

#endif  // ICL_FORMAT_SRC_FORMAT_TREE_H_
