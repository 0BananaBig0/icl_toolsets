// Copyright 2024 The ICL Format Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "icl_ast.h"

#include <string>

namespace icl {

const char* AstKindName(AstKind kind) {
  switch (kind) {
    case AstKind::kComment:
      return "Comment";
    case AstKind::kModule:
      return "Module";
    case AstKind::kParameter:
      return "Parameter";
    case AstKind::kAttribute:
      return "Attribute";
    case AstKind::kAttributeItem:
      return "AttributeItem";
    case AstKind::kMuxEntry:
      return "MuxEntry";
    case AstKind::kConnectionItem:
      return "ConnectionItem";
    case AstKind::kPort:
      return "Port";
    case AstKind::kScanInterface:
      return "ScanInterface";
    case AstKind::kOneHotScanInterface:
      return "OneHotScanInterface";
    case AstKind::kScanRegister:
      return "ScanRegister";
    case AstKind::kReg:
      return "Reg";
    case AstKind::kField:
      return "Field";
    case AstKind::kInstance:
      return "Instance";
    case AstKind::kAlias:
      return "Alias";
    case AstKind::kEnum:
      return "Enum";
    case AstKind::kScanMux:
      return "ScanMux";
    case AstKind::kLogicSignal:
      return "LogicSignal";
    case AstKind::kConnection:
      return "Connection";
    case AstKind::kPortGroup:
      return "PortGroup";
    case AstKind::kAccessLink:
      return "AccessLink";
    case AstKind::kAccessLinkItem:
      return "AccessLinkItem";
  }
  return "Unknown";
}

namespace {

int g_diagnostic_line = 0;
std::string g_diagnostic_message;

}  // namespace

void ClearParseDiagnostic() {
  g_diagnostic_line = 0;
  g_diagnostic_message.clear();
}

void SetParseDiagnostic(int line, const std::string& message) {
  if (HasParseDiagnostic()) return;  // Keep only the first error.
  g_diagnostic_line = line;
  g_diagnostic_message = message;
}

bool HasParseDiagnostic() { return !g_diagnostic_message.empty(); }

int ParseDiagnosticLine() { return g_diagnostic_line; }

const std::string& ParseDiagnosticMessage() { return g_diagnostic_message; }

}  // namespace icl
