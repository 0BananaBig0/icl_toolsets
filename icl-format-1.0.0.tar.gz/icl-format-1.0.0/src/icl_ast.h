// Copyright 2024 The ICL Format Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Phase 1 of the pipeline: the Abstract Syntax Tree.
//
// An AST node carries *semantic* information only. It deliberately stores no
// whitespace, no indentation and no line-breaking decisions: those are decided
// later, in phase 2 (see format_tree.h). Every node keeps the source line
// span it came from, which the layout pass needs in order to preserve blank
// lines and to re-attach trailing comments.
//
// Ownership model: |AstUnit| owns every node it creates (arena style) and
// child vectors hold non-owning pointers. This keeps bison's variant values
// trivial (plain pointers) and avoids leaking nodes when a rule is discarded
// during error recovery.

#ifndef ICL_FORMAT_SRC_ICL_AST_H_
#define ICL_FORMAT_SRC_ICL_AST_H_

#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace icl {

// Half-open source span [first_line, last_line] using 1-based line numbers.
//
// Formatting only needs *line* accuracy: line numbers decide whether a blank
// line separated two constructs, and whether a comment was trailing. Columns
// are deliberately not tracked.
struct SourceSpan {
  int first_line = 0;
  int last_line = 0;
};

// Builds a span from line numbers. Taking plain ints (rather than Bison's
// location type) keeps this header independent of the generated parser, so
// that the AST and the layout pass can be unit tested without bison.
inline SourceSpan SpanOf(int first_line, int last_line) {
  SourceSpan span;
  span.first_line = first_line;
  span.last_line = last_line;
  return span;
}

// All node kinds. The kinds that share a shape reuse the same C++ class; see
// the per-class comments for the mapping.
enum class AstKind {
  kComment,          // AstComment
  kModule,           // AstModule
  kParameter,        // AstStatement
  kAttribute,        // AstStatement
  kAttributeItem,    // AstStatement: `Source sr;` `InputPort a = b.c;`
  kMuxEntry,         // AstStatement: `1'b0 : si;`
  kConnectionItem,   // AstStatement: `a.SO -> b.SI;`
  kPort,             // AstPort (and AstPort with a block body)
  kScanInterface,    // AstBlock
  kOneHotScanInterface,  // AstBlock
  kScanRegister,     // AstBlock
  kReg,              // AstBlock
  kField,            // AstBlock
  kInstance,         // AstBlock
  kAlias,            // AstStatement or AstBlock
  kEnum,             // AstBlock
  kScanMux,          // AstBlock
  kLogicSignal,      // AstBlock
  kConnection,       // AstBlock
  kPortGroup,        // AstPortGroup (inline comma list)
  kAccessLink,       // AstBlock
  kAccessLinkItem,   // AstBlock: nested 1149.1 sub-structure
};

// Returns a human readable name, used by `--ast`.
const char* AstKindName(AstKind kind);

class AstNode {
 public:
  AstNode(AstKind kind, SourceSpan span) : kind_(kind), span_(span) {}
  virtual ~AstNode() = default;

  AstKind kind() const { return kind_; }
  const SourceSpan& span() const { return span_; }

  void set_last_line(int line) { span_.last_line = line; }
  void set_span(SourceSpan span) { span_ = span; }

 private:
  AstKind kind_;
  SourceSpan span_;
};

// A `//` or `/* */` comment. Kept in the AST because comments are part of the
// document, not of the whitespace.
class AstComment : public AstNode {
 public:
  AstComment(const std::string& text, SourceSpan span)
      : AstNode(AstKind::kComment, span), text_(text) {}

  const std::string& text() const { return text_; }
  bool is_multiline() const { return text_.find('\n') != std::string::npos; }

 private:
  std::string text_;
};

// `Module <name> { ... }` — the only top-level construct in ICL.
class AstModule : public AstNode {
 public:
  AstModule(const std::string& name, SourceSpan span)
      : AstNode(AstKind::kModule, span), name_(name) {}

  const std::string& name() const { return name_; }
  std::vector<AstNode*>& body() { return body_; }
  const std::vector<AstNode*>& body() const { return body_; }

 private:
  std::string name_;
  std::vector<AstNode*> body_;
};

// A construct rendered on exactly one line: parameters, attributes, generic
// attribute items, ScanMux selection entries and Connection edges.
class AstStatement : public AstNode {
 public:
  AstStatement(AstKind kind, const std::string& text, SourceSpan span)
      : AstNode(kind, span), text_(text) {}

  const std::string& text() const { return text_; }

 private:
  std::string text_;
};

// `ScanInPort si;` or `DataOutPort dout[7:0] { Source reg; }`.
class AstPort : public AstNode {
 public:
  // |header| is the keyword plus name plus optional bit range, e.g.
  // "ScanOutPort so" or "DataInPort din[31:0]". Empty |body| means the port
  // was terminated with `;`.
  AstPort(const std::string& header, SourceSpan span)
      : AstNode(AstKind::kPort, span), header_(header) {}

  const std::string& header() const { return header_; }
  std::vector<AstNode*>& body() { return body_; }
  const std::vector<AstNode*>& body() const { return body_; }
  bool has_block() const { return !body_.empty(); }

 private:
  std::string header_;
  std::vector<AstNode*> body_;
};

// Any `HEADER { ... }` construct that is not a module, port or comma list:
// Enum / Alias-with-block / ScanInterface / OneHotScanInterface /
// ScanRegister / Reg / Field / Instance / ScanMux / LogicSignal / Connection /
// AccessLink / nested 1149.1 blocks.
class AstBlock : public AstNode {
 public:
  AstBlock(AstKind kind, const std::string& header, SourceSpan span)
      : AstNode(kind, span), header_(header) {}

  const std::string& header() const { return header_; }
  std::vector<AstNode*>& body() { return body_; }
  const std::vector<AstNode*>& body() const { return body_; }

 private:
  std::string header_;
  std::vector<AstNode*> body_;
};

// `PortGroup tap_side {si, so, en}` — a comma separated list without
// semicolons. It must stay on one line, so it gets its own node kind.
class AstPortGroup : public AstNode {
 public:
  AstPortGroup(const std::string& name, std::vector<std::string> idents,
               SourceSpan span)
      : AstNode(AstKind::kPortGroup, span),
        name_(std::move(name)),
        idents_(std::move(idents)) {}

  const std::string& name() const { return name_; }
  const std::vector<std::string>& idents() const { return idents_; }

 private:
  std::string name_;
  std::vector<std::string> idents_;
};

// Owns every node of one parsed file, and hands out non-owning pointers.
class AstUnit {
 public:
  AstUnit() = default;

  // Creates a node of type |T| and takes ownership of it.
  template <typename T, typename... Args>
  T* Make(Args&&... args) {
    auto node = std::make_unique<T>(std::forward<Args>(args)...);
    T* raw = node.get();
    nodes_.push_back(std::move(node));
    return raw;
  }

  std::vector<AstNode*>& top_level() { return top_level_; }
  const std::vector<AstNode*>& top_level() const { return top_level_; }

 private:
  std::vector<std::unique_ptr<AstNode>> nodes_;
  std::vector<AstNode*> top_level_;
};

// Parser diagnostics. bison's error hook is a member function with no access
// to the parser's parameters, so the first syntax error is recorded here and
// read back by the driver. Only the first one matters: later errors are almost
// always cascades of it.
void ClearParseDiagnostic();
void SetParseDiagnostic(int line, const std::string& message);
bool HasParseDiagnostic();
int ParseDiagnosticLine();
const std::string& ParseDiagnosticMessage();

}  // namespace icl

#endif  // ICL_FORMAT_SRC_ICL_AST_H_
