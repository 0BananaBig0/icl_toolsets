// Copyright 2024 The ICL Format Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "format_tree.h"

#include <algorithm>
#include <string>
#include <vector>

namespace icl {
namespace {

// Blank lines are preserved by comparing source line numbers: if the next node
// starts at least two lines below where the previous one ended, the author had
// a blank line there. Cap the number kept so a wall of blank lines collapses.
int BlankLinesBetween(int previous_end_line, int next_start_line,
                      int max_blank_lines) {
  if (previous_end_line <= 0 || next_start_line <= 0) return 0;
  const int gap = next_start_line - previous_end_line - 1;
  return std::clamp(gap, 0, max_blank_lines);
}

// Splits on '\n'. A trailing newline yields no extra empty element, so a
// two-line comment produces exactly two entries.
std::vector<std::string> SplitLines(const std::string& text) {
  std::vector<std::string> lines;
  size_t start = 0;
  while (start <= text.size()) {
    const size_t end = text.find('\n', start);
    if (end == std::string::npos) {
      lines.push_back(text.substr(start));
      break;
    }
    lines.push_back(text.substr(start, end - start));
    start = end + 1;
    if (start == text.size()) lines.emplace_back();  // Trailing newline.
  }
  return lines;
}

class FormatTreeBuilder {
 public:
  explicit FormatTreeBuilder(const FormatStyle& style) : style_(style) {}

  void Build(const AstUnit& unit) {
    for (AstNode* node : unit.top_level()) {
      Emit(*node, 0);
    }
  }

  FormatTree Take() { return std::move(tree_); }

 private:
  // Emits |node| at indentation level |depth|.
  //
  // Dispatch is by dynamic type, not by |AstKind|: several kinds (Alias,
  // ScanRegister, Reg, Field) exist both as a one-line statement
  // (`Alias a = b;`) and as a block (`Alias a = b { ... }`). Classifying by
  // kind would cast one of them to the wrong C++ type.
  void Emit(const AstNode& node, int depth) {
    if (const AstComment* comment = dynamic_cast<const AstComment*>(&node)) {
      EmitComment(*comment, depth);
      return;
    }
    if (const AstModule* module = dynamic_cast<const AstModule*>(&node)) {
      EmitModule(*module, depth);
      return;
    }
    if (const AstPort* port = dynamic_cast<const AstPort*>(&node)) {
      EmitPort(*port, depth);
      return;
    }
    if (const AstPortGroup* group = dynamic_cast<const AstPortGroup*>(&node)) {
      EmitPortGroup(*group, depth);
      return;
    }
    if (const AstStatement* stmt = dynamic_cast<const AstStatement*>(&node)) {
      EmitStatement(*stmt, depth);
      return;
    }
    if (const AstBlock* block = dynamic_cast<const AstBlock*>(&node)) {
      EmitBlock(*block, depth);
      return;
    }
    // Unreachable: every AstKind maps to one of the classes above.
    Append(FormatKind::kLine, "/* unhandled node */", depth,
           node.span().first_line);
  }

  void EmitComment(const AstComment& node, int depth) {
    const std::vector<FormatNode>& nodes = tree_.nodes();
    // A single-line comment that started on the same source line as the
    // previous output line is a trailing comment. The *comment* is the node
    // that must join the previous line — marking the previous node instead
    // would pull it up onto its own predecessor.
    if (!nodes.empty() && node.span().first_line == nodes.back().source_line() &&
        !node.is_multiline()) {
      Append(FormatKind::kComment, node.text(), depth, node.span().first_line);
      tree_.nodes().back().set_trailing(true);
      return;
    }
    // Multi-line comments keep their internal line structure. Continuation
    // lines are re-indented from scratch: the common leading whitespace is
    // removed (it is an artifact of wherever the author placed the comment)
    // while any *relative* alignment between lines is kept, so the classic
    // " * ..." star alignment survives. Stripping a common prefix rather than
    // all whitespace is what keeps repeated formatting stable.
    const std::vector<std::string> lines = SplitLines(node.text());
    size_t common = std::string::npos;
    for (size_t i = 1; i < lines.size(); ++i) {
      const size_t indent = lines[i].find_first_not_of(" \t");
      if (indent == std::string::npos) continue;  // Blank line: ignore.
      common = (common == std::string::npos) ? indent : std::min(common, indent);
    }
    // When the comment uses the classic "/*" + " * ..." star style, re-base
    // the continuation lines one column in so the stars stay aligned under the
    // opening one. Comments that do not use stars keep their relative indent
    // unchanged, so their internal layout is not gratuitously rewritten.
    bool star_style = false;
    if (lines.size() > 1) {
      const size_t first_char = lines[1].find_first_not_of(" \t");
      star_style = first_char != std::string::npos &&
                   lines[1][first_char] == '*';
    }
    const std::string base(star_style ? 1 : 0, ' ');
    for (size_t i = 0; i < lines.size(); ++i) {
      std::string piece = lines[i];
      if (i > 0 && common != std::string::npos && piece.size() >= common) {
        const size_t indent = piece.find_first_not_of(" \t");
        const size_t extra =
            (indent == std::string::npos) ? 0 : indent - common;
        piece = base + std::string(extra, ' ') + piece.substr(common);
      }
      Append(FormatKind::kComment, piece, depth, node.span().first_line + i);
    }
  }

  void EmitStatement(const AstStatement& node, int depth) {
    Append(FormatKind::kLine, node.text(), depth, node.span().first_line);
  }

  void EmitPortGroup(const AstPortGroup& node, int depth) {
    // Comma lists stay inline: `PortGroup tap_side {si, so, en}`.
    std::string text = "PortGroup " + node.name() + " {";
    for (size_t i = 0; i < node.idents().size(); ++i) {
      if (i != 0) text += ", ";
      text += node.idents()[i];
    }
    text += "}";
    Append(FormatKind::kLine, text, depth, node.span().first_line);
  }

  void EmitPort(const AstPort& node, int depth) {
    if (!node.has_block()) {
      // Plain `ScanInPort si;` — the semicolon is not part of the header text.
      Append(FormatKind::kLine, node.header() + ";", depth,
             node.span().first_line);
      return;
    }
    EmitGroup(node.header(), node.body(), depth, node.span());
  }

  void EmitModule(const AstModule& node, int depth) {
    EmitGroup("Module " + node.name(), node.body(), depth, node.span());
  }

  void EmitBlock(const AstBlock& node, int depth) {
    EmitGroup(node.header(), node.body(), depth, node.span());
  }

  template <typename Body>
  void EmitGroup(const std::string& header, const Body& body, int depth,
                 const SourceSpan& span) {
    Append(FormatKind::kGroupOpen, header + " {", depth, span.first_line);
    for (AstNode* child : body) {
      Emit(*child, depth + 1);
    }
    Append(FormatKind::kGroupClose, "}", depth, span.last_line);
  }

  void Append(FormatKind kind, const std::string& text, int depth,
              int source_line) {
    const int blanks = BlankLinesBetween(last_source_line_, source_line,
                                         style_.max_blank_lines);
    for (int i = 0; i < blanks; ++i) {
      FormatNode blank(FormatKind::kLine, "", 0);
      blank.set_source_line(source_line);
      tree_.nodes().push_back(std::move(blank));
    }
    FormatNode node(kind, text, depth);
    node.set_source_line(source_line);
    tree_.nodes().push_back(std::move(node));
    last_source_line_ = std::max(last_source_line_, source_line);
  }

  const FormatStyle& style_;
  FormatTree tree_;
  int last_source_line_ = 0;
};

}  // namespace

FormatTree BuildFormatTree(const AstUnit& unit, const FormatStyle& style) {
  FormatTreeBuilder builder(style);
  builder.Build(unit);
  return builder.Take();
}

std::string RenderFormatTree(const FormatTree& tree, int indent_width) {
  std::string out;
  bool at_line_start = true;
  for (const FormatNode& node : tree.nodes()) {
    if (node.kind() == FormatKind::kLine && node.text().empty()) {
      // A blank line marker: close the current line, then emit an empty one.
      out += at_line_start ? "\n" : "\n\n";
      at_line_start = true;
      continue;
    }
    if (node.trailing() && !at_line_start) {
      out += ' ';
    } else {
      if (!at_line_start) out += '\n';
      out.append(node.indent() * indent_width, ' ');
    }
    out += node.text();
    at_line_start = false;
  }
  if (!out.empty()) out += '\n';
  return out;
}

}  // namespace icl
