// Copyright 2024 The ICL Format Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// `--tokens`: prints the token stream. Exists to debug the lexer in isolation
// — when the parser rejects a file, this shows whether the scanner produced
// the tokens one expected.

#include <cstdio>
#include <iostream>
#include <string>

#include "icl_driver.h"
#include "icl_parser.hh"

// Declared by the generated scanner (see icl_lexer.l).
void icl_reset_lexer(FILE* input);

namespace icl {
IclParser::symbol_type yylex(IclDriver& driver);
}

namespace icl {

void DumpTokens(const std::string& text) {
  FILE* input = fmemopen(const_cast<char*>(text.data()), text.size(), "r");
  if (input == nullptr) {
    input = tmpfile();
    if (input == nullptr) {
      std::cerr << "icl-format: cannot open input buffer\n";
      return;
    }
    fwrite(text.data(), 1, text.size(), input);
    rewind(input);
  }
  icl_reset_lexer(input);

  IclDriver driver;
  // Drive the scanner directly, bypassing the parser.
  int count = 0;
  while (true) {
    const IclParser::symbol_type symbol = yylex(driver);
    const std::string name = symbol.name();
    if (name == "end of file") break;
    std::cout << symbol.location.begin.line << '\t' << name << '\n';
    if (++count > 200000) break;  // Safety valve on malformed input.
  }
  fclose(input);
}

}  // namespace icl
